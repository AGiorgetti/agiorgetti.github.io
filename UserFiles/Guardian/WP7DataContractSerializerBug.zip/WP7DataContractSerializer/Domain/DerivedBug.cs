﻿using System;
using System.Net;
using System.Runtime.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace WP7DataContractSerializerBug.Domain
{
	[DataContract]
	public class DerivedBug : Entity
	{
		/// <summary>
		/// This is a workaround to a bug in WP7 DataContractSerializer
		/// where no data will be serialized for a class if it
		/// doesn't have an explicit DataMember property or field.
		/// </summary>
		//[DataMember]
		//public int U { get; set; }
	}
}
