using System;

namespace IoCRelease
{
   public interface IIoC : IDisposable
   {
      T GetService<T>() where T : class;
      T Resolve<T>() where T : class;
      T Resolve<T>(object argumentAsAnonimousType) where T : class;
      void Release(object obj);
      T Resolve<T>(string key) where T : class;
   }
}