﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IoCRelease.Entities
{
   public class Entity: ITestEntity
   {
      public static Int32 NumOfFinalize;

      ~Entity()
      {
         _isDisposed = true;
         NumOfFinalize++;
      }

      /// <summary>
      /// just to waste some memory
      /// </summary>
      private byte[] big = new byte[1000000];

      #region ITestEntity Members

      public bool IsDisposed
      {
         get
         {
            return _isDisposed;
         }
      }
      private bool _isDisposed; 

      #endregion
   }
}
