namespace IoCRelease.Entities
{
   public interface ITestEntity
   {
      bool IsDisposed { get; }
   }
}