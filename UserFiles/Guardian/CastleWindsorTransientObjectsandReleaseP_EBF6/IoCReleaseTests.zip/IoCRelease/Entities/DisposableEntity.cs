﻿using System;

namespace IoCRelease.Entities
{
   public class DisposableEntity : IDisposable, ITestEntity
   {
      public static Int32 NumOfDispose;
      public static Int32 NumOfFinalize;

      /// <summary>
      /// just to waste some memory
      /// </summary>
      private byte[] big = new byte[1000000];

      #region Dispose

      private bool _disposed;

      public void Dispose()
      {
         Dispose(true);
         GC.SuppressFinalize(this);
      }

      protected virtual void Dispose(bool disposing)
      {
         if (!_disposed)
         {
            if (disposing) // Managed:
            {
               _isDisposed = true;
               NumOfDispose++;
            }
            // Unmanaged:
         }
         _disposed = true;
      }

      ~DisposableEntity()
      {
         Dispose(false);
         NumOfFinalize++;
      }

      #endregion

      #region ITestEntity Members

      public bool IsDisposed
      {
         get
         {
            return _isDisposed;
         }
      }
      private bool _isDisposed; 

      #endregion
   }
}
