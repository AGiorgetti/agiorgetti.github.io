﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Castle.Core.Resource;
using Castle.MicroKernel.Releasers;
using Castle.Windsor;
using Castle.Windsor.Configuration.Interpreters;
using IoCRelease.Castle;

namespace IoCRelease
{
   public class CastleIoC : IIoC
   {
      private readonly IWindsorContainer _container;

      public CastleIoC()
      {
         _container = new WindsorContainer(
            new XmlInterpreter(new ConfigResource("services")));
         _container.Kernel.ReleasePolicy = new TrulyTransientReleasePolicy();
      }

      #region Dispose

      private bool _disposed;

      public void Dispose()
      {
         Dispose(true);
         GC.SuppressFinalize(this);
      }

      protected virtual void Dispose(bool disposing)
      {
         if (!_disposed)
         {
            if (disposing) // Managed:
            {
               _container.Dispose();
            }
            // Unmanaged:
         }
         _disposed = true;
      }

      ~CastleIoC()
      {
         Dispose(false);
      }

      #endregion

      public T GetService<T>() where T : class
      {
         return _container.GetService<T>();
      }

      public T Resolve<T>() where T : class
      {
         return _container.Resolve<T>();
      }

      public T Resolve<T>(string key) where T : class
      {
         return _container.Resolve<T>(key);
      }

      public T Resolve<T>(object argumentAsAnonimousType) where T : class
      {
         return _container.Resolve<T>(argumentAsAnonimousType);
      }

      public void Release(object obj)
      {
         _container.Release(obj);
      }
   }
}