﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IoCRelease.Entities;
using NUnit.Framework;

namespace IoCRelease.Tests
{
   [TestFixture]
   public class ReleaseEntities
   {
      [Test]
      public void TransientNonDisposableObject()
      {
         try
         {
            using (IIoC ioc = new CastleIoC())
            {
               for (Int32 I = 0; I < 10000; ++I)
               {
                  // ask the container to create a transient object
                  ITestEntity var = ioc.Resolve<ITestEntity>("Entity");
                  if (I % 100 == 0)
                  {
                     GC.Collect(2);

                     Console.WriteLine("Iteration: {0}, Memory {1} Finalize {2}",
                                       I, GC.GetTotalMemory(false), Entity.NumOfFinalize);
                  }
                  // ioc.Release(var);
               }
            }
            Console.WriteLine("Number of Dispose Called {0}", Entity.NumOfFinalize);
         }
         catch (Exception ex)
         {
            Console.WriteLine("Out of Memory Exception, Finalize called after container destruction: {0}", Entity.NumOfFinalize);
            throw;
         }
      }
   }
}
