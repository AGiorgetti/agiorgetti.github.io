﻿using System.Reflection;
using ConfOrm;
using ConfOrm.Mappers;

namespace ConfORM_Tests.Appliers
{
	public class IdNamingApplier : IPatternApplier<MemberInfo, IIdMapper>
	{
		#region IPatternApplier<MemberInfo,IIdMapper> Members

		public void Apply(MemberInfo subject, IIdMapper applyTo)
		{
			applyTo.Column("Test" + subject.Name);
		}

		#endregion

		#region IPattern<MemberInfo> Members

		public bool Match(MemberInfo subject)
		{
			return (subject != null);
		}

		#endregion
	}
}