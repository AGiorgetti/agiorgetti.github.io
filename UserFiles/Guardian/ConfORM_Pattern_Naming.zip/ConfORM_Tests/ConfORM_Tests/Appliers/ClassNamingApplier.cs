﻿using System;
using ConfOrm;
using ConfOrm.Mappers;

namespace ConfORM_Tests.Appliers
{
	public class ClassNamingApplier : IPatternApplier<Type, IClassAttributesMapper>
	{
		#region IPattern<Type> Members

		public bool Match(Type subject)
		{
			return subject != null;
		}

		#endregion

		#region IPatternApplier<Type,IClassAttributesMapper> Members

		public void Apply(Type subject, IClassAttributesMapper applyTo)
		{
			applyTo.Table("Test" + subject.Name);
		}

		#endregion
	}
}