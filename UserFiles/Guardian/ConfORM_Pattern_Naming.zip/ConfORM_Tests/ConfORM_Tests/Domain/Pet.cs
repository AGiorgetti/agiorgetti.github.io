﻿namespace ConfORM_Tests.Domain
{
	public class Pet
	{
		public virtual int Id { get; set; }
		public virtual string Name { get; set; }
		public virtual Person Owner { get; set; }
	}
}