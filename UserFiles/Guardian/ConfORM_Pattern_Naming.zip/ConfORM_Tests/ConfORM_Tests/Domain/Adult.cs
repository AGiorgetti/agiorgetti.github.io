﻿namespace ConfORM_Tests.Domain
{
	public class Adult : Person
	{
		public virtual string Title { get; set; }
	}
}
