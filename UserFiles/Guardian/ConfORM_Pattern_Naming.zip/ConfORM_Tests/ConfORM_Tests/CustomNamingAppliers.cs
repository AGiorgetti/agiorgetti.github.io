﻿using System;
using System.Collections.Generic;
using System.Linq;
using ConfOrm;
using ConfOrm.NH;
using ConfOrm.Shop.Packs;
using ConfORM_Tests.Appliers;
using ConfORM_Tests.ConfORM;
using ConfORM_Tests.Domain;
using NHibernate.Cfg;
using NHibernate.Cfg.MappingSchema;
using NHibernate.Tool.hbm2ddl;
using NUnit.Framework;

namespace ConfORM_Tests
{
	[TestFixture]
	public class CustomNamingAppliers : TestBase
	{
		private static void InitializeConfORM(Configuration nhConfig)
		{
			var orm = new ObjectRelationalMapper();

			// set the Persistence Object ID strategy
			var patternsAppliers = new SafePropertyAccessorPack();
			// add a custom naming strategy to alter the Table names
			patternsAppliers.Merge(new ClassNamingApplier());
			// add a custom naming strategy to alter the Id columns names
			patternsAppliers.Merge(new IdNamingApplier());
			// add a custom naming strategy to alter the Property column names
			patternsAppliers.Merge(new PropertyNamingApplier());
			// add a custom naming strategy for the relationships
			patternsAppliers.Merge(new ManyToOneColumnNamingApplier());
			patternsAppliers.Merge(new OneToManyKeyColumnNamingApplier(orm));
			
			var mapper = new Mapper(orm, patternsAppliers);

			// define the mapping shape

			// list all the entities we want to map
			IEnumerable<Type> baseEntities = typeof(Person).Assembly.GetTypes().Where(t => t.Namespace == typeof(Person).Namespace);

			// defines the whole hierarchy coming up from Person
			orm.TablePerClassHierarchy<Person>();

			// we map all the other classes as Table per class
			orm.TablePerClass(baseEntities.Where(t => !typeof(Person).IsAssignableFrom(t)));

			// compile the mapping for the specified entities
			HbmMapping mappingDocument = mapper.CompileMappingFor(baseEntities);

			// dump the mapping to the console
			Console.Write(mappingDocument.AsString());

			// inject the mapping in NHibernate
			nhConfig.AddDeserializedMapping(mappingDocument, "Domain");
			// fix up the schema
			SchemaMetadataUpdater.QuoteTableAndColumns(nhConfig);
		}

		/// <summary>
		/// In the Fixture setup we configure NHibernate and we create the mappings
		/// </summary>
		[Test]
		public void T01_Setup_SessionFactory()
		{
			Configuration nhConfig = ConfigureNHibernate();
			Assert.IsNotNull(nhConfig);
			// initialize ConfORM engine
			InitializeConfORM(nhConfig);
			// create the session factory
			Assert.DoesNotThrow(() => SessionFactory = nhConfig.BuildSessionFactory());
			// SessionFactory = NhConfig.BuildSessionFactory();
		}

		[Test]
		public void T02_CreateDatabaseSchema()
		{
			Configuration nhConfig = ConfigureNHibernate();
			Assert.IsNotNull(nhConfig);
			// initialize ConfORM engine
			InitializeConfORM(nhConfig);
			// clear up the database 
			Assert.DoesNotThrow(() => new SchemaExport(nhConfig).Drop(false, true));
			// create it
			Assert.DoesNotThrow(() => new SchemaExport(nhConfig).Create(false, true));
		}
	}
}
