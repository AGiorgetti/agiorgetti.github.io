﻿using System;

namespace ExplitInterfaceBinding
{
    public interface IFirst
    {
        string this[string index] { get; }

        String Name { get; }
    }
}
