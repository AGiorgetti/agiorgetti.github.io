﻿namespace ExplitInterfaceBinding
{
    public class IndexableWrapper : IIndexable<string, string>
    {
        public IndexableWrapper(IFirst wrapped)
        {
            _class = wrapped;
        }

        private readonly IFirst _class;

        public string this[string index]
        {
            get { return _class[index]; }
        }
    }
}
