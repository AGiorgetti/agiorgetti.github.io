﻿namespace ExplitInterfaceBinding
{
    public class Entity : IFirst, ISecond
    {
        public string Name
        {
            get { return "Class Name"; }
        }
        
        public string this[string index]
        {
            get { return "Class Indexer"; }
        }

        string IFirst.this[string index]
        {
            get { return "First Indexer"; }
        }

        string IFirst.Name
        {
            get { return "First Name"; }
        }

        string ISecond.this[string index]
        {
            get { return "Second Indexer"; }
        }

        string ISecond.Name
        {
            get { return "Second Name"; }
        }

        public IIndexable<string, string> FirstIndexer
        {
            get { return  (new IndexableWrapper(this)); }
        }
    }
}
