﻿using System;

namespace ExplitInterfaceBinding
{
    public interface ISecond
    {
        string this[string index] { get; }

        String Name { get; }
    }
}
