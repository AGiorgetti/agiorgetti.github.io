﻿namespace ExplitInterfaceBinding
{
    public interface IIndexable<in TKey, out TResult>
    {
        TResult this[TKey index] { get; }
    }
}
