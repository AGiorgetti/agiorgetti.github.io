using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using ConfOrm;
using ConfOrm.NH;
using ConfOrm.Patterns;
using ConfOrm.Shop.Appliers;
using ConfOrm.Shop.CoolNaming;
using ConfOrm.Shop.Inflectors;
using ConfOrm.Shop.Packs;
using ConfOrm.Shop.InflectorNaming;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Cfg.MappingSchema;
using NHibernate.Dialect;
using NHibernate.Driver;
using NHibernate.Tool.hbm2ddl;
using System.Linq;
using NHibernateInitialization.Domain;

namespace NHibernateInitialization
{
	public abstract class NHibernateInitializer : IDomainMapper
	{
		private const string ConnectionString =
			@"Data Source=localhost\se2008r2;Initial Catalog=NHibernateTests;Integrated Security=True;Pooling=False";

		protected Configuration Configure;
		private ISessionFactory _sessionFactory;

		public ISessionFactory SessionFactory
		{
			get { return _sessionFactory ?? (_sessionFactory = Configure.BuildSessionFactory()); }
		}

		public void Initialize()
		{
			Configure = new Configuration();
			Configure.SessionFactoryName("Demo");
			Configure.DataBaseIntegration(db =>
			                              {
			                              	db.Dialect<MsSql2005Dialect>();
			                              	db.Driver<SqlClientDriver>();
			                              	db.KeywordsAutoImport = Hbm2DDLKeyWords.AutoQuote;
			                              	db.IsolationLevel = IsolationLevel.ReadCommitted;
			                              	db.ConnectionString = ConnectionString;
			                              	db.BatchSize = 20;
			                              	db.Timeout = 10;
			                              	db.HqlToSqlSubstitutions = "true 1, false 0, yes 'Y', no 'N'";
			                              });
			Map();
		}

		public void CreateSchema()
		{
			new SchemaExport(Configure).Create(false, true);
		}

		public void DropSchema()
		{
			new SchemaExport(Configure).Drop(false, true);
		}

		private void Map()
		{
			Configure.AddDeserializedMapping(HbmMapping, "Domain");
		}

		public HbmMapping HbmMapping
		{
			get { return GetMapper().CompileMappingFor(GetDomainEntities()); }
		}

		public IList<HbmMapping> HbmMappings
		{
			get { return GetMapper().CompileMappingForEach(GetDomainEntities()).ToList(); }
		}

		/// <summary>
		/// Gets the domain entities.
		/// by default anything that derives from Entity
		/// </summary>
		/// <returns></returns>
		protected virtual IEnumerable<Type> GetDomainEntities()
		{
			List<Type> domainEntities = Assembly.GetAssembly(GetType()).GetTypes()
				.Where(t => (typeof(Entity<int>).IsAssignableFrom(t) || typeof(Entity<Guid>).IsAssignableFrom(t) || typeof(Entity<long>).IsAssignableFrom(t))
							&& !t.IsGenericType)
				.ToList();
			// here add your entity-types outside the AbstractEntity<T> hierarchy
			return domainEntities;
		}

		private Mapper GetMapper()
		{
			var inflector = new EnglishInflector();

			var orm = new ObjectRelationalMapper();

			orm.Patterns.Lists.Remove(orm.Patterns.Lists.Single(p => p.GetType() == typeof(ListCollectionPattern)));

			IPatternsAppliersHolder patternsAppliers = (new SafePropertyAccessorPack())
				.Merge(new SafePoidPack())
				.Merge(new OneToOneRelationPack(orm))
				.Merge(new BidirectionalManyToManyRelationPack(orm))
				.Merge(new BidirectionalOneToManyRelationPack(orm))
				.Merge(new DiscriminatorValueAsClassNamePack(orm))
				.Merge(new CoolTablesNamingPack(orm))
				//.Merge(new PluralizedTablesPack(orm, inflector))
				.Merge(new CoolColumnsNamingPack(orm))
				.UnionWith(new ConfOrm.Shop.InflectorNaming.CollectionOfElementsColumnApplier(orm, inflector))
				.Merge(new PolymorphismPack(orm))
				.Merge(new TablePerClassPack())
				.Merge(new UseNoLazyForNoProxablePack()) // <== Lazy false when the class is not proxable
				.Merge(new ConfOrm.Shop.CoolNaming.UnidirectionalOneToManyMultipleCollectionsKeyColumnApplier(orm))
				.Merge(new UseCurrencyForDecimalApplier())
				.Merge(new DatePropertyByNameApplier())
				//.Merge(new MsSQL2008DateTimeApplier())
				;

			//orm.Patterns.PoidStrategies.Add(new HighLowPoidPattern(new {max_lo = 100}));
			orm.Patterns.PoidStrategies.Add(new IdentityPoidPattern());

			var mapper = new Mapper(orm, patternsAppliers);
			
			ConfOrmMapping(orm, mapper);

			return mapper;
		}

		protected abstract void ConfOrmMapping(ObjectRelationalMapper orm, Mapper mapper);
	}
}