﻿using NUnit.Framework;

namespace NHibernate.Envers.Tests.SimpleInitialization
{
	[TestFixture]
	public class Test
	{
		private NHinit _nh;

		[TestFixtureSetUp]
		public void FixtureSetup()
		{
			_nh = new NHinit();
			_nh.Initialize();
			_nh.InitializeAudit();
			_nh.CreateSchema();
		}

		[TestFixtureTearDown]
		public void FixtureTearDown()
		{
			//_nh.DropSchema();
		}

		[Test]
		public void Pass()
		{
			Assert.IsTrue(true);
		}
	}
}