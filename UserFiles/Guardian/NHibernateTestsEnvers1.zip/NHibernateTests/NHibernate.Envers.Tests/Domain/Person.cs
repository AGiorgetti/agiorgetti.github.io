﻿using System.Collections.Generic;
using System.Text;
using NHibernateInitialization.Domain;

namespace NHibernate.Envers.Tests.Domain
{
	public class Person : Entity<int>
	{
		protected Person()
		{
		}

		public Person(string name, string surname)
		{
			Games = new List<Game>();
			Name = name;
			Surname = surname;
		}

		public string Name { get; set; }

		public string Surname { get; set; }

		public string Note { get; set; }
		
		public IList<Game> Games { get; set; }

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("Id: {2}, Name: {0}, Surname: {1}, Note: {3}\n", Name, Surname, Id, Note);
			sb.AppendLine("Games:");
			foreach (var g in Games)
				sb.AppendLine(g.ToString());
			sb.AppendLine("---");
			return sb.ToString();
		}
	}
}