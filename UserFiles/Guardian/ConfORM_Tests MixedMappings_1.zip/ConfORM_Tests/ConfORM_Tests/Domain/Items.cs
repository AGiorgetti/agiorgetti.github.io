﻿using System.Collections.ObjectModel;

namespace ConfORM_Tests.Domain
{
	//public class Items : ReadOnlyCollection<Item>
	//{
	//    public Items() :
	//        base(new[]
	//                {
	//                    new Item() { Id=1, Name="Knife"},
	//                    new Item() { Id=1, Name="Fork"},
	//                    new Item() { Id=1, Name="Spoon"},
	//                })
	//    { }
	//}
}