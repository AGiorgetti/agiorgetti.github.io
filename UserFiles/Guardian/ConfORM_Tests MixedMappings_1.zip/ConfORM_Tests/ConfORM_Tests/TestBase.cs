﻿using System.Data;
using NHibernate;
using NHibernate.ByteCode.LinFu;
using NHibernate.Cfg;
using NHibernate.Cfg.Loquacious;
using NHibernate.Dialect;
using NHibernate.Driver;

namespace ConfORM_Tests
{
	public class TestBase
	{
		static TestBase()
		{
			// remember to initialize Log4Net or logging won't work.
			log4net.Config.XmlConfigurator.Configure();
		}

		public TestBase()
		{
			//NhConfig = ConfigureNHibernate();
		}

		private const string ConnectionString =
			@"Data Source=localhost\SE2008;Initial Catalog=ConfORMtest;Integrated Security=True;Pooling=False";

		//protected Configuration NhConfig;
		protected ISessionFactory SessionFactory;

		protected static Configuration ConfigureNHibernate()
		{
			var configure = new Configuration();
			configure.SessionFactoryName("Demo");
			configure.Proxy(p =>
			{
				p.Validation = false;
				p.ProxyFactoryFactory<ProxyFactoryFactory>();
			});
			configure.DataBaseIntegration(db =>
			{
				db.Dialect<MsSql2008Dialect>();
				db.Driver<SqlClientDriver>();
				db.KeywordsAutoImport = Hbm2DDLKeyWords.AutoQuote;
				db.IsolationLevel = IsolationLevel.ReadCommitted;
				db.ConnectionString = ConnectionString;
				db.Timeout = 10;
				db.HqlToSqlSubstitutions = "true 1, false 0, yes 'Y', no 'N'";

				// enabled for testing
				db.LogFormatedSql = true;
				// db.LogSqlInConsole = true;
				// db.AutoCommentSql = true;
			});

			return configure;
		}

		///// <summary>
		///// In the Fixture setup we configure NHibernate and we create the mappings
		///// </summary>
		//[TestFixtureSetUp]
		//public void Setup()
		//{
		//    NhConfig = ConfigureNHibernate();
		//    // the mapping
		//    HbmMapping mappingDocument = GetMapping();
			
		//    Console.Write(mappingDocument.AsString());
		//    // inject the mapping in NHibernate
		//    NhConfig.AddDeserializedMapping(mappingDocument, "Domain");
		//    // fix up the schema
		//    SchemaMetadataUpdater.QuoteTableAndColumns(NhConfig);
		//    // create the session factory
		//    Assert.DoesNotThrow(() => SessionFactory = NhConfig.BuildSessionFactory());
		//}
	}
}
