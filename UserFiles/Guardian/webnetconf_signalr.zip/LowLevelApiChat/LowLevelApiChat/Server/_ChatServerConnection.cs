﻿using SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LowLevelApiChat.Server
{
    public class ChatServerConnection : PersistentConnection
    {
        protected override System.Threading.Tasks.Task OnReceivedAsync(IRequest request, string connectionId, string data)
        {
            //return base.OnReceivedAsync(request, connectionId, data);

			// 'data' will contains messages in the form of:
			// username|messagedata

            // do some elaboration with the message
            string result = DateTime.Now.ToString() + "|" + data;

            // broadcast to all.
            return Connection.Broadcast(result);
        }        
    }
}