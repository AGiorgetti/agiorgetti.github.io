﻿/// <reference path="jquery-1.8.1.intellisense.js" />
/// <reference path="jquery.signalR-0.5.3.min.js" />
/// <reference path="jquery-ui-1.8.23.js" />
/// <reference path="knockout-2.1.0.debug.js" />
/// <reference path="knockout.mapping-latest.debug.js" />

$(function () {
    "use strict";

    function ChatVM() {
        var self = this;

        this.chatList = ko.observableArray();
        this.username = ko.observable();
        this.message = ko.observable();

        // signalr connection
        var conn = $.connection('/chatserver');
       
        conn.received(function (data) {
            if (data !== undefined && data !== "") {
                var elems = data.split('|');
                self.chatList.push(
                    { timestamp: elems[0], username: elems[1], message: elems[2] }
                );
            };
        });

        this.sendMessage = function () {
            // buildup the message and send it through the wire
            var msg = self.username() + "|" + self.message();
            conn.send(msg);
        };

        conn.start();
    };

    var vm = new ChatVM();
    ko.applyBindings(vm);
});
