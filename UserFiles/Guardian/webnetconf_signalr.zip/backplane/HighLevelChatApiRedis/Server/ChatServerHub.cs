﻿using SignalR.Hubs;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HighLevelChatApi.Server
{
    /// <summary>
    /// Hubs are nice!
    /// They allow us to:
    /// - pass in and out complex objects (json serialized).
    /// - expose functions that can be called by the clients.
    /// - call functions defined on the clients.
    /// </summary>
    [HubName("chatserver")]
    public class ChatServerHub : Hub
    {
        public void SendMessage(SentMessage msg)
        {
            // perform some elaboration:
            Message newMsg = new Message()
            {
                Timestamp = DateTime.Now.ToString(),
                Username = msg.Username,
                Payload = msg.Payload
            };

            // call a method on the clients to notify them a new message has been sent.
            Clients.notify(newMsg);
        }
    }

    /// <summary>
    /// Message that the client will send to the server
    /// </summary>
    public class SentMessage
    {
        public string Username { get; set; }

        public string Payload { get; set; }
    }

    /// <summary>
    /// structure that will be pushed from the server to all the connected clients
    /// </summary>
    public class Message
    {
        /// <summary>
        /// this is a demo: i do not want to get involved in the fight with dates in JS
        /// </summary>
        public string Timestamp { get; set; }

        public string Username { get; set; }

        public string Payload { get; set; }
    }
}