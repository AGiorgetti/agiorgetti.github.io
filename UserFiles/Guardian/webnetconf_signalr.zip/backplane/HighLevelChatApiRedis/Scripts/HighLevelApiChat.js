﻿/// <reference path="jquery-1.8.1.intellisense.js" />
/// <reference path="jquery.signalR-0.5.3.min.js" />
/// <reference path="jquery-ui-1.8.23.js" />
/// <reference path="knockout-2.1.0.debug.js" />
/// <reference path="knockout.mapping-latest.debug.js" />

$(function () {
    "use strict";

    function ChatVM() {
        var self = this;

        this.chatList = ko.observableArray();
        this.username = ko.observable();
        this.message = ko.observable();

        // signalr connection
        var conn = $.connection.chatserver;

        conn.notify = function (msg) {
            self.chatList.push(msg);
        };

        this.sendMessage = function () {
            // buildup the message and send it through the wire
            conn.sendMessage({ Username: self.username(), Payload: self.message() });
        };

        $.connection.hub.start();
    };

    var vm = new ChatVM();
    ko.applyBindings(vm);
});
