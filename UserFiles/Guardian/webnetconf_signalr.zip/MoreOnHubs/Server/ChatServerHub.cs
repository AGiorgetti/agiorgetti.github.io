﻿using SignalR.Hubs;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MoreOnHubs.Server
{
    /// <summary>
    /// Hubs are nice!
    /// They allow us to:
    /// - pass in and out complex objects (json serialized).
    /// - expose functions that can be called by the clients.
    /// - call functions defined on the clients.
    /// </summary>
    [HubName("chatserver")]
    public class ChatServerHub : Hub, IConnected, IDisconnect
    {
        #region "Connection Trackig"

		// Unlike PersistentConnections, Hubs don't have a Connect, Reconnect or Disconnect event. 
		// To detect disconnects when using hubs, implement the IDisconnect interface. To detect connects and reconnects, implement IConnected.

		// Whenever a client disconnects, the Disconnect method will be invoked on all hubs that implement IDisconnect. 
		// When this method is called you can use Context.ConnectionId to access the client that disconnected.
		// NOTE: This method is called from the server, that means state on the Caller object, any state that was with the connection, 
		// as well as the HubContext's User and Cookies will not be populated.

		// The Disconnected event is not always reliable: sooner (or later) it will be called.

		/// <summary>
		/// this solution will not scale: in a server farm we can keep this information in a shared databse or shared cache
		/// we can have multiple connection per User
		/// </summary>
		private static readonly ConcurrentDictionary<string, object> _connections = new ConcurrentDictionary<string, object>();

		public System.Threading.Tasks.Task Connect()
		{
			_connections.TryAdd(Context.ConnectionId, 0);
			return Clients.clientCountChanged(_connections.Count);
		}

		public System.Threading.Tasks.Task Reconnect(IEnumerable<string> groups)
		{
			_connections.AddOrUpdate(Context.ConnectionId, 0, (k, o) => o);
			return Clients.clientCountChanged(_connections.Count);
		}

		public System.Threading.Tasks.Task Disconnect()
		{
			object value;
			_connections.TryRemove(Context.ConnectionId, out value);
			return Clients.clientCountChanged(_connections.Count);
		}

		#endregion

		public void SendMessage(SentMessage msg)
		{
			// send a message to the caller only!
			if (string.IsNullOrEmpty(msg.Topic))
			{
				Caller.noTopicError();
				return;
			}

			// add the user to the connection group
			// very rough! should handle removing from the group also
			string TopicGroup = msg.Topic;
			JoinGroup(Context.ConnectionId, TopicGroup);
			
			// perform some elaboration:
			Message newMsg = new Message()
			{
				Timestamp = DateTime.Now.ToString(),
				Username = msg.Username,
				Topic = TopicGroup,
				Payload = msg.Payload
			};

			// spam only those interested in the very same topic
			Clients[TopicGroup].notify(newMsg);
		}

        #region "Grouping"

		private static readonly ConcurrentDictionary<string, List<string>> _groups = new ConcurrentDictionary<string, List<string>>();

		private static object _groupinglock = new object();

        // You can add connections to groups and send messages to particular groups. 
        // Groups are not persisted on the server so applications are responsible for keeping track 
        // of what connections are in what groups so things like group count can be achieved.
		private void JoinGroup(string signalId, string groupname)
		{
			// (I should also track which connection are in which group and remove them
			// when the client goes away), SignalR do not exposes its internal connections list
			List<string> connList = _groups.GetOrAdd(groupname, new List<string>());
			if (!connList.Contains(signalId))
			{
				// SignalR: add the connection to the group 
				Groups.Add(signalId, groupname).Wait();
				
				// add it to my private list
				connList.Add(signalId);
			}			
		}

		// todo: remove the signal from the group when the client disconnects

        #endregion
    }

    /// <summary>
    /// Message structure that the client will send to the server
    /// </summary>
    public class SentMessage
    {
        public string Username { get; set; }

        /// <summary>
        /// group to which send the message
        /// </summary>
        public string Topic { get; set; }

        public string Payload { get; set; }
    }

    /// <summary>
    /// structure that will be pushed from the server to all the connected clients
    /// </summary>
    public class Message
    {
        /// <summary>
        /// this is a demo: i do not want to get involved in the fight with dates in JS
        /// </summary>
        public string Timestamp { get; set; }

        public string Username { get; set; }

        public string Topic { get; set; }

        public string Payload { get; set; }
    }
}