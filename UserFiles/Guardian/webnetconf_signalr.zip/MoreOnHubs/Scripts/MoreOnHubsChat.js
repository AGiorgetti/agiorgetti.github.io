﻿/// <reference path="jquery-1.8.1.intellisense.js" />
/// <reference path="jquery.signalR-0.5.3.min.js" />
/// <reference path="jquery-ui-1.8.23.js" />
/// <reference path="knockout-2.1.0.debug.js" />
/// <reference path="knockout.bindings.js" />
/// <reference path="knockout.mapping-latest.debug.js" />

$(function () {
    "use strict";

    function tab() {
        this.name = ko.observable();
        this.chatList = ko.observableArray();
    }

    function ChatVM() {
        var self = this;
        //this.chatList = ko.observableArray();

        // just to keep track of the tabs added
        this.tabs = ko.observableArray();
        // the actual tabs viewmodel
        this.tabs2 = ko.observableArray();

        this.topic = ko.observable();
        this.username = ko.observable();
        this.message = ko.observable();

        this.countConnected = ko.observable(0);

        // signalr connection
        var conn = $.connection.chatserver;

        conn.clientCountChanged = function (cnt) {
            self.countConnected(cnt);
        };

        conn.noTopicError = function () {
            alert('You need to specify a topic');
        };

        conn.notify = function (msg) {

            // find a tab and add the data, if no tab is found just add one
            var idx = 0;
            var found = false;
            for (idx = 0; idx < self.tabs().length; idx++) {
                if (self.tabs()[idx].name === msg.Topic) {
                    found = true;
                    self.tabs()[idx].chatList.push(msg);
                    break;
                }
            }

            if (found === false) {
                var newTab = new tab();
                newTab.name = msg.Topic;
                newTab.chatList.push(msg);
                self.tabs.push(newTab);

                var newTab2vm = new ko.TabViewModel(newTab.name, newTab.name, newTab, "tabitem");
                self.tabs2.push(newTab2vm);
            }
        };

        this.sendMessage = function () {
            // buildup the message and send it through the wire
            conn.sendMessage({ Username: self.username(), Topic: self.topic(), Payload: self.message() });
        };

        $.connection.hub.start().done(function () { alert("connection ready"); });
    };

    var vm = new ChatVM();
    ko.applyBindings(vm);
});

//http://jsfiddle.net/rniemeyer/gFqaM/
