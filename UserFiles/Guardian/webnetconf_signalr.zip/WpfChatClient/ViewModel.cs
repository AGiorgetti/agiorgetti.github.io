﻿using SignalR.Client.Hubs;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace WpfChatClient
{
    public class ViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<Tab> Tabs { get; set; }

        public string Topic { get; set; }

        public string Username { get; set; }

        public string Message { get; set; }

        public int CountConnected
        {
            get { return _countConnected; }
            set
            {
                _countConnected = value;
                OnPropertyChanged("CountConnected");
            }
        }
        private int _countConnected;

        public SendCommand SendCommand { get; set; }

        public ViewModel()
        {
            Tabs = new ObservableCollection<Tab>();
            SendCommand = new SendCommand(this);

            InitSignalR();
        }

        #region "signalr"

        // a signalr connections
        HubConnection _conn;
        // reference a hub proxy
        IHubProxy _chatServer;

        private void InitSignalR()
        {
            // point to the root of the website
            _conn = new HubConnection("http://localhost:17536/");
            // get a hub proxy
            _chatServer = _conn.CreateProxy("chatserver");
            // wire up the events
            _chatServer.On<int>("clientCountChanged", data => { CountConnected = data; });

            _chatServer.On("noTopicError", () => { MessageBox.Show("You need to specify a topic"); });

            _chatServer.On("notify", msg =>
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    // find a tab and add the data, if it's not present create a new tab
                    Tab tab = Tabs.SingleOrDefault(t => t.Name == (string)msg.Topic);
                    if (tab != null)
                    {
                        tab.ChatList.Add(new Chat() { Timestamp = DateTime.Parse((string)msg.Timestamp), Username = msg.Username, Payload = msg.Payload });
                        return;
                    }
                    // create a new tab
                    tab = new Tab();
                    tab.Name = msg.Topic;
                    tab.ChatList.Add(new Chat() { Timestamp = DateTime.Parse((string)msg.Timestamp), Username = msg.Username, Payload = msg.Payload });
                    Tabs.Add(tab);
                });
            });

            // start the connection
            _conn.Start().Wait();
        }

        #endregion

        public void Send()
        {
            _chatServer.Invoke("SendMessage", new { Topic = this.Topic, Username = this.Username, Payload = this.Message })
                .ContinueWith(task =>
                {
                    if (task.IsFaulted)
                    {
                        MessageBox.Show(string.Format("Error calling the server: {0}", task.Exception.GetBaseException().Message));
                    }
                });

			// old code to avoid using a call to the service
            //Tab t = new Tab();
            //t.Name = "1";
            //t.ChatList.Add(new Chat() { Timestamp = DateTime.Now, Username = "A", Payload = "pippo" });
            //Tabs.Add(t);
        }

        private void OnPropertyChanged(string propertyName)
        {
            var pc = PropertyChanged;
            if (pc != null)
                pc(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class Tab
    {
        public string Name { get; set; }

        public ObservableCollection<Chat> ChatList { get; set; }

        public Tab()
        {
            ChatList = new ObservableCollection<Chat>();
        }
    }

    public class Chat
    {
        public DateTime Timestamp { get; set; }

        public string Username { get; set; }

        public string Payload { get; set; }
    }

    public class SendCommand : ICommand
    {
        private ViewModel _vm;

        public SendCommand(ViewModel vm)
        {
            _vm = vm;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            _vm.Send();
        }
    }
}
