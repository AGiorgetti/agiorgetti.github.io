﻿using System.Collections.Generic;
using NHibernate.Cfg.MappingSchema;

namespace NHibernateInitialization
{
	/// <summary>
	/// Probe for ConfORM toolbox
	/// </summary>
	public interface IDomainMapper
	{
		HbmMapping HbmMapping { get; }

		IList<HbmMapping> HbmMappings { get; }
	}
}
