﻿using NHibernate.Tests.Domain;
using NUnit.Framework;

namespace NHibernate.Tests.Collections
{
	[TestFixture]
	public class Test
	{
		public Test()
		{
			// remember to call the log4net initialization explicitly...Here I go read from the app.config file
			log4net.Config.XmlConfigurator.Configure();
		}

		private NHinit _nh;

		[TestFixtureSetUp]
		public void FixtureSetup()
		{
			_nh = new NHinit();
			_nh.Initialize();
			_nh.CreateSchema();
			GenerateTestData();
		}

		[TestFixtureTearDown]
		public void FixtureTearDown()
		{
			_nh.DropSchema();
		}

		[Test]
		public void AlwaysPass()
		{
			Assert.IsTrue(true);
		}

		private void GenerateTestData()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					Post p = new Post("Slug");
					for (int i = 0; i < 2; i++)
					{
						Category category = new Category { Name = "Cat" + i };
						s.Persist(category);
						p.Categories.Add(category);
						Tag tag = new Tag { Name = "Tag" + i };
						s.Persist(tag);
						p.Tags.Add(tag);
					}
					s.Persist(p);
					tx.Commit();
				}
			}
		}

		/// <summary>
		/// get the data without fetching 
		/// </summary>
		/// <remarks>
		/// Generates 3 selects:
		/// select post0_.Id as Id0_, post0_.Slug as Slug0_ from Post post0_ where post0_.Slug=@p0;@p0 = 'Slug' [Type: String (4000)]
		/// SELECT categories0_.PostId as PostId1_, categories0_.Id as Id1_, categories0_.Id as Id1_0_, categories0_.Name as Name1_0_ FROM Category categories0_ WHERE categories0_.PostId=@p0;@p0 = 1 [Type: Int32 (0)]
		/// SELECT tags0_.PostId as PostId1_, tags0_.Id as Id1_, tags0_.Id as Id2_0_, tags0_.Name as Name2_0_ FROM Tag tags0_ WHERE tags0_.PostId=@p0;@p0 = 1 [Type: Int32 (0)]
		/// all the data are correct
		/// </remarks>
		[Test]
		public void NoFetch_Success()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					var p = s.CreateQuery("from Post p where p.Slug = :slug")
						.SetParameter("slug", "Slug")
						.UniqueResult<Post>();

					tx.Commit();

					Assert.IsNotNull(p);
					Assert.AreEqual(2, p.Categories.Count); 
					Assert.AreEqual(2, p.Tags.Count); 
				}
			}
		}

		/// <summary>
		/// Get the data fetching everything (this is the mistake! fetching more than 1 collection - at the same level in the hierarchy - generate a cartesian product and duplicated data)
		/// </summary>
		/// <remarks>
		/// Generates a single query
		/// select post0_.Id as Id0_0_, categories1_.Id as Id1_1_, tags2_.Id as Id2_2_, post0_.Slug as Slug0_0_, categories1_.Name as Name1_1_, categories1_.PostId as PostId0__, categories1_.Id as Id0__, tags2_.Name as Name2_2_, tags2_.PostId as PostId1__, tags2_.Id as Id1__ from Post post0_ left outer join Category categories1_ on post0_.Id=categories1_.PostId left outer join Tag tags2_ on post0_.Id=tags2_.PostId where post0_.Slug=@p0;@p0 = 'Slug' [Type: String (4000)]
		/// the data are wrong!
		/// </remarks>
		[Test]
		public void FetchALL_Failure()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					// try adding a: select distinct p 
					var p = s.CreateQuery("from Post p left join fetch p.Categories left join fetch p.Tags where p.Slug = :slug")
						.SetParameter("slug", "Slug")
						.UniqueResult<Post>();

					tx.Commit();

					Assert.IsNotNull(p);
					Assert.AreEqual(4, p.Categories.Count); // 4!!!!!!!!!! Wrong data, it should have been 2
					Assert.AreEqual(4, p.Tags.Count);  // 4!!!!!!!!!! Wrong data, it should have been 2
				}
			}
		}

		/// <summary>
		/// Fetch a single collection
		/// </summary>
		/// <remarks>
		/// Generates 2 queries
		/// select post0_.Id as Id12_0_, categories1_.Id as Id13_1_, post0_.Slug as Slug12_0_, categories1_.Name as Name13_1_, categories1_.PostId as PostId0__, categories1_.Id as Id0__ from Post post0_ left outer join Category categories1_ on post0_.Id=categories1_.PostId where post0_.Slug=@p0;@p0 = 'Slug' [Type: String (4000)]
		/// SELECT tags0_.PostId as PostId1_, tags0_.Id as Id1_, tags0_.Id as Id14_0_, tags0_.Name as Name14_0_ FROM Tag tags0_ WHERE tags0_.PostId=@p0;@p0 = 1 [Type: Int32 (0)]
		/// all the data are correct
		/// </remarks>
		[Test]
		public void FetchSingleCollection_Success1()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					// UniqueResult<T> is smart enough to hide us a 'fetch join' side effect...
					var p = s.CreateQuery("from Post p left join fetch p.Categories where p.Slug = :slug")
						.SetParameter("slug", "Slug")
						.UniqueResult<Post>();

					tx.Commit();

					Assert.IsNotNull(p);
					Assert.AreEqual(2, p.Categories.Count);
					Assert.AreEqual(2, p.Tags.Count);
				}
			}
		}

		/// <summary>
		/// Fetch a single collection
		/// </summary>
		/// <remarks>
		/// Generates 2 queries
		/// select post0_.Id as Id12_0_, categories1_.Id as Id13_1_, post0_.Slug as Slug12_0_, categories1_.Name as Name13_1_, categories1_.PostId as PostId0__, categories1_.Id as Id0__ from Post post0_ left outer join Category categories1_ on post0_.Id=categories1_.PostId where post0_.Slug=@p0;@p0 = 'Slug' [Type: String (4000)]
		/// SELECT tags0_.PostId as PostId1_, tags0_.Id as Id1_, tags0_.Id as Id14_0_, tags0_.Name as Name14_0_ FROM Tag tags0_ WHERE tags0_.PostId=@p0;@p0 = 1 [Type: Int32 (0)]
		/// all the data are correct
		/// </remarks>
		[Test]
		public void FetchSingleCollection_Success2()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					var l = s.CreateQuery("from Post p left join fetch p.Categories where p.Slug = :slug")
						.SetParameter("slug", "Slug")
						.List<Post>();

					Assert.IsNotNull(l);
					// problem: the fetch introduces a 'ghost' here, we have data duplication
					Assert.AreEqual(2, l.Count);

					tx.Commit();
				}
			}
		}

		/// <summary>
		/// Fetch a single collection, the correct way!
		/// </summary>
		/// <remarks>
		/// Generates 2 queries
		/// select distinct post0_.Id as Id12_0_, categories1_.Id as Id13_1_, post0_.Slug as Slug12_0_, categories1_.Name as Name13_1_, categories1_.PostId as PostId0__, categories1_.Id as Id0__ from Post post0_ left outer join Category categories1_ on post0_.Id=categories1_.PostId left outer join Tag tags2_ on post0_.Id=tags2_.PostId where post0_.Slug=@p0;@p0 = 'Slug' [Type: String (4000)]
		/// SELECT tags0_.PostId as PostId1_, tags0_.Id as Id1_, tags0_.Id as Id14_0_, tags0_.Name as Name14_0_ FROM Tag tags0_ WHERE tags0_.PostId=@p0;@p0 = 1 [Type: Int32 (0)]
		/// all the data are correct
		/// </remarks>
		[Test]
		public void FetchSingleCollection_Distinct_Success()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					var p = s.CreateQuery("select distinct p from Post p left join fetch p.Categories where p.Slug = :slug")
						.SetParameter("slug", "Slug")
						.UniqueResult<Post>();
					tx.Commit();

					Assert.IsNotNull(p);
					Assert.AreEqual(2, p.Categories.Count);
					Assert.AreEqual(2, p.Tags.Count);
				}
			}
		}
	}
}