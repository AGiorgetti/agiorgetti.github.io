﻿using NHibernate.Tests.Domain;
using NHibernateInitialization;

namespace NHibernate.Tests.Collections
{
	public class NHinit : NHibernateInitializer
	{
		protected override void ConfOrmMapping(ConfOrm.ObjectRelationalMapper orm, ConfOrm.NH.Mapper mapper)
		{
			orm.TablePerClass<Tag>();
			orm.TablePerClass<Category>();
			orm.TablePerClass<Post>();
		}
	}
}