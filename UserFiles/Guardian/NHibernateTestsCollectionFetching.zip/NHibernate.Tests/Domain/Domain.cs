﻿using System.Collections.Generic;
using NHibernateInitialization.Domain;

namespace NHibernate.Tests.Domain
{
	public class Post : Entity<int>
	{
		protected Post()
		{
		}

		public Post(string slug)
		{
			Slug = slug;
			Categories = new List<Category>();
			Tags = new List<Tag>();
		}

		public string Slug { get; set; }

		public IList<Category> Categories { get; set; }

		public IList<Tag> Tags { get; set; }	
	}

	public class Category : Entity<int>
	{
		public string Name { get; set; }
	}

	public class Tag : Entity<int>
	{
		public string Name { get; set; }
	}
}
