using System;

namespace SID.Installer.BootStrap
{
	/// <summary>
	/// Holds all the options for installing the database or the product
	/// </summary>
	public class InstallOperations
	{
		/// <summary>
		/// true if we have to install the database engine or the database file or generate them through scripting
		/// </summary>
		public bool InstallDatabase;

		/// <summary>
		/// true if we have to install the database engine before using script or attaching a db file
		/// </summary>
		public bool InstallDatabaseEngine;

		/// <summary>
		/// true if we have to install the software
		/// </summary>
		public bool InstallSoftware;

		#region New Database Engine Parameters

		public string EngineInstallationPath
		{
			get 
			{
				if (StringUtils.IsNullOrEmpty(mEngineInstallationPath))
						return ProgramFilesFolder;
				return mEngineInstallationPath;
			}
			set { mEngineInstallationPath = value; }
		}
		private string mEngineInstallationPath;

		public string EngineDataPath
		{
			get 
			{
				if (StringUtils.IsNullOrEmpty(mEngineDataPath))
					return System.IO.Path.Combine(ProgramFilesFolder, "Microsoft SQL Server\\");
				return mEngineDataPath;
			}
			set {mEngineDataPath = value; }
		}

		private string mEngineDataPath;
		public string InstallationInstanceName;
		public string InstallationSaPassword;

		#endregion

		#region Existing Database Engine Parameters

		// these parameters will be used to execute the scripts that allow the creation of the databases
		// they will be automatically filled with defaults if the user selects to install a new database engine

		public bool IntegratedAuthentication;
		public string ScriptInstance;
		public string ScriptUsername;
		public string ScriptPassword;
		public string ScriptPort;

		#endregion

		private static string ProgramFilesFolder = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
			
	}
}
