using System;
using System.IO;
using System.Reflection;

namespace SID.Installer.BootStrap
{
	/// <summary>
	/// Descrizione di riepilogo per ResourceManager.
	/// </summary>
	public class ResourceManager
	{
		public static void SafeDelete(string filename)
		{
			try 
			{
				System.IO.File.Delete(filename);
			}
			catch (Exception ex) 
			{
				System.Diagnostics.Debug.WriteLine(ex.Message);
			}
		}

		public static void WriteResourceToFile(System.Reflection.Assembly assembly, string resourceName, string fileName) 
		{
			using (Stream s = assembly.GetManifestResourceStream(resourceName)) 
			{
				if (s != null) 
				{
					byte[] buffer = new byte[s.Length];
					char[] sb = new char[s.Length];
					s.Read(buffer, 0, (int)(s.Length));
					using(System.IO.FileStream sw = new FileStream(fileName, System.IO.FileMode.Create)) 
					{
						sw.Write(buffer,0,buffer.Length);
						sw.Flush();
					}
				}   
			}
		}
	}
}
