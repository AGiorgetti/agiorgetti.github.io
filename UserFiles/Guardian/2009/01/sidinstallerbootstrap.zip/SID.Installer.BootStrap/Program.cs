using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Reflection;
using System.Diagnostics;

namespace SID.Installer.BootStrap
{
	/// <summary>
	/// Descrizione di riepilogo per Program.
	/// </summary>
	public class Program
	{
		/// <summary>
		/// Il punto di ingresso principale dell'applicazione.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			AppDomain.CurrentDomain.SetShadowCopyFiles();
			ExtractResources();
			Form1 f = new Form1();
			Application.Run(f);
			if (f.DialogResult == DialogResult.OK)
			{
				installoperations = f.InstallOperations;
				InstallSqlEngine();
				ExecuteDatabaseCreationScripts();
				InstallSoftware();
			}
			// when the form closes we have all the information needed to proceed
			GC.Collect();
			DeleteResources();
		}

		private static InstallOperations installoperations;

		private static void ExtractSQLResources() 
		{
			// If you embed some resources you can get themcalling this method
			// ResourceManager.WriteResourceToFile(Assembly.GetExecutingAssembly(), "SID.Installer.BootStrap.Data.SQLEXPR.EXE", "SQLEXPR.EXE");
		}

		private static void ExtractResources() 
		{
			// If you embed some resources you can get themcalling this method
			// ResourceManager.WriteResourceToFile(Assembly.GetExecutingAssembly(), "SID.Installer.BootStrap.Data.SQLEXPR.EXE", "SQLEXPR.EXE");
		}

		private static void DeleteResources()
		{
			// Remove any extracted embedded resource
			// ResourceManager.SafeDelete("SQLEXPR.EXE");
		}

		private static void InstallSqlEngine()
		{
			if ((installoperations.InstallDatabase == false) || (installoperations.InstallDatabaseEngine == false))
				return;

			ExtractSQLResources();
			
			EmbeddedInstall EI = new EmbeddedInstall();

			EI.AutostartSQLBrowserService = false;
			EI.AutostartSQLService = true;
			EI.Collation = "SQL_Latin1_General_Cp1_CS_AS";
			EI.DisableNetworkProtocols = false;
			EI.InstanceName = installoperations.InstallationInstanceName; // "SQLEXPRESS";
			EI.ReportErrors = true;
			EI.SetupFileLocation = System.IO.Path.Combine(Application.StartupPath, "sqlexpr.exe");  // "C:\\Downloads\\sqlexpr.exe";  
			//Provide location for the Express setup file
			//			EI.SqlBrowserAccountName = ""; //Blank means LocalSystem
			//			EI.SqlBrowserPassword = ""; // N/A
			EI.SqlDataDirectory =  installoperations.EngineDataPath; // "C:\\Program Files\\Microsoft SQL Server\\";
			EI.SqlInstallDirectory = installoperations.EngineInstallationPath; // "C:\\Program Files\\";
			EI.SqlInstallSharedDirectory = installoperations.EngineInstallationPath; // "C:\\Program Files\\";
			//			EI.SqlServiceAccountName = ""; //Blank means Localsystem
			//			EI.SqlServicePassword = ""; // N/A
			EI.SysadminPassword = installoperations.InstallationSaPassword; //<<Supply a secure sysadmin password>>
			EI.UseSQLSecurityMode = true;

			int pid = EI.InstallExpress();

			// lets force the script options
			installoperations.IntegratedAuthentication = false;
			installoperations.ScriptInstance = "localhost\\" + installoperations.InstallationInstanceName;
			if (StringUtils.IsNullOrEmpty(installoperations.ScriptPort) == false)
				installoperations.ScriptInstance += "," + installoperations.ScriptPort;
			installoperations.ScriptUsername = "sa";
			installoperations.ScriptPassword = installoperations.InstallationSaPassword;

			// now let's wait till the setup is complete
			Process installp = Process.GetProcessById(pid);
			if (installp != null)
				installp.WaitForExit();
		}

		private static void ExecuteDatabaseCreationScripts()
		{
			if (installoperations.InstallDatabase == false)
				return;

			// then create the databases according to the product we are installing
			// use scripting or any other tecnique you like

			MessageBox.Show("Database creation Script Executed");
		}

		private static void InstallSoftware()
		{
			if (installoperations.InstallSoftware == false)
				return;

			// extract the package embedded resource

			/* uncomment these lines to start you custom MSI */

			string[] installationPackages = System.IO.Directory.GetFiles(Application.StartupPath, "*.msi");
			for (int i = 0; i < installationPackages.Length; i++)
			{
				Process myProcess = new Process();
				myProcess.StartInfo.FileName = installationPackages[i];//<<Insert the path to your MSI file here>>
				myProcess.StartInfo.Arguments = ""; //<<Insert any command line parameters here>>
				myProcess.StartInfo.UseShellExecute = false;
				myProcess.Start();
				Process installp = Process.GetProcessById(myProcess.Id);
				if (installp != null)
					installp.WaitForExit();
			}

			MessageBox.Show("Software Installation Completed");
		}

	}
}
