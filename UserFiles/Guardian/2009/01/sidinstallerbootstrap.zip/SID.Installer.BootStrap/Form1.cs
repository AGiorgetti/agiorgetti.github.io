using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SID.Installer.BootStrap
{
	/// <summary>
	/// Descrizione di riepilogo per Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.CheckBox chkInstallDatabase;
		private System.Windows.Forms.CheckBox chlInstallSoftware;
		private System.Windows.Forms.Button btnNext;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.Button btnPrev;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnInstall;
		private System.Windows.Forms.RadioButton rbNewDBInstance;
		private System.Windows.Forms.RadioButton rbExistingDBInstance;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListBox lstExistingInstances;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtEngineRuntimePath;
		private System.Windows.Forms.TextBox txtEngineDataPath;
		private System.Windows.Forms.TextBox txtEngineInstanceName;
		private System.Windows.Forms.TextBox txtAdminPassword;
		private System.Windows.Forms.ListBox lstExistingInstances2;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.RadioButton rbIntegratedAutentication;
		private System.Windows.Forms.TextBox txtExistingAdminPassword;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtPort;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.RichTextBox rtbRecap;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txtExistingUsername;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.ErrorProvider errorProvider;
		private System.Windows.Forms.Button btnBrowseRuntimePath;
		private System.Windows.Forms.Button btnBrowseDataPath;
		private System.Windows.Forms.RadioButton rbUserPassword;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Codice generato da Progettazione Windows Form
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.chkInstallDatabase = new System.Windows.Forms.CheckBox();
			this.chlInstallSoftware = new System.Windows.Forms.CheckBox();
			this.btnNext = new System.Windows.Forms.Button();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.rbExistingDBInstance = new System.Windows.Forms.RadioButton();
			this.rbNewDBInstance = new System.Windows.Forms.RadioButton();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.txtAdminPassword = new System.Windows.Forms.TextBox();
			this.txtEngineInstanceName = new System.Windows.Forms.TextBox();
			this.txtEngineDataPath = new System.Windows.Forms.TextBox();
			this.txtEngineRuntimePath = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.lstExistingInstances = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.txtPort = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtExistingAdminPassword = new System.Windows.Forms.TextBox();
			this.rbUserPassword = new System.Windows.Forms.RadioButton();
			this.rbIntegratedAutentication = new System.Windows.Forms.RadioButton();
			this.lstExistingInstances2 = new System.Windows.Forms.ListBox();
			this.label6 = new System.Windows.Forms.Label();
			this.btnPrev = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnInstall = new System.Windows.Forms.Button();
			this.tabPage5 = new System.Windows.Forms.TabPage();
			this.rtbRecap = new System.Windows.Forms.RichTextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.txtExistingUsername = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.errorProvider = new System.Windows.Forms.ErrorProvider();
			this.btnBrowseRuntimePath = new System.Windows.Forms.Button();
			this.btnBrowseDataPath = new System.Windows.Forms.Button();
			this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.tabPage4.SuspendLayout();
			this.tabPage5.SuspendLayout();
			this.SuspendLayout();
			// 
			// chkInstallDatabase
			// 
			this.chkInstallDatabase.Location = new System.Drawing.Point(8, 8);
			this.chkInstallDatabase.Name = "chkInstallDatabase";
			this.chkInstallDatabase.Size = new System.Drawing.Size(164, 24);
			this.chkInstallDatabase.TabIndex = 0;
			this.chkInstallDatabase.Text = "Install Database";
			// 
			// chlInstallSoftware
			// 
			this.chlInstallSoftware.Checked = true;
			this.chlInstallSoftware.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chlInstallSoftware.Location = new System.Drawing.Point(8, 40);
			this.chlInstallSoftware.Name = "chlInstallSoftware";
			this.chlInstallSoftware.Size = new System.Drawing.Size(164, 24);
			this.chlInstallSoftware.TabIndex = 1;
			this.chlInstallSoftware.Text = "Install Software";
			// 
			// btnNext
			// 
			this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnNext.Location = new System.Drawing.Point(352, 232);
			this.btnNext.Name = "btnNext";
			this.btnNext.TabIndex = 2;
			this.btnNext.Text = "Next";
			this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage4);
			this.tabControl1.Controls.Add(this.tabPage5);
			this.tabControl1.Location = new System.Drawing.Point(0, -24);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(525, 220);
			this.tabControl1.TabIndex = 3;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.chlInstallSoftware);
			this.tabPage1.Controls.Add(this.chkInstallDatabase);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(517, 194);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Product Selection";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.rbExistingDBInstance);
			this.tabPage2.Controls.Add(this.rbNewDBInstance);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(517, 194);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Database Selection";
			// 
			// rbExistingDBInstance
			// 
			this.rbExistingDBInstance.Location = new System.Drawing.Point(8, 40);
			this.rbExistingDBInstance.Name = "rbExistingDBInstance";
			this.rbExistingDBInstance.Size = new System.Drawing.Size(196, 24);
			this.rbExistingDBInstance.TabIndex = 1;
			this.rbExistingDBInstance.Text = "Existing Database Instance";
			// 
			// rbNewDBInstance
			// 
			this.rbNewDBInstance.Checked = true;
			this.rbNewDBInstance.Location = new System.Drawing.Point(8, 8);
			this.rbNewDBInstance.Name = "rbNewDBInstance";
			this.rbNewDBInstance.Size = new System.Drawing.Size(196, 24);
			this.rbNewDBInstance.TabIndex = 0;
			this.rbNewDBInstance.TabStop = true;
			this.rbNewDBInstance.Text = "New Database Instance";
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.btnBrowseDataPath);
			this.tabPage3.Controls.Add(this.btnBrowseRuntimePath);
			this.tabPage3.Controls.Add(this.txtAdminPassword);
			this.tabPage3.Controls.Add(this.txtEngineInstanceName);
			this.tabPage3.Controls.Add(this.txtEngineDataPath);
			this.tabPage3.Controls.Add(this.txtEngineRuntimePath);
			this.tabPage3.Controls.Add(this.label5);
			this.tabPage3.Controls.Add(this.label4);
			this.tabPage3.Controls.Add(this.label3);
			this.tabPage3.Controls.Add(this.label2);
			this.tabPage3.Controls.Add(this.lstExistingInstances);
			this.tabPage3.Controls.Add(this.label1);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(517, 194);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "New Database";
			// 
			// txtAdminPassword
			// 
			this.errorProvider.SetIconAlignment(this.txtAdminPassword, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.txtAdminPassword.Location = new System.Drawing.Point(128, 160);
			this.txtAdminPassword.Name = "txtAdminPassword";
			this.txtAdminPassword.Size = new System.Drawing.Size(196, 20);
			this.txtAdminPassword.TabIndex = 9;
			this.txtAdminPassword.Text = "";
			// 
			// txtEngineInstanceName
			// 
			this.errorProvider.SetIconAlignment(this.txtEngineInstanceName, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.txtEngineInstanceName.Location = new System.Drawing.Point(128, 136);
			this.txtEngineInstanceName.Name = "txtEngineInstanceName";
			this.txtEngineInstanceName.Size = new System.Drawing.Size(196, 20);
			this.txtEngineInstanceName.TabIndex = 8;
			this.txtEngineInstanceName.Text = "";
			// 
			// txtEngineDataPath
			// 
			this.errorProvider.SetIconAlignment(this.txtEngineDataPath, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.txtEngineDataPath.Location = new System.Drawing.Point(128, 112);
			this.txtEngineDataPath.Name = "txtEngineDataPath";
			this.txtEngineDataPath.Size = new System.Drawing.Size(196, 20);
			this.txtEngineDataPath.TabIndex = 7;
			this.txtEngineDataPath.Text = "";
			// 
			// txtEngineRuntimePath
			// 
			this.errorProvider.SetIconAlignment(this.txtEngineRuntimePath, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.txtEngineRuntimePath.Location = new System.Drawing.Point(128, 88);
			this.txtEngineRuntimePath.Name = "txtEngineRuntimePath";
			this.txtEngineRuntimePath.Size = new System.Drawing.Size(196, 20);
			this.txtEngineRuntimePath.TabIndex = 6;
			this.txtEngineRuntimePath.Text = "";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(8, 164);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(89, 16);
			this.label5.TabIndex = 5;
			this.label5.Text = "Admin Password";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(8, 140);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(80, 16);
			this.label4.TabIndex = 4;
			this.label4.Text = "Instance Name";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(8, 116);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(93, 16);
			this.label3.TabIndex = 3;
			this.label3.Text = "Engine Data Path";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(8, 92);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(111, 16);
			this.label2.TabIndex = 2;
			this.label2.Text = "Engine Runtime Path";
			// 
			// lstExistingInstances
			// 
			this.lstExistingInstances.Location = new System.Drawing.Point(8, 28);
			this.lstExistingInstances.Name = "lstExistingInstances";
			this.lstExistingInstances.Size = new System.Drawing.Size(316, 56);
			this.lstExistingInstances.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(99, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Existing Instances:";
			// 
			// tabPage4
			// 
			this.tabPage4.Controls.Add(this.label9);
			this.tabPage4.Controls.Add(this.txtExistingUsername);
			this.tabPage4.Controls.Add(this.txtPort);
			this.tabPage4.Controls.Add(this.label7);
			this.tabPage4.Controls.Add(this.txtExistingAdminPassword);
			this.tabPage4.Controls.Add(this.rbUserPassword);
			this.tabPage4.Controls.Add(this.rbIntegratedAutentication);
			this.tabPage4.Controls.Add(this.lstExistingInstances2);
			this.tabPage4.Controls.Add(this.label6);
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Size = new System.Drawing.Size(517, 194);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Existing Database";
			// 
			// txtPort
			// 
			this.txtPort.Location = new System.Drawing.Point(44, 88);
			this.txtPort.Name = "txtPort";
			this.txtPort.TabIndex = 8;
			this.txtPort.Text = "";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(8, 92);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(25, 16);
			this.label7.TabIndex = 7;
			this.label7.Text = "Port";
			// 
			// txtExistingAdminPassword
			// 
			this.txtExistingAdminPassword.Location = new System.Drawing.Point(220, 148);
			this.txtExistingAdminPassword.Name = "txtExistingAdminPassword";
			this.txtExistingAdminPassword.Size = new System.Drawing.Size(104, 20);
			this.txtExistingAdminPassword.TabIndex = 6;
			this.txtExistingAdminPassword.Text = "";
			// 
			// rbUserPassword
			// 
			this.rbUserPassword.Location = new System.Drawing.Point(8, 148);
			this.rbUserPassword.Name = "rbUserPassword";
			this.rbUserPassword.Size = new System.Drawing.Size(80, 24);
			this.rbUserPassword.TabIndex = 5;
			this.rbUserPassword.Text = "Username";
			// 
			// rbIntegratedAutentication
			// 
			this.rbIntegratedAutentication.Checked = true;
			this.rbIntegratedAutentication.Location = new System.Drawing.Point(8, 116);
			this.rbIntegratedAutentication.Name = "rbIntegratedAutentication";
			this.rbIntegratedAutentication.Size = new System.Drawing.Size(152, 24);
			this.rbIntegratedAutentication.TabIndex = 4;
			this.rbIntegratedAutentication.TabStop = true;
			this.rbIntegratedAutentication.Text = "Integrated Autentication";
			// 
			// lstExistingInstances2
			// 
			this.lstExistingInstances2.Location = new System.Drawing.Point(8, 28);
			this.lstExistingInstances2.Name = "lstExistingInstances2";
			this.lstExistingInstances2.Size = new System.Drawing.Size(316, 56);
			this.lstExistingInstances2.TabIndex = 3;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(8, 8);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(99, 16);
			this.label6.TabIndex = 2;
			this.label6.Text = "Existing Instances:";
			// 
			// btnPrev
			// 
			this.btnPrev.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnPrev.Location = new System.Drawing.Point(268, 232);
			this.btnPrev.Name = "btnPrev";
			this.btnPrev.TabIndex = 4;
			this.btnPrev.Text = "Previous";
			this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnCancel.Location = new System.Drawing.Point(8, 232);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 5;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnInstall
			// 
			this.btnInstall.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnInstall.Location = new System.Drawing.Point(444, 232);
			this.btnInstall.Name = "btnInstall";
			this.btnInstall.TabIndex = 6;
			this.btnInstall.Text = "Install";
			this.btnInstall.Click += new System.EventHandler(this.btnInstall_Click);
			// 
			// tabPage5
			// 
			this.tabPage5.Controls.Add(this.label8);
			this.tabPage5.Controls.Add(this.rtbRecap);
			this.tabPage5.Location = new System.Drawing.Point(4, 22);
			this.tabPage5.Name = "tabPage5";
			this.tabPage5.Size = new System.Drawing.Size(517, 194);
			this.tabPage5.TabIndex = 4;
			this.tabPage5.Text = "Confirm Installation";
			// 
			// rtbRecap
			// 
			this.rtbRecap.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.rtbRecap.Location = new System.Drawing.Point(8, 32);
			this.rtbRecap.Name = "rtbRecap";
			this.rtbRecap.ReadOnly = true;
			this.rtbRecap.Size = new System.Drawing.Size(492, 152);
			this.rtbRecap.TabIndex = 0;
			this.rtbRecap.Text = "";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(8, 8);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(110, 16);
			this.label8.TabIndex = 1;
			this.label8.Text = "Installation Summary";
			// 
			// txtExistingUsername
			// 
			this.txtExistingUsername.Location = new System.Drawing.Point(88, 148);
			this.txtExistingUsername.Name = "txtExistingUsername";
			this.txtExistingUsername.Size = new System.Drawing.Size(92, 20);
			this.txtExistingUsername.TabIndex = 9;
			this.txtExistingUsername.Text = "";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(184, 152);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(29, 16);
			this.label9.TabIndex = 10;
			this.label9.Text = "Pass";
			// 
			// errorProvider
			// 
			this.errorProvider.ContainerControl = this;
			// 
			// btnBrowseRuntimePath
			// 
			this.btnBrowseRuntimePath.Location = new System.Drawing.Point(328, 88);
			this.btnBrowseRuntimePath.Name = "btnBrowseRuntimePath";
			this.btnBrowseRuntimePath.Size = new System.Drawing.Size(28, 20);
			this.btnBrowseRuntimePath.TabIndex = 10;
			this.btnBrowseRuntimePath.Text = "...";
			this.btnBrowseRuntimePath.Click += new System.EventHandler(this.btnBrowseRuntimePath_Click);
			// 
			// btnBrowseDataPath
			// 
			this.btnBrowseDataPath.Location = new System.Drawing.Point(328, 112);
			this.btnBrowseDataPath.Name = "btnBrowseDataPath";
			this.btnBrowseDataPath.Size = new System.Drawing.Size(28, 20);
			this.btnBrowseDataPath.TabIndex = 11;
			this.btnBrowseDataPath.Text = "...";
			this.btnBrowseDataPath.Click += new System.EventHandler(this.btnBrowseDataPath_Click);
			// 
			// folderBrowserDialog
			// 
			this.folderBrowserDialog.Description = "Select Folder";
			this.folderBrowserDialog.ShowNewFolderButton = false;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(524, 264);
			this.Controls.Add(this.btnInstall);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnPrev);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.btnNext);
			this.Name = "Form1";
			this.Text = "Application Installer";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			this.tabPage4.ResumeLayout(false);
			this.tabPage5.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private enum Page
		{
			Page1 = 0,
			Page2 = 1,
			Page3New = 2,
			Page3Existing = 3,
			Page4Confirm = 4
		}

		private enum ActionButton
		{
			Next = 0,
			Prev = 1,
			Install = 2
		}

		private Page mPage = Page.Page1;

		private InstallOperations mInstallOperations = new InstallOperations();
		/// <summary>
		/// contains the settings specified by the user
		/// </summary>
		public InstallOperations InstallOperations
		{
			get { return mInstallOperations; }
		}

		private void OpenCurrentPage()
		{
			tabControl1.SelectedIndex = (int)mPage;
			// house keeping
			switch (mPage)
			{
				case Page.Page1:
					btnPrev.Enabled = false;
					btnNext.Enabled = true;
					btnInstall.Enabled = false;
					break;
				case Page.Page2:
					btnPrev.Enabled = true;
					btnNext.Enabled = true;
					btnInstall.Enabled = false;
					break;
				case Page.Page3New:
					btnPrev.Enabled = true;
					btnNext.Enabled = true;
					btnInstall.Enabled = false;
					if (lstExistingInstances.DataSource == null)
						lstExistingInstances.DataSource = EmbeddedInstall.EnumSQLInstances();
					if (txtEngineRuntimePath.Text == "")
						txtEngineRuntimePath.Text = InstallOperations.EngineInstallationPath;
					if (txtEngineDataPath.Text == "")
						txtEngineDataPath.Text = InstallOperations.EngineDataPath;

					break;
				case Page.Page3Existing:
					btnPrev.Enabled = true;
					btnNext.Enabled = true;
					btnInstall.Enabled = false;
					if (lstExistingInstances2.DataSource == null)
						lstExistingInstances2.DataSource = EmbeddedInstall.EnumSQLInstances();

					break;
				case Page.Page4Confirm:
					btnPrev.Enabled = true;
					btnNext.Enabled = false;
					btnInstall.Enabled = true;

					AssignValues();
				
					DisplaySummary();

					break;
			}
		}

		private bool ValidateNewDatabase()
		{
			bool isValid = true;

			errorProvider.SetError(txtEngineRuntimePath, "");
			errorProvider.SetError(txtEngineDataPath, "");
			errorProvider.SetError(txtEngineInstanceName, "");
			errorProvider.SetError(txtAdminPassword, "");

			if (txtEngineRuntimePath.Text == "")
			{
				errorProvider.SetError(txtEngineRuntimePath, "Required.");
				isValid = false;
			}
			if (txtEngineDataPath.Text == "")
			{
				errorProvider.SetError(txtEngineDataPath, "Required.");
				isValid = false;
			}
			if (txtEngineInstanceName.Text == "")
			{
				errorProvider.SetError(txtEngineInstanceName, "Required.");
				isValid = false;
			}
			else
			{
				// must be different from an existing instance
				foreach (object o in (ArrayList)lstExistingInstances.DataSource)
				{
					EmbeddedInstall.SqlInstanceData d = (EmbeddedInstall.SqlInstanceData)o;
					if (string.Compare(d.Instance, txtEngineInstanceName.Text, true) == 0)
					{
						errorProvider.SetError(txtEngineInstanceName, "This instance already exists.");
						isValid = false;
						break;
					}
				}
			}
			if (txtAdminPassword.Text == "")
			{
				errorProvider.SetError(txtAdminPassword, "Required.");
				isValid = false;
			}			

			return isValid;
		}

		private bool ValidateExistingDataBase()
		{
			bool isValid = true;

			errorProvider.SetError(lstExistingInstances2, "");
			errorProvider.SetError(txtExistingUsername, "");
			errorProvider.SetError(txtExistingAdminPassword, "");
			
			if (lstExistingInstances2.SelectedItem == null)
			{
				errorProvider.SetError(lstExistingInstances2, "Select one.");
				isValid = false;
			}
			if (rbUserPassword.Checked == true)
			{
				if (txtExistingUsername.Text == "")
				{
					errorProvider.SetError(txtExistingUsername, "Required.");
					isValid = false;
				}	
				if (txtExistingAdminPassword.Text == "")
				{
					errorProvider.SetError(txtExistingAdminPassword, "Required.");
					isValid = false;
				}	
			}

			return isValid;
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			OpenCurrentPage();
		}

		private void DisplaySummary()
		{
			rtbRecap.Clear();
			if (InstallOperations.InstallDatabase)
			{
				if (InstallOperations.InstallDatabaseEngine)
				{
					rtbRecap.AppendText("Install Database Engine");
					rtbRecap.AppendText(Environment.NewLine);
					rtbRecap.AppendText("New Database Instance: " + InstallOperations.InstallationInstanceName);
				}
				else
				{
					rtbRecap.AppendText("Use Existing Database Instance: " + InstallOperations.ScriptInstance);
				}
				rtbRecap.AppendText(Environment.NewLine);
				rtbRecap.AppendText(Environment.NewLine);
				rtbRecap.AppendText("Create Database Data Files");
				rtbRecap.AppendText(Environment.NewLine);
				rtbRecap.AppendText(Environment.NewLine);
			}
			if (InstallOperations.InstallSoftware)
			{
				rtbRecap.AppendText("Install Software");
			}
			rtbRecap.Focus();
		}

		private void AssignValues()
		{
			InstallOperations.InstallDatabase = chkInstallDatabase.Checked;
			InstallOperations.InstallSoftware = chlInstallSoftware.Checked;
			InstallOperations.InstallDatabaseEngine = rbNewDBInstance.Checked;
			InstallOperations.EngineInstallationPath = txtEngineRuntimePath.Text;
			InstallOperations.EngineInstallationPath = txtEngineDataPath.Text;
			InstallOperations.InstallationInstanceName = txtEngineInstanceName.Text;
			InstallOperations.InstallationSaPassword = txtAdminPassword.Text;
			InstallOperations.IntegratedAuthentication = rbIntegratedAutentication.Checked;
			if (lstExistingInstances2.SelectedItem != null)
				InstallOperations.ScriptInstance = ((EmbeddedInstall.SqlInstanceData)lstExistingInstances2.SelectedItem).Instance;
			InstallOperations.ScriptUsername = txtExistingUsername.Text;
			InstallOperations.ScriptPassword = txtExistingAdminPassword.Text;
			InstallOperations.ScriptPort = txtPort.Text;
		}

		private void Wizard(ActionButton btn)
		{
			if (btn == ActionButton.Install)
			{
				// set the data InstallOptions Data and exit the dialog
				AssignValues();
				this.DialogResult = DialogResult.OK;
				this.Close();
			}
			Page NextPage = mPage;
			
			switch (mPage)
			{
				case Page.Page1:
					if (chkInstallDatabase.Checked)
						NextPage = Page.Page2;
					else
						NextPage = Page.Page4Confirm;
					break;
				case Page.Page2:
					if (btn == ActionButton.Prev)
						NextPage = Page.Page1;
					else
					{
						if (rbNewDBInstance.Checked)
							NextPage = Page.Page3New;
						else
							NextPage = Page.Page3Existing;
					}
					break;
				case Page.Page3Existing:
					if (btn == ActionButton.Prev)
						NextPage = Page.Page2;
					else
						if (ValidateExistingDataBase())
							NextPage = Page.Page4Confirm;
					break;
				case Page.Page3New:
					if (btn == ActionButton.Prev)
						NextPage = Page.Page2;
					else
						if (ValidateNewDatabase())
							NextPage = Page.Page4Confirm;
					break;
				case Page.Page4Confirm:
					if (chkInstallDatabase.Checked == false)
						NextPage = Page.Page1;
					else if (rbNewDBInstance.Checked)
						NextPage = Page.Page3New;
					else
						NextPage = Page.Page3Existing;
					break;
			}
			mPage = NextPage;
			OpenCurrentPage();			
		}

		private void btnPrev_Click(object sender, System.EventArgs e)
		{
			Wizard(ActionButton.Prev);
		}

		private void btnNext_Click(object sender, System.EventArgs e)
		{
			Wizard(ActionButton.Next);
		}

		private void btnInstall_Click(object sender, System.EventArgs e)
		{
			Wizard(ActionButton.Install);
		}

		private void btnBrowseRuntimePath_Click(object sender, System.EventArgs e)
		{
			folderBrowserDialog.SelectedPath = txtEngineRuntimePath.Text;
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				txtEngineRuntimePath.Text = folderBrowserDialog.SelectedPath;
			}
		}

		private void btnBrowseDataPath_Click(object sender, System.EventArgs e)
		{
			folderBrowserDialog.SelectedPath = txtEngineDataPath.Text;
			if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
			{
				txtEngineDataPath.Text = folderBrowserDialog.SelectedPath;
			}
		}

	}
}
