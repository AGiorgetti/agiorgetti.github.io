using System;
using System.Text;

namespace SID.Installer.BootStrap
{
   public class StringUtils
   {
      public static bool IsNullOrEmpty(string str)
		{
			return (str == null) || (str == string.Empty);
		}
   }
}
