﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Serialization;
using NUnit.Core;
using NUnit.Core.Extensibility;
using Structura.NUnitExtensions.Twitter.Utils;

namespace Structura.NUnitExtensions.Twitter
{
   /// <summary>
   /// send a twitter message using the account specified in the Twetter.config, this file must be deployed with the addin
   /// </summary>
   [NUnitAddin(Description = "Send a Twetter message whenever a test fails")]
   public class TwitterDecorator : IAddin, ITestDecorator
   {
      public TwitterAccount Account { get; set; }

      #region IAddin Members

      public bool Install(IExtensionHost host)
      {
         System.Diagnostics.Trace.WriteLine("TwetterDecorator: Install called");
         IExtensionPoint2 decorators = (IExtensionPoint2)host.GetExtensionPoint("TestDecorators");
         if (decorators == null) return false;
         decorators.Install(this, 9);

         // read the configuration
         string filepath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().CodeBase);
         filepath = Path.Combine(filepath, "Twitter.config").Replace("file:\\", "");
         Account = TwitterAccount.Load(filepath);

         return true;
      }

      #endregion

      #region ITestDecorator Members

      public Test Decorate(Test test, MemberInfo member)
      {
         System.Diagnostics.Trace.WriteLine("TwetterDecorator: decorate called");
         if (test is NUnitTestMethod)
         {
            test = new TwitterTestMethod(((NUnitTestMethod)test).Method, Account);
         }
         return test;
      }

      #endregion
   }

   public class TwitterTestMethod : NUnitTestMethod
   {
      public TwitterTestMethod(MethodInfo method, TwitterAccount account)
         : base(method)
      {
         Account = account;
      }

      public TwitterAccount Account { get; set; }

      public override void Run(TestResult testResult)
      {
         // let's run the test
         base.Run(testResult);
         // check for success or failure and send the twitter message
         // if (testResult.IsFailure)
         if (!testResult.IsSuccess)
         {
            string message = string.Empty;
            if (testResult.IsFailure)
               message = string.Format("{0} - Failure: {1} {2}", Account.Project, testResult.FullName, testResult.Message);
            if (testResult.IsError)
               message = string.Format("{0} - Error: {1} {2}", Account.Project, testResult.FullName, testResult.Message);

            TwitterService twitter = new TwitterService();
            twitter.SendMessage(Account.Username, Account.Password, message);
         }
      }
   }

   public class TwitterAccount
   {
      public string Username { get; set; }
      public string Password { get; set; }
      public string Project { get; set; }

      public static TwitterAccount Load(string filename)
      {
         XmlSerializer ser = new XmlSerializer(typeof(TwitterAccount));
         using (StreamReader sr = new StreamReader(filename))
            return (TwitterAccount)ser.Deserialize(sr);
      }
   }
}
