<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DisplayFrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.ValueTxt = New System.Windows.Forms.TextBox
		Me.OKBtn = New System.Windows.Forms.Button
		Me.SuspendLayout()
		'
		'ValueTxt
		'
		Me.ValueTxt.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
								Or System.Windows.Forms.AnchorStyles.Left) _
								Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.ValueTxt.Location = New System.Drawing.Point(0, 1)
		Me.ValueTxt.Multiline = True
		Me.ValueTxt.Name = "ValueTxt"
		Me.ValueTxt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.ValueTxt.Size = New System.Drawing.Size(298, 142)
		Me.ValueTxt.TabIndex = 0
		'
		'OKBtn
		'
		Me.OKBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.OKBtn.Location = New System.Drawing.Point(223, 149)
		Me.OKBtn.Name = "OKBtn"
		Me.OKBtn.Size = New System.Drawing.Size(75, 23)
		Me.OKBtn.TabIndex = 1
		Me.OKBtn.Text = "OK"
		Me.OKBtn.UseVisualStyleBackColor = True
		'
		'DisplayFrm
		'
		Me.AcceptButton = Me.OKBtn
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(300, 174)
		Me.Controls.Add(Me.OKBtn)
		Me.Controls.Add(Me.ValueTxt)
		Me.Name = "DisplayFrm"
		Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "DisplayFrm"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents ValueTxt As System.Windows.Forms.TextBox
	Friend WithEvents OKBtn As System.Windows.Forms.Button
End Class
