<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MemberFrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.MemberGrp = New System.Windows.Forms.GroupBox
		Me.GroupBox2 = New System.Windows.Forms.GroupBox
		Me.FindBtn = New System.Windows.Forms.Button
		Me.FindUserTxt = New System.Windows.Forms.TextBox
		Me.Label12 = New System.Windows.Forms.Label
		Me.UniChk = New System.Windows.Forms.CheckBox
		Me.GroupBox1 = New System.Windows.Forms.GroupBox
		Me.GetPropsBtn = New System.Windows.Forms.Button
		Me.ChangePwdBtn = New System.Windows.Forms.Button
		Me.NewPwdTxt = New System.Windows.Forms.TextBox
		Me.Label11 = New System.Windows.Forms.Label
		Me.OldPwdTxt = New System.Windows.Forms.TextBox
		Me.Label10 = New System.Windows.Forms.Label
		Me.UserNameTxt = New System.Windows.Forms.TextBox
		Me.Label9 = New System.Windows.Forms.Label
		Me.Delete = New System.Windows.Forms.Button
		Me.DomTxt = New System.Windows.Forms.TextBox
		Me.Label4 = New System.Windows.Forms.Label
		Me.NumUsers = New System.Windows.Forms.NumericUpDown
		Me.Label3 = New System.Windows.Forms.Label
		Me.PwdTxt = New System.Windows.Forms.TextBox
		Me.Label2 = New System.Windows.Forms.Label
		Me.CreateUserBtn = New System.Windows.Forms.Button
		Me.PrefixTxt = New System.Windows.Forms.TextBox
		Me.Label1 = New System.Windows.Forms.Label
		Me.RoleGrp = New System.Windows.Forms.GroupBox
		Me.UniAddChk = New System.Windows.Forms.CheckBox
		Me.DeleteRoleBtn = New System.Windows.Forms.Button
		Me.GetRolesBtn = New System.Windows.Forms.Button
		Me.GetUsersBtn = New System.Windows.Forms.Button
		Me.StartNum = New System.Windows.Forms.NumericUpDown
		Me.Label8 = New System.Windows.Forms.Label
		Me.AddToRoleBtn = New System.Windows.Forms.Button
		Me.NumRoleUsers = New System.Windows.Forms.NumericUpDown
		Me.Label7 = New System.Windows.Forms.Label
		Me.RolePrefixTxt = New System.Windows.Forms.TextBox
		Me.Label6 = New System.Windows.Forms.Label
		Me.CreateRoleBtn = New System.Windows.Forms.Button
		Me.RoleTxt = New System.Windows.Forms.TextBox
		Me.Label5 = New System.Windows.Forms.Label
		Me.PBar = New System.Windows.Forms.ProgressBar
		Me.ConfigBtn = New System.Windows.Forms.Button
		Me.MemberGrp.SuspendLayout()
		Me.GroupBox2.SuspendLayout()
		Me.GroupBox1.SuspendLayout()
		CType(Me.NumUsers, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.RoleGrp.SuspendLayout()
		CType(Me.StartNum, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.NumRoleUsers, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'MemberGrp
		'
		Me.MemberGrp.Controls.Add(Me.GroupBox2)
		Me.MemberGrp.Controls.Add(Me.UniChk)
		Me.MemberGrp.Controls.Add(Me.GroupBox1)
		Me.MemberGrp.Controls.Add(Me.Delete)
		Me.MemberGrp.Controls.Add(Me.DomTxt)
		Me.MemberGrp.Controls.Add(Me.Label4)
		Me.MemberGrp.Controls.Add(Me.NumUsers)
		Me.MemberGrp.Controls.Add(Me.Label3)
		Me.MemberGrp.Controls.Add(Me.PwdTxt)
		Me.MemberGrp.Controls.Add(Me.Label2)
		Me.MemberGrp.Controls.Add(Me.CreateUserBtn)
		Me.MemberGrp.Controls.Add(Me.PrefixTxt)
		Me.MemberGrp.Controls.Add(Me.Label1)
		Me.MemberGrp.Location = New System.Drawing.Point(5, 28)
		Me.MemberGrp.Name = "MemberGrp"
		Me.MemberGrp.Size = New System.Drawing.Size(333, 296)
		Me.MemberGrp.TabIndex = 1
		Me.MemberGrp.TabStop = False
		Me.MemberGrp.Text = "Membership"
		'
		'GroupBox2
		'
		Me.GroupBox2.Controls.Add(Me.FindBtn)
		Me.GroupBox2.Controls.Add(Me.FindUserTxt)
		Me.GroupBox2.Controls.Add(Me.Label12)
		Me.GroupBox2.Location = New System.Drawing.Point(9, 237)
		Me.GroupBox2.Name = "GroupBox2"
		Me.GroupBox2.Size = New System.Drawing.Size(314, 51)
		Me.GroupBox2.TabIndex = 23
		Me.GroupBox2.TabStop = False
		Me.GroupBox2.Text = "Find User"
		'
		'FindBtn
		'
		Me.FindBtn.Location = New System.Drawing.Point(183, 15)
		Me.FindBtn.Name = "FindBtn"
		Me.FindBtn.Size = New System.Drawing.Size(89, 23)
		Me.FindBtn.TabIndex = 2
		Me.FindBtn.Text = "Find..."
		Me.FindBtn.UseVisualStyleBackColor = True
		'
		'FindUserTxt
		'
		Me.FindUserTxt.Location = New System.Drawing.Point(42, 17)
		Me.FindUserTxt.Name = "FindUserTxt"
		Me.FindUserTxt.Size = New System.Drawing.Size(134, 20)
		Me.FindUserTxt.TabIndex = 1
		Me.FindUserTxt.Text = "user"
		'
		'Label12
		'
		Me.Label12.AutoSize = True
		Me.Label12.Location = New System.Drawing.Point(8, 20)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(38, 13)
		Me.Label12.TabIndex = 0
		Me.Label12.Text = "Name:"
		'
		'UniChk
		'
		Me.UniChk.AutoSize = True
		Me.UniChk.Location = New System.Drawing.Point(7, 80)
		Me.UniChk.Name = "UniChk"
		Me.UniChk.Size = New System.Drawing.Size(297, 17)
		Me.UniChk.TabIndex = 4
		Me.UniChk.Text = "Only create or delete 1 user; don't use the # of Users field"
		Me.UniChk.UseVisualStyleBackColor = True
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.Add(Me.GetPropsBtn)
		Me.GroupBox1.Controls.Add(Me.ChangePwdBtn)
		Me.GroupBox1.Controls.Add(Me.NewPwdTxt)
		Me.GroupBox1.Controls.Add(Me.Label11)
		Me.GroupBox1.Controls.Add(Me.OldPwdTxt)
		Me.GroupBox1.Controls.Add(Me.Label10)
		Me.GroupBox1.Controls.Add(Me.UserNameTxt)
		Me.GroupBox1.Controls.Add(Me.Label9)
		Me.GroupBox1.Location = New System.Drawing.Point(8, 131)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(315, 100)
		Me.GroupBox1.TabIndex = 22
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Password and Properties"
		'
		'GetPropsBtn
		'
		Me.GetPropsBtn.Location = New System.Drawing.Point(184, 48)
		Me.GetPropsBtn.Name = "GetPropsBtn"
		Me.GetPropsBtn.Size = New System.Drawing.Size(89, 23)
		Me.GetPropsBtn.TabIndex = 4
		Me.GetPropsBtn.Text = "Get Properties"
		Me.GetPropsBtn.UseVisualStyleBackColor = True
		'
		'ChangePwdBtn
		'
		Me.ChangePwdBtn.Location = New System.Drawing.Point(184, 19)
		Me.ChangePwdBtn.Name = "ChangePwdBtn"
		Me.ChangePwdBtn.Size = New System.Drawing.Size(89, 23)
		Me.ChangePwdBtn.TabIndex = 3
		Me.ChangePwdBtn.Text = "Change Pwd"
		Me.ChangePwdBtn.UseVisualStyleBackColor = True
		'
		'NewPwdTxt
		'
		Me.NewPwdTxt.Location = New System.Drawing.Point(77, 71)
		Me.NewPwdTxt.Name = "NewPwdTxt"
		Me.NewPwdTxt.Size = New System.Drawing.Size(100, 20)
		Me.NewPwdTxt.TabIndex = 2
		Me.NewPwdTxt.Text = "some!pass"
		'
		'Label11
		'
		Me.Label11.AutoSize = True
		Me.Label11.Location = New System.Drawing.Point(6, 74)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(75, 13)
		Me.Label11.TabIndex = 18
		Me.Label11.Text = "Old Password:"
		'
		'OldPwdTxt
		'
		Me.OldPwdTxt.Location = New System.Drawing.Point(77, 45)
		Me.OldPwdTxt.Name = "OldPwdTxt"
		Me.OldPwdTxt.Size = New System.Drawing.Size(100, 20)
		Me.OldPwdTxt.TabIndex = 1
		Me.OldPwdTxt.Text = "!Passw0rd"
		'
		'Label10
		'
		Me.Label10.AutoSize = True
		Me.Label10.Location = New System.Drawing.Point(6, 48)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(75, 13)
		Me.Label10.TabIndex = 16
		Me.Label10.Text = "Old Password:"
		'
		'UserNameTxt
		'
		Me.UserNameTxt.Location = New System.Drawing.Point(77, 19)
		Me.UserNameTxt.Name = "UserNameTxt"
		Me.UserNameTxt.Size = New System.Drawing.Size(100, 20)
		Me.UserNameTxt.TabIndex = 0
		Me.UserNameTxt.Text = "user1"
		'
		'Label9
		'
		Me.Label9.AutoSize = True
		Me.Label9.Location = New System.Drawing.Point(49, 22)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(32, 13)
		Me.Label9.TabIndex = 13
		Me.Label9.Text = "User:"
		'
		'Delete
		'
		Me.Delete.Location = New System.Drawing.Point(251, 104)
		Me.Delete.Name = "Delete"
		Me.Delete.Size = New System.Drawing.Size(75, 23)
		Me.Delete.TabIndex = 6
		Me.Delete.Text = "Delete"
		Me.Delete.UseVisualStyleBackColor = True
		'
		'DomTxt
		'
		Me.DomTxt.Location = New System.Drawing.Point(66, 55)
		Me.DomTxt.Name = "DomTxt"
		Me.DomTxt.Size = New System.Drawing.Size(100, 20)
		Me.DomTxt.TabIndex = 2
		Me.DomTxt.Text = "contoso.com"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Location = New System.Drawing.Point(3, 58)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(64, 13)
		Me.Label4.TabIndex = 19
		Me.Label4.Text = "Email Suffix:"
		'
		'NumUsers
		'
		Me.NumUsers.Location = New System.Drawing.Point(226, 55)
		Me.NumUsers.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
		Me.NumUsers.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
		Me.NumUsers.Name = "NumUsers"
		Me.NumUsers.Size = New System.Drawing.Size(100, 20)
		Me.NumUsers.TabIndex = 3
		Me.NumUsers.Value = New Decimal(New Integer() {50, 0, 0, 0})
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Location = New System.Drawing.Point(169, 58)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(59, 13)
		Me.Label3.TabIndex = 16
		Me.Label3.Text = "# of Users:"
		'
		'PwdTxt
		'
		Me.PwdTxt.Location = New System.Drawing.Point(223, 25)
		Me.PwdTxt.Name = "PwdTxt"
		Me.PwdTxt.Size = New System.Drawing.Size(100, 20)
		Me.PwdTxt.TabIndex = 1
		Me.PwdTxt.Text = "!Passw0rd"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Location = New System.Drawing.Point(172, 28)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(56, 13)
		Me.Label2.TabIndex = 14
		Me.Label2.Text = "Password:"
		'
		'CreateUserBtn
		'
		Me.CreateUserBtn.Location = New System.Drawing.Point(168, 104)
		Me.CreateUserBtn.Name = "CreateUserBtn"
		Me.CreateUserBtn.Size = New System.Drawing.Size(75, 23)
		Me.CreateUserBtn.TabIndex = 5
		Me.CreateUserBtn.Text = "Create"
		Me.CreateUserBtn.UseVisualStyleBackColor = True
		'
		'PrefixTxt
		'
		Me.PrefixTxt.Location = New System.Drawing.Point(66, 25)
		Me.PrefixTxt.Name = "PrefixTxt"
		Me.PrefixTxt.Size = New System.Drawing.Size(100, 20)
		Me.PrefixTxt.TabIndex = 0
		Me.PrefixTxt.Text = "user"
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Location = New System.Drawing.Point(6, 28)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(61, 13)
		Me.Label1.TabIndex = 11
		Me.Label1.Text = "User Prefix:"
		'
		'RoleGrp
		'
		Me.RoleGrp.Controls.Add(Me.UniAddChk)
		Me.RoleGrp.Controls.Add(Me.DeleteRoleBtn)
		Me.RoleGrp.Controls.Add(Me.GetRolesBtn)
		Me.RoleGrp.Controls.Add(Me.GetUsersBtn)
		Me.RoleGrp.Controls.Add(Me.StartNum)
		Me.RoleGrp.Controls.Add(Me.Label8)
		Me.RoleGrp.Controls.Add(Me.AddToRoleBtn)
		Me.RoleGrp.Controls.Add(Me.NumRoleUsers)
		Me.RoleGrp.Controls.Add(Me.Label7)
		Me.RoleGrp.Controls.Add(Me.RolePrefixTxt)
		Me.RoleGrp.Controls.Add(Me.Label6)
		Me.RoleGrp.Controls.Add(Me.CreateRoleBtn)
		Me.RoleGrp.Controls.Add(Me.RoleTxt)
		Me.RoleGrp.Controls.Add(Me.Label5)
		Me.RoleGrp.Location = New System.Drawing.Point(364, 28)
		Me.RoleGrp.Name = "RoleGrp"
		Me.RoleGrp.Size = New System.Drawing.Size(333, 160)
		Me.RoleGrp.TabIndex = 2
		Me.RoleGrp.TabStop = False
		Me.RoleGrp.Text = "Roles"
		'
		'UniAddChk
		'
		Me.UniAddChk.AutoSize = True
		Me.UniAddChk.Location = New System.Drawing.Point(14, 131)
		Me.UniAddChk.Name = "UniAddChk"
		Me.UniAddChk.Size = New System.Drawing.Size(241, 17)
		Me.UniAddChk.TabIndex = 22
		Me.UniAddChk.Text = "Only add 1 user; don't use the # of Users field"
		Me.UniAddChk.UseVisualStyleBackColor = True
		'
		'DeleteRoleBtn
		'
		Me.DeleteRoleBtn.Location = New System.Drawing.Point(248, 33)
		Me.DeleteRoleBtn.Name = "DeleteRoleBtn"
		Me.DeleteRoleBtn.Size = New System.Drawing.Size(75, 20)
		Me.DeleteRoleBtn.TabIndex = 5
		Me.DeleteRoleBtn.Text = "Delete"
		Me.DeleteRoleBtn.UseVisualStyleBackColor = True
		'
		'GetRolesBtn
		'
		Me.GetRolesBtn.Location = New System.Drawing.Point(248, 56)
		Me.GetRolesBtn.Name = "GetRolesBtn"
		Me.GetRolesBtn.Size = New System.Drawing.Size(75, 20)
		Me.GetRolesBtn.TabIndex = 6
		Me.GetRolesBtn.Text = "Get Roles"
		Me.GetRolesBtn.UseVisualStyleBackColor = True
		'
		'GetUsersBtn
		'
		Me.GetUsersBtn.Location = New System.Drawing.Point(248, 79)
		Me.GetUsersBtn.Name = "GetUsersBtn"
		Me.GetUsersBtn.Size = New System.Drawing.Size(75, 20)
		Me.GetUsersBtn.TabIndex = 7
		Me.GetUsersBtn.Text = "Get Users"
		Me.GetUsersBtn.UseVisualStyleBackColor = True
		'
		'StartNum
		'
		Me.StartNum.Location = New System.Drawing.Point(68, 101)
		Me.StartNum.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
		Me.StartNum.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
		Me.StartNum.Name = "StartNum"
		Me.StartNum.Size = New System.Drawing.Size(100, 20)
		Me.StartNum.TabIndex = 3
		Me.StartNum.Value = New Decimal(New Integer() {5, 0, 0, 0})
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.Location = New System.Drawing.Point(10, 107)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(57, 13)
		Me.Label8.TabIndex = 21
		Me.Label8.Text = "Start Num:"
		'
		'AddToRoleBtn
		'
		Me.AddToRoleBtn.Location = New System.Drawing.Point(248, 102)
		Me.AddToRoleBtn.Name = "AddToRoleBtn"
		Me.AddToRoleBtn.Size = New System.Drawing.Size(75, 20)
		Me.AddToRoleBtn.TabIndex = 8
		Me.AddToRoleBtn.Text = "Add to Role"
		Me.AddToRoleBtn.UseVisualStyleBackColor = True
		'
		'NumRoleUsers
		'
		Me.NumRoleUsers.Location = New System.Drawing.Point(68, 75)
		Me.NumRoleUsers.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
		Me.NumRoleUsers.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
		Me.NumRoleUsers.Name = "NumRoleUsers"
		Me.NumRoleUsers.Size = New System.Drawing.Size(100, 20)
		Me.NumRoleUsers.TabIndex = 2
		Me.NumRoleUsers.Value = New Decimal(New Integer() {10, 0, 0, 0})
		'
		'Label7
		'
		Me.Label7.AutoSize = True
		Me.Label7.Location = New System.Drawing.Point(11, 82)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(59, 13)
		Me.Label7.TabIndex = 18
		Me.Label7.Text = "# of Users:"
		'
		'RolePrefixTxt
		'
		Me.RolePrefixTxt.Location = New System.Drawing.Point(68, 49)
		Me.RolePrefixTxt.Name = "RolePrefixTxt"
		Me.RolePrefixTxt.Size = New System.Drawing.Size(100, 20)
		Me.RolePrefixTxt.TabIndex = 1
		Me.RolePrefixTxt.Text = "user"
		'
		'Label6
		'
		Me.Label6.AutoSize = True
		Me.Label6.Location = New System.Drawing.Point(6, 56)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(61, 13)
		Me.Label6.TabIndex = 13
		Me.Label6.Text = "User Prefix:"
		'
		'CreateRoleBtn
		'
		Me.CreateRoleBtn.Location = New System.Drawing.Point(248, 10)
		Me.CreateRoleBtn.Name = "CreateRoleBtn"
		Me.CreateRoleBtn.Size = New System.Drawing.Size(75, 20)
		Me.CreateRoleBtn.TabIndex = 4
		Me.CreateRoleBtn.Text = "Create"
		Me.CreateRoleBtn.UseVisualStyleBackColor = True
		'
		'RoleTxt
		'
		Me.RoleTxt.Location = New System.Drawing.Point(68, 23)
		Me.RoleTxt.Name = "RoleTxt"
		Me.RoleTxt.Size = New System.Drawing.Size(175, 20)
		Me.RoleTxt.TabIndex = 0
		Me.RoleTxt.Text = "My New Role"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Location = New System.Drawing.Point(35, 26)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(32, 13)
		Me.Label5.TabIndex = 0
		Me.Label5.Text = "Role:"
		'
		'PBar
		'
		Me.PBar.Location = New System.Drawing.Point(5, 330)
		Me.PBar.Minimum = 1
		Me.PBar.Name = "PBar"
		Me.PBar.Size = New System.Drawing.Size(692, 23)
		Me.PBar.TabIndex = 19
		Me.PBar.Value = 1
		Me.PBar.Visible = False
		'
		'ConfigBtn
		'
		Me.ConfigBtn.Location = New System.Drawing.Point(254, 5)
		Me.ConfigBtn.Name = "ConfigBtn"
		Me.ConfigBtn.Size = New System.Drawing.Size(75, 23)
		Me.ConfigBtn.TabIndex = 0
		Me.ConfigBtn.Text = "Configure..."
		Me.ConfigBtn.UseVisualStyleBackColor = True
		'
		'MemberFrm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(705, 357)
		Me.Controls.Add(Me.ConfigBtn)
		Me.Controls.Add(Me.PBar)
		Me.Controls.Add(Me.RoleGrp)
		Me.Controls.Add(Me.MemberGrp)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
		Me.MaximizeBox = False
		Me.Name = "MemberFrm"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "ASP.NET Membership Form"
		Me.MemberGrp.ResumeLayout(False)
		Me.MemberGrp.PerformLayout()
		Me.GroupBox2.ResumeLayout(False)
		Me.GroupBox2.PerformLayout()
		Me.GroupBox1.ResumeLayout(False)
		Me.GroupBox1.PerformLayout()
		CType(Me.NumUsers, System.ComponentModel.ISupportInitialize).EndInit()
		Me.RoleGrp.ResumeLayout(False)
		Me.RoleGrp.PerformLayout()
		CType(Me.StartNum, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.NumRoleUsers, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents MemberGrp As System.Windows.Forms.GroupBox
	Friend WithEvents DomTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents NumUsers As System.Windows.Forms.NumericUpDown
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents PwdTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents CreateUserBtn As System.Windows.Forms.Button
	Friend WithEvents PrefixTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents RoleGrp As System.Windows.Forms.GroupBox
	Friend WithEvents CreateRoleBtn As System.Windows.Forms.Button
	Friend WithEvents RoleTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents StartNum As System.Windows.Forms.NumericUpDown
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents AddToRoleBtn As System.Windows.Forms.Button
	Friend WithEvents NumRoleUsers As System.Windows.Forms.NumericUpDown
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents RolePrefixTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents PBar As System.Windows.Forms.ProgressBar
	Friend WithEvents GetUsersBtn As System.Windows.Forms.Button
	Friend WithEvents GetRolesBtn As System.Windows.Forms.Button
	Friend WithEvents DeleteRoleBtn As System.Windows.Forms.Button
	Friend WithEvents Delete As System.Windows.Forms.Button
	Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Friend WithEvents UserNameTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents NewPwdTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents OldPwdTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents ChangePwdBtn As System.Windows.Forms.Button
	Friend WithEvents GetPropsBtn As System.Windows.Forms.Button
	Friend WithEvents UniChk As System.Windows.Forms.CheckBox
	Friend WithEvents ConfigBtn As System.Windows.Forms.Button
	Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
	Friend WithEvents FindUserTxt As System.Windows.Forms.TextBox
	Friend WithEvents Label12 As System.Windows.Forms.Label
	Friend WithEvents FindBtn As System.Windows.Forms.Button
	Friend WithEvents UniAddChk As System.Windows.Forms.CheckBox

End Class
