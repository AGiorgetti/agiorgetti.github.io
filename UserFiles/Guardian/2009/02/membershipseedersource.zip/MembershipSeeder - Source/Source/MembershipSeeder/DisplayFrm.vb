Public Class DisplayFrm


	Public Property Title() As String
		Get
			Return Me.Text
		End Get
		Set(ByVal value As String)
			Me.Text = value
		End Set
	End Property

	Public WriteOnly Property Value() As String
		Set(ByVal value As String)
			ValueTxt.Text = value
		End Set
	End Property


	Private Sub OKBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKBtn.Click
		Me.Close()
	End Sub

End Class