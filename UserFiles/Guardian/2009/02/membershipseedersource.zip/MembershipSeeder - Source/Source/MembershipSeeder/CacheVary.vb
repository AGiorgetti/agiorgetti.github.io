Imports Microsoft.SharePoint.ApplicationRuntime


Public Class CacheVary
	Implements IVaryByCustomHandler


	Public Function GetVaryByCustomString(ByVal app As System.Web.HttpApplication, ByVal context As System.Web.HttpContext, ByVal custom As String) As String Implements Microsoft.SharePoint.ApplicationRuntime.IVaryByCustomHandler.GetVaryByCustomString

		Dim foo As New SPHttpApplication
		foo.RegisterGetVaryByCustomStringHandler(Me)
		Return "monkey"


	End Function

End Class
