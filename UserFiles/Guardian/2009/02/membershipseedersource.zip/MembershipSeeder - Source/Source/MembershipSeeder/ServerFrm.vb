Public Class ServerFrm


	Public Enum SqlAuthType
		Windows
		SQL
	End Enum


	Private mConStr As String = String.Empty
	Public Property ConnectionString() As String
		Get
			Return mConStr
		End Get
		Set(ByVal value As String)
			mConStr = value
		End Set
	End Property


	Public Property Server() As String
		Get
			Return ServerTxt.Text
		End Get
		Set(ByVal value As String)
			ServerTxt.Text = value
		End Set
	End Property

	Public Property Database() As String
		Get
			Return DatabaseTxt.Text
		End Get
		Set(ByVal value As String)
			DatabaseTxt.Text = value
		End Set
	End Property


	'Public Property AuthenticationType() As SqlAuthType
	'	Get
	'		If WinOpt.Checked Then
	'			Return SqlAuthType.Windows
	'		Else
	'			Return SqlAuthType.SQL
	'		End If
	'	End Get
	'	Set(ByVal value As SqlAuthType)
	'		If value = SqlAuthType.SQL Then
	'			SqlOpt.Checked = True
	'		Else
	'			WinOpt.Checked = True
	'		End If
	'	End Set
	'End Property


	'Public Property SqlUserName() As String
	'	Get
	'		Return UserTxt.Text
	'	End Get
	'	Set(ByVal value As String)
	'		UserTxt.Text = value
	'	End Set
	'End Property


	'Public Property SqlPassword() As String
	'	Get
	'		Return PwdTxt.Text
	'	End Get
	'	Set(ByVal value As String)
	'		PwdTxt.Text = value
	'	End Set
	'End Property

	Private Sub OKBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKBtn.Click
		ConnectionString = "server=" & Server & "; database=" & Database & "; Trusted_Connection=True"
		Me.Close()
	End Sub

	Private Sub CancelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
		mConStr = ""
		Me.Close()
	End Sub

	Private Sub ServerFrm_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
		If Me.Visible Then
			If String.IsNullOrEmpty(Server) Then Server = Environment.MachineName
		End If
	End Sub

End Class