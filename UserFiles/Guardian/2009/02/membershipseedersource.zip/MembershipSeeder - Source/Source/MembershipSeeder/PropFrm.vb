Imports System.Web
Imports System.Web.Security
Imports System.Web.Profile
Imports System.Configuration


Public Class PropFrm

	Private dt As New DataTable


	Public Property AccountName() As String
		Get
			Return UserLbl.Text
		End Get
		Set(ByVal value As String)
			UserLbl.Text = value
		End Set
	End Property


	Private Sub PropFrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

		Dim props As SettingsPropertyCollection = Nothing
		Dim vals As SettingsPropertyValueCollection = Nothing
		Dim ctx As SettingsContext = Nothing
		Dim dr As DataRow = Nothing

		Try
			'get all the properties
			props = System.Web.Profile.DefaultProfile.Properties

			'get an settings context
			ctx = New SettingsContext()
			ctx("UserName") = AccountName
			ctx("IsAuthenticated") = True

			'get the property values
			vals = ProfileManager.Provider.GetPropertyValues(ctx, props)

			'create the recordset
			dt.Columns.Add("PropertyName", GetType(String))
			dt.Columns.Add("PropertyValue", GetType(String))

			For Each prop As SettingsProperty In props
				dr = dt.NewRow
				dr.Item("PropertyName") = prop.Name
				dr.Item("PropertyValue") = vals(prop.Name).PropertyValue.ToString()
				dt.Rows.Add(dr)
			Next

			'plug the data into the grid
			PropGrd.DataSource = dt
		Catch ex As Exception
			MessageBox.Show("Error getting properties: " & ex.Message)
		End Try

	End Sub


	Private Sub UpdateBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateBtn.Click

		Dim vals As SettingsPropertyValueCollection = Nothing
		Dim val As SettingsProperty = Nothing
		Dim data As SettingsPropertyValue = Nothing
		Dim ctx As SettingsContext = Nothing
		Dim dr As DataRow = Nothing

		Try
			'get an settings context
			ctx = New SettingsContext()
			ctx("UserName") = AccountName
			ctx("IsAuthenticated") = True

			''create a collection of property values
			vals = ProfileManager.Provider.GetPropertyValues(ctx, _
			 System.Web.Profile.DefaultProfile.Properties)

			'run through each row and grab the data
			For Each row As DataGridViewRow In PropGrd.Rows
				vals(row.Cells(0).Value.ToString()).PropertyValue = row.Cells(1).Value
			Next

			'now try updating
			ProfileManager.Provider.SetPropertyValues(ctx, vals)
			MessageBox.Show("The properties were updated.")

		Catch ex As Exception
			MessageBox.Show("Error setting properties: " & ex.Message)
		End Try

	End Sub

End Class