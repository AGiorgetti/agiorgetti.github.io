Imports System.Web.Security
Imports System.Xml
Imports System.Security
Imports System.Security.Cryptography
Imports System.Security.Cryptography.Xml
Imports System.Configuration


Public Class MemberFrm

	Private Sub MemberFrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		DomTxt.Text = System.Environment.GetEnvironmentVariable("USERDNSDOMAIN")
	End Sub


	Private Sub CreateUserBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateUserBtn.Click

		Dim userStatus As MembershipCreateStatus
		Dim newUser As MembershipUser
		Dim userName As String = String.Empty

		Dim badStatus As String = String.Empty
		Dim badCnt As Integer = 0
		Dim temp As String = String.Empty
		Dim frm As New DisplayFrm

		Try
			'enumerate through and add users if we're doing multiple
			If Not UniChk.Checked Then
				'setup progress bar
				PBar.Maximum = NumUsers.Value
				PBar.Visible = True

				For cnt As Integer = 1 To NumUsers.Value
					'increment progress bar
					PBar.Value = cnt

					'create the user
					userName = PrefixTxt.Text & cnt.ToString
					newUser = Membership.CreateUser(userName, PwdTxt.Text, userName & "@" & DomTxt.Text, _
					 "YourDog", "Fido", True, userStatus)

					'check the status
					If userStatus <> MembershipCreateStatus.Success Then
						badCnt += 1
						badStatus += "User " & userName & " failed with status " & userStatus.ToString() & _
						 ControlChars.CrLf
					End If

				Next

				'hide progress bar
				PBar.Visible = False
			Else
				'just create one user
				newUser = Membership.CreateUser(PrefixTxt.Text, PwdTxt.Text, userName & "@" & DomTxt.Text, _
				 "YourDog", "Fido", True, userStatus)
			End If

		Catch ex As Exception
			MessageBox.Show("There was an error trying to create a user: " & ex.Message, "Membership Error", _
			 MessageBoxButtons.OK, MessageBoxIcon.Error)
			PBar.Visible = False
			Exit Sub
		End Try

		If badCnt = 0 Then
			MessageBox.Show("All users were added successfully.", "Members Added", _
			 MessageBoxButtons.OK, MessageBoxIcon.Information)
		Else
			If badCnt = NumUsers.Value Then
				temp = "No users were added. "
			Else
				temp = badCnt.ToString & " were not added because of errors. "
			End If
			frm.Title = "Error Creating Users"
			frm.Value = temp & "The errors were: " & ControlChars.CrLf & badStatus
			frm.ShowDialog()
		End If

	End Sub



	Private Sub Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Delete.Click

		Dim userName As String = String.Empty
		Dim badStatus As String = String.Empty
		Dim badCnt As Integer = 0
		Dim temp As String
		Dim frm As New DisplayFrm

		If MessageBox.Show("You are about to delete " & IIf(UniChk.Checked, "1", NumUsers.Value.ToString) & " users.  The " & _
		"users to be deleted are " & IIf(UniChk.Checked, PrefixTxt.Text, PrefixTxt.Text & "1 to " & _
		PrefixTxt.Text & (NumUsers.Value).ToString) & ".  Are you sure you want to continue?", _
		"Delete Users", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.No _
		Then Exit Sub


		Try
			If Not UniChk.Checked Then
				'setup progress bar
				PBar.Maximum = NumUsers.Value
				PBar.Visible = True

				For cnt As Integer = 1 To NumUsers.Value

					'increment progress bar
					PBar.Value = cnt

					'delete the user
					userName = PrefixTxt.Text & cnt.ToString
					Membership.DeleteUser(userName, True)
				Next

				'hide progress bar
				PBar.Visible = False
			Else
				Membership.DeleteUser(PrefixTxt.Text, True)
			End If

		Catch ex As Exception
			badCnt += 1
			badStatus += ex.Message & ControlChars.CrLf
		End Try

		If badCnt = 0 Then
			MessageBox.Show("All users were deleted successfully.", "Members Deleted", _
			 MessageBoxButtons.OK, MessageBoxIcon.Information)
		Else
			If badCnt = NumUsers.Value Then
				temp = "No users were deleted. "
			Else
				temp = badCnt.ToString & " were not deleted because of errors. "
			End If
			frm.Title = "Error Deleting Users"
			frm.Value = temp & "The errors were: " & ControlChars.CrLf & badStatus
			frm.ShowDialog()
		End If

	End Sub


	Private Sub CreateRoleBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateRoleBtn.Click

		Try
			System.Web.Security.Roles.CreateRole(RoleTxt.Text)
			MessageBox.Show("Role " & RoleTxt.Text & " was created.", "Role Create", _
			 MessageBoxButtons.OK, MessageBoxIcon.Information)
		Catch ex As Exception
			MessageBox.Show("Error creating role: " & ex.Message, "Role Create Error", _
			 MessageBoxButtons.OK, MessageBoxIcon.Error)
		End Try

	End Sub


	Private Sub AddToRoleBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToRoleBtn.Click

		Try

			Dim Users(NumRoleUsers.Value - 1) As String

			If UniAddChk.Checked Then
				ReDim Users(0)
				Users(0) = RolePrefixTxt.Text
			Else
				'create the array of users that will be added to the role
				For i As Integer = StartNum.Value To (StartNum.Value + NumRoleUsers.Value - 1)
					Users(i - StartNum.Value) = RolePrefixTxt.Text & i.ToString
				Next
			End If

			'try adding them to the role
			System.Web.Security.Roles.AddUsersToRole(Users, RoleTxt.Text)

			MessageBox.Show(Users.Length.ToString() & " added to role " & RoleTxt.Text, _
			 "Role Users Added", MessageBoxButtons.OK, MessageBoxIcon.Information)
		Catch ex As Exception
			MessageBox.Show("Error adding users to role: " & ex.Message, "Role Users Error", _
				MessageBoxButtons.OK, MessageBoxIcon.Error)
		End Try

	End Sub


	Private Sub GetUsersBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetUsersBtn.Click

		Dim Users() As String
		Dim Temp As String = String.Empty
		Dim frm As New DisplayFrm

		Try
			Users = System.Web.Security.Roles.GetUsersInRole(RoleTxt.Text)
			For i As Integer = 0 To Users.Length - 1
				Temp += Users(i) & ControlChars.CrLf
			Next
			frm.Title = "Role Users"
			frm.Value = Temp
			frm.ShowDialog()
		Catch ex As Exception
			MessageBox.Show("Error retrieving list of users for role " & RoleTxt.Text & ":" & ex.Message, _
			 "Role Users Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
		End Try

	End Sub


	Private Sub GetRolesBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetRolesBtn.Click

		Dim Roles() As String
		Dim Temp As String = String.Empty
		Dim frm As New DisplayFrm

		Try
			Roles = System.Web.Security.Roles.GetAllRoles
			For i As Integer = 0 To Roles.Length - 1
				Temp += Roles(i) & ControlChars.CrLf
			Next
			frm.Title = "Roles"
			frm.Value = Temp
			frm.ShowDialog()
		Catch ex As Exception
			MessageBox.Show("Error retrieving list of roles:" & ex.Message, _
			"Roles Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
		End Try

	End Sub

	Private Sub DeleteRoleBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteRoleBtn.Click

		Try
			System.Web.Security.Roles.DeleteRole(RoleTxt.Text)
			MessageBox.Show("Role " & RoleTxt.Text & " was deleted.", "Role Delete", _
			 MessageBoxButtons.OK, MessageBoxIcon.Information)
		Catch ex As Exception
			MessageBox.Show("Error deleting role: " & ex.Message, "Role Delete Error", _
			 MessageBoxButtons.OK, MessageBoxIcon.Error)
		End Try

	End Sub


	Private Sub ChangePwdBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangePwdBtn.Click

		Dim newUser As MembershipUser = Nothing

		Try
			'get the user
			newUser = System.Web.Security.Membership.GetUser(UserNameTxt.Text)
			If newUser Is Nothing Then
				MessageBox.Show("Unable to find user " & UserNameTxt.Text)
				Exit Sub
			End If

			'change the password
			If newUser.ChangePassword(OldPwdTxt.Text, NewPwdTxt.Text) Then
				MessageBox.Show("Password was successfully changed.")
			Else
				MessageBox.Show("UNABLE to change password.")
			End If

		Catch ex As Exception
			MessageBox.Show("Error changing password: " & ex.Message, "Change Password Error", _
			 MessageBoxButtons.OK, MessageBoxIcon.Error)
		End Try

	End Sub


	Private Sub GetPropsBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetPropsBtn.Click

		Dim frm As New PropFrm
		frm.AccountName = UserNameTxt.Text
		frm.ShowDialog()
		frm = Nothing

	End Sub


	Private Sub ConfigBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConfigBtn.Click

		Dim xDoc As XmlDocument = New XmlDocument()
		Dim xNode As XmlNode = Nothing
		Dim xPath As String = String.Empty
		Dim xFile As String = String.Empty

		Dim mServer As String = String.Empty
		Dim mDatabase As String = String.Empty
		Dim mAuth As String = String.Empty
		Dim mUser As String = String.Empty
		Dim mPwd As String = String.Empty
		Dim mConStr As String = String.Empty

		Dim srvFrm As New ServerFrm()

		Try
			'open the config file
			xFile = Application.ExecutablePath & ".config"
			xDoc.Load(xFile)

			'get the ServerName value
			mServer = ConfigurationManager.AppSettings("ServerName")
			mDatabase = ConfigurationManager.AppSettings("Database")

			'plug the values into the server form
			srvFrm.Server = mServer
			srvFrm.Database = mDatabase

			'show the form
			srvFrm.ShowDialog(Me)

			'check results 
			If Not String.IsNullOrEmpty(srvFrm.ConnectionString) Then
				'get all the properties so we can persist them
				mConStr = srvFrm.ConnectionString
				mServer = srvFrm.Server
				mDatabase = srvFrm.Database

				'get the connection string node
				xNode = xDoc.SelectSingleNode("configuration/connectionStrings/add[@name='AspNetSqlMembershipProvider']")
				If xNode IsNot Nothing Then CType(xNode, XmlElement).SetAttribute("connectionString", mConStr)

				'get the ServerName node
				xNode = xDoc.SelectSingleNode("configuration/appSettings/add[@key='ServerName']")
				If xNode IsNot Nothing Then CType(xNode, XmlElement).SetAttribute("value", mServer)
				'get the database node
				xNode = xDoc.SelectSingleNode("configuration/appSettings/add[@key='Database']")
				If xNode IsNot Nothing Then CType(xNode, XmlElement).SetAttribute("value", mDatabase)

				'save the config file
				xDoc.Save(xFile)

				'let the user know it worked but the need to restart the app; RefreshSection didn't do anything useful
				MessageBox.Show("The information was updated successfully.  You need to close and restart this application" & _
				 "to have the new data used.", "Membership Seeder", MessageBoxButtons.OK, MessageBoxIcon.Information)
			End If

		Catch ex As Exception
			MessageBox.Show("There was an error getting or saving the configuration information: " & ex.Message, "Membership Seeder", _
			 MessageBoxButtons.OK, MessageBoxIcon.Error)
		Finally
			xDoc = Nothing
		End Try

	End Sub


	Private Sub FindBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindBtn.Click

		Dim muc As MembershipUserCollection = Nothing
		Dim dispFrm As DisplayFrm = Nothing
		Dim temp As New System.Text.StringBuilder(2048)

		If String.IsNullOrEmpty(FindUserTxt.Text) Then
			MessageBox.Show("You must enter some search criteria.", "Membership Seeder", MessageBoxButtons.OK, MessageBoxIcon.Error)
			Exit Sub
		End If

		Try
			'look for matches
			muc = Membership.FindUsersByName(FindUserTxt.Text & "%")

			'figure out if any were found
			If (muc IsNot Nothing) AndAlso (muc.Count > 0) Then
				'create a new display form
				dispFrm = New DisplayFrm()
				dispFrm.Title = "Users Found"

				'enumerate matches and add them to display
				For Each m As MembershipUser In muc
					temp.Append(m.UserName & Environment.NewLine)
				Next

				'plug in the values
				dispFrm.Value = temp.ToString()

				'show it
				dispFrm.ShowDialog(Me)
			Else
				MessageBox.Show("No matching users were found.", "Membership Seeder", MessageBoxButtons.OK, MessageBoxIcon.Information)
			End If
		Catch ex As Exception
			MessageBox.Show("Error searching for users: " & ex.Message, "Membership Seeder", MessageBoxButtons.OK, MessageBoxIcon.Error)
		Finally
			dispFrm = Nothing
		End Try

	End Sub

End Class
