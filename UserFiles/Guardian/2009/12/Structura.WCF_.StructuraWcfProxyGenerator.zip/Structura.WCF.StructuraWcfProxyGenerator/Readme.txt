﻿1- Compile and deploy to the GAC

2- Run the provided registry file

3- Add a web service reference an change the custom tool of the Reference.svcmap to 'Structura WCF Proxy Generator'

4- Run the custom tool again