﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using NHibernateEagerOrderBy.Entities;

namespace NHibernateEagerOrderBy
{
	public class NHelper
	{
		private static ISessionFactory _sessionFactory;
		private static Configuration _configuration;

		static NHelper()
		{
			_configuration = new Configuration();
			_configuration.Configure();
			_configuration.AddAssembly(typeof(Item).Assembly);
		}
 
		private static ISessionFactory SessionFactory
		{
			get
			{
				if(_sessionFactory == null)
				{
					_sessionFactory = _configuration.BuildSessionFactory();
				}
				return _sessionFactory;
			}
		}

		public static void GenerateSchema()
		{
			new SchemaExport(_configuration).Execute(true, true, false);
		}
 
		public static ISession OpenSession()
		{
			return SessionFactory.OpenSession();
		}
	}
}
