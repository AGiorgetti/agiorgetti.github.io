﻿using System.Collections.Generic;
using NHibernate;
using NHibernate.Criterion;
using NHibernate.Transform;
using NHibernateEagerOrderBy.Entities;
using NUnit.Framework;

namespace NHibernateEagerOrderBy
{
	[TestFixture]
	public class Test
	{
		[Test, Explicit]
		public void Schema()
		{
			NHelper.GenerateSchema();
			CreateTestData();
		}

		[Test]
		public void CriteriaEagerFecthSelect()
		{
			IList<Item> result;
			using (ISession session = NHelper.OpenSession())
			using (ITransaction tx = session.BeginTransaction())
			{
				ICriteria myCriteria = session.CreateCriteria<Item>();

				myCriteria
					.SetResultTransformer(Transformers.DistinctRootEntity)
					.SetFetchMode("Tags", FetchMode.Eager)
					.AddOrder(new Order("Sort", true));

				result = myCriteria.List<Item>();

				tx.Commit();
			}
			// arret the result in the expected order
			Assert.IsNotNull(result);
			Assert.AreEqual(10, result.Count);
			for (int i = 0; i < 10; i++)
				Assert.AreEqual("Item" + i, result[i].Name);
		}

		[Test]
		public void HqlEagerFecthSelect()
		{
			IList<Item> result;
			using (ISession session = NHelper.OpenSession())
			using (ITransaction tx = session.BeginTransaction())
			{
				IQuery query = session.CreateQuery("from Item itm left join fetch itm.Tags order by itm.Sort");

				result = query.List<Item>();

				tx.Commit();
			}
			// arret the result in the expected order
			Assert.IsNotNull(result);
			Assert.AreEqual(10, result.Count);
			for (int i = 0; i < 10; i++)
				Assert.AreEqual("Item" + i, result[i].Name);
		}

		public void CreateTestData()
		{
			string[] tagsName = new[] { "zapp", "crunch", "bang", "sbanf" };
			using (ISession session = NHelper.OpenSession())
			using (ITransaction tx = session.BeginTransaction())
			{
				// create some items
				for (int i = 0; i < 10; i++)
				{
					Item itm = new Item() { Name = "Item" + i, Sort = i };
					session.SaveOrUpdate(itm);
					
					Tag t = new Tag();
					t.Name = tagsName[i / 3];
					t.Item = itm;
					itm.Tags.Add(t);
					session.SaveOrUpdate(t);
				}
				tx.Commit();
			}
		}
	}
}
