﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NHibernateEagerOrderBy.Entities
{
	public class Item
	{
		public Item()
		{
			Tags = new List<Tag>();
		}

		public virtual int Id { get; set; }

		public virtual string Name { get; set; }

		public virtual int Sort { get; set; }

		public virtual IList<Tag> Tags { get; set; }
	}
}
