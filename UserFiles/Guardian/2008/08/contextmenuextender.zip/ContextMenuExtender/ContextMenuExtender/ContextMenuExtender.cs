﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;

namespace ContextMenuExtender
{
	public class ContextMenuExtender
	{
		private Canvas _canvas = null;
		private Dictionary<FrameworkElement, ContextMenuAnchor> _anchors = new Dictionary<FrameworkElement, ContextMenuAnchor>();
		private FrameworkElement _current = null;

		/// <summary>
		/// the external canvas that will be used to hold the controls
		/// </summary>
		/// <param name="canvas"></param>
		public ContextMenuExtender(Canvas canvas)
		{
			_canvas = canvas;
		}

		/// <summary>
		/// extends the framework element
		/// </summary>
		/// <param name="ctrl"></param>
		/// <param name="click"></param>
		public void AddContextMenu(FrameworkElement ctrl, RoutedEventHandler click)
		{
			if (!_anchors.ContainsKey(ctrl))
			{
				ctrl.MouseEnter += new MouseEventHandler(_ctrl_MouseEnter);
				ContextMenuAnchor anchor = new ContextMenuAnchor();
				_anchors.Add(ctrl, anchor);
				anchor.button.Click += click;
				anchor.button.Click += new RoutedEventHandler(button_Click);
				anchor.border.MouseLeave += new MouseEventHandler(b_MouseLeave);
			}
		}

		void button_Click(object sender, RoutedEventArgs e)
		{
			RemoveHighlight(sender as Button);
		}

		void _ctrl_MouseEnter(object sender, MouseEventArgs e)
		{
			HighlightControl(sender as FrameworkElement);
		}

		/// <summary>
		/// reposition the border and the anchor over the control
		/// </summary>
		/// <param name="ctrl"></param>
		void HighlightControl(FrameworkElement ctrl)
		{
			//this is a patch to have only 1 element highlited at a time, sometimes if you move the mouse
			//too fast, silverlight misses to raise the MouseLeave event.
			if ((_current != null) && (_current != ctrl))
				RemoveHighlight(_current);

			_current = ctrl;

			ContextMenuAnchor anchor = _anchors[ctrl];
			if (anchor != null)
			{
				Button btn = anchor.button;
				Border b = anchor.border;

				if (!_canvas.Children.Contains(b))
				{
					GeneralTransform gt = ctrl.TransformToVisual(_canvas);
					Point p = gt.Transform(new Point(0, 0));

					b.Width = ctrl.ActualWidth;
					b.Height = ctrl.ActualHeight;
					b.SetValue(Canvas.TopProperty, p.Y);
					b.SetValue(Canvas.LeftProperty, p.X);
					_canvas.Children.Add(b);
					Canvas.SetZIndex(b, Canvas.GetZIndex(ctrl) + 1);

					btn.SetValue(Canvas.TopProperty, p.Y);
					btn.SetValue(Canvas.LeftProperty, p.X + ctrl.ActualWidth - btn.Width);
					_canvas.Children.Add(btn);
					Canvas.SetZIndex(btn, Canvas.GetZIndex(ctrl) + 1);
				}
			}
		}

		void b_MouseLeave(object sender, MouseEventArgs e)
		{
			RemoveHighlight(sender as Border);
		}

		#region RemoveHighlight functions

		void RemoveHighlight(Border ctrl)
		{
			ContextMenuAnchor anchor = (from r in _anchors where r.Value.border == ctrl select r.Value).Single();
			RemoveHighlight(anchor);
		}

		void RemoveHighlight(Button ctrl)
		{
			ContextMenuAnchor anchor = (from r in _anchors where r.Value.button == ctrl select r.Value).Single();
			RemoveHighlight(anchor);
		}

		void RemoveHighlight(FrameworkElement ctrl)
		{
			RemoveHighlight(_anchors[ctrl]);
		}

		void RemoveHighlight(ContextMenuAnchor anchor)
		{
			_canvas.Children.Remove(anchor.border);
			_canvas.Children.Remove(anchor.button);
		}

		#endregion

		/// <summary>
		/// this class will contain out anchor and highlight controls
		/// </summary>
		private class ContextMenuAnchor
		{
			public Border border = new Border();
			public Button button = new Button();

			public ContextMenuAnchor()
			{
				button.Width = 10;
				button.Height = 10;
				border.BorderBrush = new SolidColorBrush(Colors.Blue);
				border.BorderThickness = new Thickness(1);
			}
		}

	}
}
