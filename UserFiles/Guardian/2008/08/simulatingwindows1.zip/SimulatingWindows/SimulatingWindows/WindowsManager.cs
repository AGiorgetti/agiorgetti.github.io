﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace SimulatingWindows
{
	/// <summary>
	/// Class that handles the creation and destruction of dynamic windows
	/// </summary>
	public class WindowsManager
	{
		private Canvas _canvas = null;
		
		/// <summary>
		/// creates the manager and stores the canvas to which attach the windows
		/// </summary>
		/// <param name="surface"></param>
		public WindowsManager(Canvas surface)
		{
			_canvas = surface;
		}
		
		public Window ShowWindow(FrameworkElement content, string caption, Point location)
		{
			Window w = new Window();
			w.Caption = caption;
			w.Content = content;
			w.Closed += new EventHandler(w_Closed);
			Canvas.SetLeft(w, location.X);
			Canvas.SetTop(w, location.Y);			
			_canvas.Children.Add(w);
			return w;
		}

		/// <summary>
		/// show a window attaching it to the canvas
		/// </summary>
		/// <param name="w"></param>
		/// <param name="location"></param>
		public void ShowWindow(Window w, Point location)
		{
			w.Closed += new EventHandler(w_Closed);
			Canvas.SetLeft(w, location.X);
			Canvas.SetTop(w, location.Y);
			_canvas.Children.Add(w);
		}

		void w_Closed(object sender, EventArgs e)
		{
			//remove the object from the childern colelction and dispose it dispose the object 
			Window w = (Window)sender;
			_canvas.Children.Remove(w);
			//todo: dispose the object
		}
	}
}
