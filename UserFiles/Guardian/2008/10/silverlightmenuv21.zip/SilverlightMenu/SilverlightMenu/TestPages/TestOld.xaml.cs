﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightMenu
{
	public partial class TestOld : UserControl
	{
		public TestOld()
		{
			InitializeComponent();
			this.Loaded += new RoutedEventHandler(Page_Loaded);
		}

		void Page_Loaded(object sender, RoutedEventArgs e)
		{
			//Dynamically buildup a menu
			Menu m1 = new Menu("Test1");
			m1.AddSubmenu(new SubMenu("Sub1"));
			m1.AddSubmenu(new SubMenu("Long Sub1 string"));
			SubMenu sb1 = new SubMenu("Disabled Sub1");
			sb1.IsEnabled = false;
			m1.AddSubmenu(sb1);
			sb1 = new SubMenu("Click Me! Sub1");
			sb1.MenuClick += new MenuClickEventHandler(sb1_MenuClick);
			m1.AddSubmenu(sb1);
			Menu.AddMenu(m1);
			Menu m2 = new Menu("Disabled Test2");
			m2.IsEnabled = false;
			m2.AddSubmenu(new SubMenu("Sub2"));
			m2.AddSubmenu(new SubMenu("Sub2"));
			m2.AddSubmenu(new SubMenu("Sub2"));
			Menu.AddMenu(m2);
			Menu m3 = new Menu("Test3");
			m3.AddSubmenu(new SubMenu("Sub3"));
			m3.AddSubmenu(new SubMenu("Sub3"));
			SubMenu sb3 =new SubMenu("Sub3");
			m3.AddSubmenu(sb3);
			Menu.AddMenu(m3);
		}

		void sb1_MenuClick(object sender, MenuClickEventArgs e)
		{
			System.Windows.Browser.HtmlPage.Window.Alert("Clicked!");
		}

		private void Button_MouseEnter(object sender, MouseEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("Button_MouseEnter");
		}

		private void Button_MouseLeave(object sender, MouseEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("Button_MouseLeave");
		}

		private void Button_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("Button_MouseLeftButtonDown");
		}

		private void Button_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("Button_MouseLeftButtonUp");
		}

		private void StackPanel_MouseEnter(object sender, MouseEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("StackPanel_MouseEnter");
		}

		private void StackPanel_MouseLeave(object sender, MouseEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("StackPanel_MouseLeave");
		}
	}
}
