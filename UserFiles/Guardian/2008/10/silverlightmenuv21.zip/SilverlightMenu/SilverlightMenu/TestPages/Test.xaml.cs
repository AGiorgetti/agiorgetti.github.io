﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightMenu.TestPages
{
	public partial class Test : UserControl
	{
		public Test()
		{
			InitializeComponent();

			this.Loaded += new RoutedEventHandler(PageNew_Loaded);
		}

		void PageNew_Loaded(object sender, RoutedEventArgs e)
		{
			//Dynamically buildup a menu
			MainMenuItem m1 = new MainMenuItem("Test1");
			m1.AddSubmenu(new MenuItem("Sub1"));
			m1.AddSubmenu(new MenuItem("Long Sub1 string"));
			MenuItem sb1 = new MenuItem("Disabled Sub1");
			sb1.IsEnabled = false;
			m1.AddSubmenu(sb1);
			sb1 = new MenuItem("Click Me! Sub1");
			sb1.MenuItemClick += new MenuClickEventHandler(sb1_MenuClick);
			m1.AddSubmenu(sb1);
			Menu.AddMenu(m1);
			MainMenuItem m2 = new MainMenuItem("Disabled Test2");
			m2.IsEnabled = false;
			m2.AddSubmenu(new MenuItem("Sub2 1"));
			m2.AddSubmenu(new MenuItem("Sub2 2"));
			m2.AddSubmenu(new MenuItem("Sub2 3"));
			Menu.AddMenu(m2);
			MainMenuItem m3 = new MainMenuItem("Test3");
			m3.AddSubmenu(new MenuItem("Sub3 1"));
			MenuItem sb2 = new MenuItem("Sub3 2");
			sb2.AddSubmenu(new MenuItem("Sub Sub2 1"));
			sb2.AddSubmenu(new MenuItem("Sub Sub2 2 "));
			m3.AddSubmenu(sb2);
			MenuItem sb3 = new MenuItem("Sub3 3");
			m3.AddSubmenu(sb3);
			sb3.AddSubmenu(new MenuItem("Sub Sub3 1"));
			sb3.AddSubmenu(new MenuItem("Sub Sub3 2 "));
			MenuItem subsub3 = new MenuItem("Sub Sub3 3");
			subsub3.MenuItemClick += (ms, me) => { System.Windows.Browser.HtmlPage.Window.Alert("Sub Sub3 3 Clicked!"); };
			sb3.AddSubmenu(subsub3);
			m3.AddSubmenu(new MenuItem("Sub4"));
			m3.AddSubmenu(new MenuItem("Sub5"));
			Menu.AddMenu(m3);
		}

		void sb1_MenuClick(object sender, MenuClickEventArgs e)
		{
			System.Windows.Browser.HtmlPage.Window.Alert("Clicked!");
		}

	}
}
