﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightMenu
{
	public partial class MenuBar : UserControl
	{
		public MenuBar()
		{
			InitializeComponent();
		}

		public void AddMenu(MainMenuItem mi)
		{
			mi.ParentMenu = this;
			MenuContainer.Children.Add(mi);
		}
		
		public MainMenuItem AddMenu(string text)
		{
			var mi = CreateMainMenuItem(text);
			AddMenu(mi);
			return mi;
		}

		public void RemoveMenu(MainMenuItem mi)
		{
			mi.ParentMenu = null;
			MenuContainer.Children.Remove(mi);
		}

		public Style MainMenuItemStyle
		{
			get { return (Style)GetValue(MainMenuItemStyleProperty); }
			set { SetValue(MainMenuItemStyleProperty, value); }
		}
		
		public MenuItem CreateMenuItem(string text)
		{
			MenuItem mi = new MenuItem(text);
			SetMenuItemStyle(mi);
			return mi;
		}
		
		public MainMenuItem CreateMainMenuItem(string text)
		{
			MainMenuItem mi = new MainMenuItem(text);
			SetMainMenuItemStyle(mi);
			return mi;
		}

		// Using a DependencyProperty as the backing store for MainMenuItemStyle.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty MainMenuItemStyleProperty =
			 DependencyProperty.Register("MainMenuItemStyle", typeof(Style), typeof(MenuBar), new PropertyMetadata(null));

		public Style MenuItemStyle
		{
			get { return (Style)GetValue(MenuItemStyleProperty); }
			set { SetValue(MenuItemStyleProperty, value); }
		}

		// Using a DependencyProperty as the backing store for MenuItemStyle.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty MenuItemStyleProperty =
			 DependencyProperty.Register("MenuItemStyle", typeof(Style), typeof(MenuBar), new PropertyMetadata(null));

		public Style MenuPanelStyle
		{
			get { return (Style)GetValue(MenuPanelStyleProperty); }
			set { SetValue(MenuPanelStyleProperty, value); }
		}

		// Using a DependencyProperty as the backing store for MenuPanelStyle.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty MenuPanelStyleProperty =
			 DependencyProperty.Register("MenuPanelStyle", typeof(Style), typeof(MenuBar), new PropertyMetadata(null));

		internal void SetMainMenuItemStyle(MainMenuItem mi)
		{
			if (MainMenuItemStyle != null) 
				mi.Style = MainMenuItemStyle;
			if (MenuPanelStyle != null)
				mi.PanelMenuStyle = MenuPanelStyle;
		}

		internal void SetMenuItemStyle(MenuItem mi)
		{
			if ((MenuItemStyle != null) && (mi.Style == null))
				mi.Style = MenuItemStyle;
			if (MenuPanelStyle != null)
				mi.PanelMenuStyle = MenuPanelStyle;
		}
	}
}
