﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace SilverlightMenu
{
	[TemplateVisualState(GroupName = "CommonStates", Name = "Normal"),
	 TemplateVisualState(GroupName = "CommonStates", Name = "MouseOver"),
	 TemplateVisualState(GroupName = "CommonStates", Name = "Pressed"),
	 TemplateVisualState(GroupName = "CommonStates", Name = "Disabled"),
	 TemplatePart(Name = MenuItem.MenuItemLayoutElement, Type = typeof(Grid)),
	 TemplatePart(Name = MenuItem.MenuItemsArrowElement, Type = typeof(Path))]
	public class MenuItem : Button
	{
		internal MenuItem() :
			base()
		{
			this.DefaultStyleKey = typeof(MenuItem);
		}

		internal MenuItem(string text) :
			this()
		{
			Text = text;
		}

		private const string MenuItemLayoutElement = "MenuItemLayout";
		private const string MenuItemsArrowElement = "MenuItemsArrow";

		public override void OnApplyTemplate()
		{
			//OverrideDefaultStyle();

			base.OnApplyTemplate();

			LayoutGrid = GetTemplateChild(MenuItemLayoutElement) as Grid;

			MenuItemsArrow = GetTemplateChild(MenuItemsArrowElement) as Shape;

			if ((p != null) && (!LayoutGrid.Children.Contains(p)))
			{
				//Grid par = (Grid)VisualTreeHelper.GetParent(p);
				//if (par != null)
				//   par.Children.Remove(p);
				LayoutGrid.Children.Add(p);
			}

			if (MenuItemsArrow != null)
				MenuItemsArrow.Visibility = !HasSubItems ? Visibility.Collapsed : Visibility.Visible;

		}

		protected virtual void OverrideDefaultStyle()
		{
			ParentMenu.SetMenuItemStyle(this);
		}

		System.Windows.Controls.Primitives.Popup p;
		MenuPanel pnl;
		MenuPopupProvider pp = null;

		Grid LayoutGrid;
		Shape MenuItemsArrow;
		protected Direction MenuDirection = Direction.Right;

		public bool HasSubItems
		{
			get
			{
				return ((pnl != null) && (pnl.Children.Count > 0));
			}
		}

		public bool IsSubMenuOpen
		{
			get
			{
				if (pp == null)
					return false;
				return pp.IsPopupOpen;
			}
		}

		internal IList<UIElement> MenuItems
		{
			get
			{
				if (pnl == null)
					return null;
				else
					return pnl.Children;
			}
		}

		internal Style PanelMenuStyle { get; set; }

		protected override void OnClick()
		{
			//lanciamo prima l'onclick base
			if (!_isEnabled) return;

			base.OnClick();

			RaiseMenuItemClick();
		}

		protected virtual void RaiseMenuItemClick()
		{
			if (!this.HasSubItems)
			{
				//close the parent popup window
				ParentMenuItem.ForceCloseMenuPopup();

				//reaise the menu click event
				OnMenuClick();
			}
		}

		public MenuItem AddSubmenu(string text)
		{
			MenuItem mi = new MenuItem(text);
			ParentMenu.SetMenuItemStyle(mi);
			AddSubmenu(mi);
			return mi;
		}

		/// <summary>
		/// add a submenu
		/// </summary>
		/// <param name="sm">the menu item to add</param>
		/// <remarks>
		/// internally it creates the stuctures to hold the submenu items only
		/// if they are actually added to the menu itself.
		/// it also will create the popup provider to handle open and close events
		/// </remarks>
		public void AddSubmenu(MenuItem sm)
		{
			if (p == null)
			{
				p = new System.Windows.Controls.Primitives.Popup();
				if (pnl == null)
				{
					pnl = new MenuPanel();
					if (PanelMenuStyle != null)
						pnl.Style = PanelMenuStyle;
					pnl.LayoutUpdated += new EventHandler(pnl_LayoutUpdated);
				}
				p.Child = pnl;
				if ((LayoutGrid != null) && (!LayoutGrid.Children.Contains(p)))
					LayoutGrid.Children.Add(p);
				if (MenuItemsArrow != null)
					MenuItemsArrow.Visibility = Visibility.Visible;
			}
			pnl.Children.Add(sm);
			sm.ParentMenuItem = this;
			EnablePopupProvider();
		}

		void pnl_LayoutUpdated(object sender, EventArgs e)
		{
			//set each enabled menuitem in normal state
			//this way we avoid to display the focus on an element of the popup
			//seems that an element of the popup menu can get the focus when it's displayed
			foreach (MenuItem mi in pnl.Children)
				mi.ForceVisualState(mi.IsEnabled);
		}

		private void EnablePopupProvider()
		{
			if (pp == null)
				pp = new MenuPopupProvider(this, this, p, pnl, MenuDirection);
		}

		private void DisablePopupProvider()
		{
			if (pp != null)
			{
				pp.Dispose();
				pp = null;
			}
		}

		/// <summary>
		/// Remove a menu from the list
		/// </summary>
		/// <param name="sm">the menu item to remove</param>
		/// <remarks>internally it will destroy the popup provider so we are sure that
		/// events for opening and closing a menu aren't triggered</remarks>
		public void RemoveSubmenu(MenuItem sm)
		{
			sm.ParentMenuItem = null;
			pnl.Children.Remove(sm);
			if (pnl.Children.Count == 0)
			{
				DisablePopupProvider();
				if (MenuItemsArrow != null)
					MenuItemsArrow.Visibility = Visibility.Collapsed;
			}
		}

		public string Text
		{
			get { return this.Content.ToString(); }
			set { this.Content = value; }
		}

		public new bool IsEnabled
		{
			get { return _isEnabled; }
			set
			{
				_isEnabled = value;
				ForceVisualState(value);
				//this is not strictly needed if the menu control is implemented as a button and we can
				//'really' disable the control, cause if the control is disabled no event will be fired
				if (value)
					EnablePopupProvider();
				else
					DisablePopupProvider();
			}
		}
		private bool _isEnabled = true;

		private void ForceVisualState(bool value)
		{
			if (value)
				VisualStateManager.GoToState(this, "Normal", true);
			else
				VisualStateManager.GoToState(this, "Disabled", true);
		}

		public event MenuClickEventHandler MenuItemClick;

		/// <summary>
		/// the click even is fired only if this menu do not have childrens
		/// </summary>
		private void OnMenuClick()
		{
			if (_isEnabled)
				if (!HasSubItems && (MenuItemClick != null))
					MenuItemClick(this, new MenuClickEventArgs());
		}

		/// <summary>
		/// close the menu, but the closing can be aborted if the mouse is over the popup menu itself
		/// </summary>
		public void CloseMenuPopup()
		{
			if (pp != null)
				pp.BeginClosingPopup();
		}

		/// <summary>
		/// close the menu, even if the mouse is over the popup menu itself
		/// </summary>
		public void ForceCloseMenuPopup()
		{
			if (pp != null)
				pp.ForceBeginClosingPopup();
		}

		public void OpenMenuPopup()
		{
			if (IsEnabled && (pp != null) && (pp.IsPopupOpen == false))
				pp.ShowPopup();
		}

		public MenuItem ParentMenuItem { get; set; }

		public virtual MenuBar ParentMenu
		{
			get
			{
				if (ParentMenuItem != null)
				{
					return ParentMenuItem.ParentMenu;
				}
				return null;
			}
			set { throw new ArgumentException("Unexpected use of setted method"); }
		}
	}
}
