﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SilverlightMenu
{
	public class MenuPopupProvider : IDisposable
	{
		#region Constructors

		/// <summary>
		/// http://www.codeproject.com/KB/silverlight/Silverlight_Popup_Logic.aspx
		/// 
		/// Encapsulates logic for popup controls so the code does not need to be rewritten.
		/// </summary>
		/// <param name="owner">
		/// The owner is the FrameworkElement that will trigger the popup to close it the
		/// mouse leaves its screan area.  The popup will only remain open after leaving the
		/// owner if the popupChild element is supplied in this constructor and the mouse 
		/// immediately enters the screen area of the popupChild element after leaving the owner.
		/// </param>
		/// <param name="trigger">
		/// The trigger is the framework element that triggers the popup panel to open.
		/// The popup will open on the MouseLeftButtonUp routed event of the trigger.
		/// </param>
		/// <param name="popup">
		/// The popup is the Popup primitive control that contains the content to be displayed.
		/// </param>
		/// <param name="popupChild">
		/// The popupChild is the child control of the popup panel.  The Popup control does not 
		/// raise MouseEnter and MouseLeave events so the child control must be used to detect
		/// if the popup should remain open or closed in conjuction with the owner element.
		/// This value may be left null to create situations where only the owner element
		/// controls whether the popup closes or not.  e.g. an image could trigger a popup that
		/// describes the image and the popup closes when the mouse leaves the image regardless
		/// of whether the mouse enters the description. 
		/// </param>
		/// <param name="placement">
		/// Determines which side of the owner element the popup will appear on.
		/// </param>
		public MenuPopupProvider(FrameworkElement owner, FrameworkElement trigger, Popup popup, FrameworkElement popupChild, Direction placement)
		{
			if (owner == null) throw new ArgumentNullException("owner");
			if (trigger == null) throw new ArgumentNullException("trigger");
			if (popup == null) throw new ArgumentNullException("popup");

			_owner = owner;
			_placement = placement;
			_popup = popup;
			_popupChild = popupChild;
			_trigger = trigger;

			_owner.MouseEnter += new MouseEventHandler(_owner_MouseEnter);
			_owner.MouseLeave += new MouseEventHandler(_owner_MouseLeave);
			if (_popupChild != null)
			{
				_popupChild.MouseEnter += new MouseEventHandler(_popupChild_MouseEnter);
				_popupChild.MouseLeave += new MouseEventHandler(_popupChild_MouseLeave);
			}

			//small fix cause buttons do not use MouseLeftButtonUp or MouseLeftButtonDown anymore
			if (_trigger is ButtonBase)
				((ButtonBase)_trigger).Click += new RoutedEventHandler(_trigger_Click);
			else
				_trigger.MouseLeftButtonUp += new MouseButtonEventHandler(_trigger_MouseLeftButtonUp);
			//if the trigger is a menu item we probably want to open the menu when the mouse if over the menu item
			if (_trigger.GetType() == typeof(MenuItem))
			{
				_trigger.MouseEnter += new MouseEventHandler(_trigger_MouseEnter);
				//_trigger.MouseMove += new MouseEventHandler(_trigger_MouseMove);
			}

			_closeTimer = new DispatcherTimer();
			_closeTimer.Interval = new TimeSpan(0, 0, 0, 0, CloseDelay);
			_closeTimer.Tick += new EventHandler(_closeTimer_Tick);
		}

		#endregion

		#region IDisposable Members

		/// <summary>
		/// remove any event handler added
		/// </summary>
		public void Dispose()
		{
			_owner.MouseEnter -= new MouseEventHandler(_owner_MouseEnter);
			_owner.MouseLeave -= new MouseEventHandler(_owner_MouseLeave);
			if (_popupChild != null)
			{
				_popupChild.MouseEnter -= new MouseEventHandler(_popupChild_MouseEnter);
				_popupChild.MouseLeave -= new MouseEventHandler(_popupChild_MouseLeave);
			}
			//small fix cause buttons do not use MouseLeftButtonUp or MouseLeftButtonDown anymore
			if (_trigger is ButtonBase)
				((ButtonBase)_trigger).Click -= new RoutedEventHandler(_trigger_Click);
			else
				_trigger.MouseLeftButtonUp -= new MouseButtonEventHandler(_trigger_MouseLeftButtonUp);
			//if the trigger is a menu item we probably want to open the menu when the mouse if over the menu item
			if (_trigger.GetType() == typeof(MenuItem))
			{
				_trigger.MouseEnter -= new MouseEventHandler(_trigger_MouseEnter);
				//_trigger.MouseMove -= new MouseEventHandler(_trigger_MouseMove);
			}
		}

		#endregion

		#region Event Handlers

		void _closeTimer_Tick(object sender, EventArgs e)
		{
			DebugMessage("_closeTimer_Tick");
			ClosePopup();
		}

		void _owner_MouseEnter(object sender, MouseEventArgs e)
		{
			DebugMessage("_owner_MouseEnter");
			StopClosingPopup();
		}

		void _owner_MouseLeave(object sender, MouseEventArgs e)
		{
			DebugMessage("_owner_MouseLeave");
			BeginClosingPopup();
		}

		void _popupChild_MouseEnter(object sender, MouseEventArgs e)
		{
			_isMouseOverPopupChild = true;
			DebugMessage("_popupLayout_MouseEnter");
			StopClosingPopup();
		}

		void _popupChild_MouseLeave(object sender, MouseEventArgs e)
		{
			_isMouseOverPopupChild = false;
			DebugMessage("_popupLayout_MouseLeave");
			BeginClosingPopup();
		}

		void _trigger_Click(object sender, RoutedEventArgs e)
		{
			ShowPopup();
		}

		void _trigger_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ShowPopup();
		}

		void _trigger_MouseEnter(object sender, MouseEventArgs e)
		{
			//now it seems to work even on mouseenter in the trigger
			if (!_isPopupOpen)
				ShowPopup();
			//System.Diagnostics.Debug.WriteLine("TRIGGER ENTER");
		}

		//void _trigger_MouseMove(object sender, MouseEventArgs e)
		//{
		//   //seems event are fired in a bad way with popup opened during mouseeneter events
		//   //if (!_isPopupOpen)
		//   //   ShowPopup();
		//}

		public void ShowPopup()
		{
			DebugMessage("ShowPopup");
			if (!_isPopupOpen)
			{
				//popup offset is now relative to its parent
				Point p;
				switch (_placement)
				{
					case Direction.Left:
						p = new Point(_popup.ActualWidth, 0);
						break;
					case Direction.Top:
						p = new Point(0, -_popup.ActualHeight);
						break;
					case Direction.Bottom:
						p = new Point(0, _owner.ActualHeight);
						break;
					case Direction.Right:
						p = new Point(_owner.ActualWidth, 0);
						break;
					default:
						throw new InvalidOperationException("Placement of popup not defined.");
				}

				_popup.VerticalOffset = p.Y;
				_popup.HorizontalOffset = p.X;
				_isPopupOpen = _popup.IsOpen = true;
			}
			else
			{
				BeginClosingPopup();
			}
		}

		private void DebugMessage(string methodName)
		{
			System.Diagnostics.Debug.WriteLine("{5} {0}: _isPopupOpen({1}) _isPopupClosing({2}) _popup.IsOpen({3}) _closeTimer.IsEnabled({4})", methodName, _isPopupOpen, _isPopupClosing, _popup.IsOpen, _closeTimer.IsEnabled, ((MenuItem)_owner).Text);
		}

		#endregion

		#region Private Fields

		private const int CloseDelay = 20;

		private DispatcherTimer _closeTimer;
	
		private bool _isPopupOpen;
		public bool IsPopupOpen
		{
			get { return _isPopupOpen; }
		}
		private bool _isPopupClosing;
		private FrameworkElement _owner;
		private Direction _placement;
		private Popup _popup;
		private FrameworkElement _popupChild;
		private FrameworkElement _trigger;
		/// <summary>
		/// we cannot close this menu popup is the mouse is over it usually
		/// so we provide a method to force the popup closing
		/// by setting thie member to false..it's useful when we the menu that
		/// use this popup ask to the popupcobntroller to close the menu after a click
		/// </summary>
		private bool _isMouseOverPopupChild;

		#endregion

		#region Private Methods

		public void ForceBeginClosingPopup()
		{
			_isMouseOverPopupChild = false;
			BeginClosingPopup();
		}

		public void BeginClosingPopup()
		{
			if (_isPopupOpen && !_isPopupClosing && !_isMouseOverPopupChild)
			{
				_isPopupClosing = true;
				_closeTimer.Start();
			}
		}

		private void ClosePopup()
		{
			if (_isPopupOpen && _isPopupClosing)
			{
				_closeTimer.Stop();
				//the popup logically belongs to the owner, so we have to check in one of his children have a popup opened. 
				if (_owner is MenuItem)
				{
					MenuItem mi = _owner as MenuItem;
					if (mi.HasSubItems)
						foreach (MenuItem m in mi.MenuItems)
							if (m.IsSubMenuOpen)
							{
								//if so we cancel the closing request
								_isPopupClosing = false;
								return;
							}
				}

				_isPopupOpen = _isPopupClosing = _popup.IsOpen = false;

				//if this is a menuitem and his parent is not null, we have to ask it to close its menu too,
				//however we have to close the parent menu only if the mouse is not over the menu itself
				if (_owner.GetType() == typeof(MenuItem))
				{
					MenuItem parent = (_owner as MenuItem).ParentMenuItem;
					if (parent != null)
						parent.CloseMenuPopup();
				}
			}
		}

		private void StopClosingPopup()
		{
			if (_isPopupOpen && _isPopupClosing)
			{
				_closeTimer.Stop();
				_isPopupClosing = false;
			}
			//if (_owner.GetType() == typeof(MenuItem))
			//{
			//   MenuItem mi = _owner as MenuItem;
			//   if (mi.HasSubItems)
			//      mi.OpenMenuPopup();
			//}
		}

		#endregion
	}
}
