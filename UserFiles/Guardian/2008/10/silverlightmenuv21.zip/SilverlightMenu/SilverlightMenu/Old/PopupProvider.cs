﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SilverlightMenu
{
	public enum Direction
	{
		Left,
		Top,
		Right,
		Bottom
	}

	public class PopupProvider : IDisposable
	{
		#region Constructors

		/// <summary>
		/// http://www.codeproject.com/KB/silverlight/Silverlight_Popup_Logic.aspx
		/// 
		/// Encapsulates logic for popup controls so the code does not need to be rewritten.
		/// </summary>
		/// <param name="owner">
		/// The owner is the FrameworkElement that will trigger the popup to close it the
		/// mouse leaves its screan area.  The popup will only remain open after leaving the
		/// owner if the popupChild element is supplied in this constructor and the mouse 
		/// immediately enters the screen area of the popupChild element after leaving the owner.
		/// </param>
		/// <param name="trigger">
		/// The trigger is the framework element that triggers the popup panel to open.
		/// The popup will open on the MouseLeftButtonUp routed event of the trigger.
		/// </param>
		/// <param name="popup">
		/// The popup is the Popup primitive control that contains the content to be displayed.
		/// </param>
		/// <param name="popupChild">
		/// The popupChild is the child control of the popup panel.  The Popup control does not 
		/// raise MouseEnter and MouseLeave events so the child control must be used to detect
		/// if the popup should remain open or closed in conjuction with the owner element.
		/// This value may be left null to create situations where only the owner element
		/// controls whether the popup closes or not.  e.g. an image could trigger a popup that
		/// describes the image and the popup closes when the mouse leaves the image regardless
		/// of whether the mouse enters the description. 
		/// </param>
		/// <param name="placement">
		/// Determines which side of the owner element the popup will appear on.
		/// </param>
		public PopupProvider(FrameworkElement owner, FrameworkElement trigger, Popup popup, FrameworkElement popupChild, Direction placement)
		{
			if (owner == null) throw new ArgumentNullException("owner");
			if (trigger == null) throw new ArgumentNullException("trigger");
			if (popup == null) throw new ArgumentNullException("popup");

			_owner = owner;
			_placement = placement;
			_popup = popup;
			_popupChild = popupChild;
			_trigger = trigger;

			_owner.MouseEnter += new MouseEventHandler(_owner_MouseEnter);
			_owner.MouseLeave += new MouseEventHandler(_owner_MouseLeave);
			if (_popupChild != null)
			{
				_popupChild.MouseEnter += new MouseEventHandler(_popupChild_MouseEnter);
				_popupChild.MouseLeave += new MouseEventHandler(_popupChild_MouseLeave);
			}
			//small fix cause buttons do not use MouseLeftButtonUp or MouseLeftButtonDown anymore
			if (_trigger is ButtonBase)
				((ButtonBase)_trigger).Click += new RoutedEventHandler(_trigger_Click);
			else
				_trigger.MouseLeftButtonUp += new MouseButtonEventHandler(_trigger_MouseLeftButtonUp);

			_closeTimer = new DispatcherTimer();
			_closeTimer.Interval = new TimeSpan(0, 0, 0, 0, CloseDelay);
			_closeTimer.Tick += new EventHandler(_closeTimer_Tick);
		}

		#endregion

		#region IDisposable Members

		/// <summary>
		/// remove any event handler added
		/// </summary>
		public void Dispose()
		{
			_owner.MouseEnter -= new MouseEventHandler(_owner_MouseEnter);
			_owner.MouseLeave -= new MouseEventHandler(_owner_MouseLeave);
			if (_popupChild != null)
			{
				_popupChild.MouseEnter -= new MouseEventHandler(_popupChild_MouseEnter);
				_popupChild.MouseLeave -= new MouseEventHandler(_popupChild_MouseLeave);
			}
			//small fix cause buttons do not use MouseLeftButtonUp or MouseLeftButtonDown anymore
			if (_trigger is ButtonBase)
				((ButtonBase)_trigger).Click -= new RoutedEventHandler(_trigger_Click);
			else
				_trigger.MouseLeftButtonUp -= new MouseButtonEventHandler(_trigger_MouseLeftButtonUp);
		}

		#endregion

		#region Event Handlers

		void _closeTimer_Tick(object sender, EventArgs e)
		{
			DebugMessage("_closeTimer_Tick");
			ClosePopup();
		}

		void _owner_MouseEnter(object sender, MouseEventArgs e)
		{
			//(sender as FrameworkElement).CaptureMouse();
			DebugMessage("_owner_MouseEnter");
			StopClosingPopup();
		}

		void _owner_MouseLeave(object sender, MouseEventArgs e)
		{
			//(sender as FrameworkElement).ReleaseMouseCapture();
			DebugMessage("_owner_MouseLeave");
			BeginClosingPopup();
		}

		void _popupChild_MouseEnter(object sender, MouseEventArgs e)
		{
			DebugMessage("_popupLayout_MouseEnter");
			StopClosingPopup();
		}

		void _popupChild_MouseLeave(object sender, MouseEventArgs e)
		{
			DebugMessage("_popupLayout_MouseLeave");
			BeginClosingPopup();
		}

		void _trigger_Click(object sender, RoutedEventArgs e)
		{
			ShowPopup();
		}

		void _trigger_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			ShowPopup();
		}

		private void ShowPopup()
		{
			DebugMessage("_trigger_MouseLeftButtonUp");
			if (!_isPopupOpen)
			{
				//FrameworkElement page = (Application.Current != null) ? Application.Current.RootVisual as FrameworkElement : null;
				//GeneralTransform gt = _owner.TransformToVisual(page);
				//Point p;
				//switch (_placement)
				//{
				//   case Direction.Left:
				//      p = gt.Transform(new Point(_popup.ActualWidth, 0));
				//      break;
				//   case Direction.Top:
				//      p = gt.Transform(new Point(0, -_popup.ActualHeight));
				//      break;
				//   case Direction.Bottom:
				//      p = gt.Transform(new Point(0, _owner.ActualHeight));
				//      break;
				//   case Direction.Right:
				//      p = gt.Transform(new Point(_owner.ActualWidth, 0));
				//      break;
				//   default:
				//      throw new InvalidOperationException("Placement of popup not defined.");
				//}
				
				//popup offset is now relative to its parent
				Point p;
				switch (_placement)
				{
					case Direction.Left:
						p = new Point(_popup.ActualWidth, 0);
						break;
					case Direction.Top:
						p = new Point(0, -_popup.ActualHeight);
						break;
					case Direction.Bottom:
						p = new Point(0, _owner.ActualHeight);
						break;
					case Direction.Right:
						p = new Point(_owner.ActualWidth, 0);
						break;
					default:
						throw new InvalidOperationException("Placement of popup not defined.");
				}
				
				_popup.VerticalOffset = p.Y;
				_popup.HorizontalOffset = p.X;
				_isPopupOpen = _popup.IsOpen = true;
			}
			else
				BeginClosingPopup();
		}

		private void DebugMessage(string methodName)
		{
			System.Diagnostics.Debug.WriteLine("{0}: _isPopupOpen({1}) _isPopupClosing({2}) _popup.IsOpen({3}) _closeTimer.IsEnabled({4})", methodName, _isPopupOpen, _isPopupClosing, _popup.IsOpen, _closeTimer.IsEnabled);
		}

		#endregion

		#region Private Fields

		private const int CloseDelay = 10;

		private DispatcherTimer _closeTimer;
		private bool _isPopupOpen;
		private bool _isPopupClosing;
		private FrameworkElement _owner;
		private Direction _placement;
		private Popup _popup;
		private FrameworkElement _popupChild;
		private FrameworkElement _trigger;

		#endregion

		#region Private Methods

		public void BeginClosingPopup()
		{
			if (_isPopupOpen && !_isPopupClosing)
			{
				_isPopupClosing = true;
				_closeTimer.Start();
			}
		}

		private void ClosePopup()
		{
			if (_isPopupOpen && _isPopupClosing)
			{
				_closeTimer.Stop();
				_isPopupOpen = _isPopupClosing = _popup.IsOpen = false;
			}
		}

		private void StopClosingPopup()
		{
			if (_isPopupOpen && _isPopupClosing)
			{
				_closeTimer.Stop();
				_isPopupClosing = false;
			}
		}

		#endregion
	}
}
