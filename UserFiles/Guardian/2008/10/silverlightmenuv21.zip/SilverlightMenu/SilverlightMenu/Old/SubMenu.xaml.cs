﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightMenu
{
	/// <summary>
	/// Level 1,2,3 etc Menu Items
	/// </summary>
	public partial class SubMenu : UserControl, IMenu
	{
		public SubMenu()
		{
			InitializeComponent();

			this.MenuButton.Click += new RoutedEventHandler(MenuButton_Click);
			this.Loaded += new RoutedEventHandler(SubMenu_Loaded);
		}

		void SubMenu_Loaded(object sender, RoutedEventArgs e)
		{
			//force the visualization to switch to the normal state to avoid the
			//hovering bug: the control is in the hover state when we ask to close 
			//the popup that contains it, if we do not change the state manually
			//it will retain the 'mouse hover' status
			if (IsEnabled)
				VisualStateManager.GoToState(MenuButton, "Normal", true);				
		}

		public SubMenu(string text) :
			this()
		{
			Text = text;
		}

		public string Text
		{
			get { return this.MenuButton.Content.ToString(); }
			set { this.MenuButton.Content = value; }
		}

		void MenuButton_Click(object sender, RoutedEventArgs e)
		{
			//close the parent popup window
			ParentMenu.CloseMenuPopup();

			//reaise the menu click event
			OnMenuClick();
		}

		public event MenuClickEventHandler MenuClick;

		private void OnMenuClick()
		{
			if (MenuClick != null)
				MenuClick(this, new MenuClickEventArgs());
		}

		public new bool IsEnabled
		{
			get { return this.MenuButton.IsEnabled; }
			set { this.MenuButton.IsEnabled = value; }
		}

		#region IMenu Members

		public IMenu ParentMenu { get; set; }

		public void CloseMenuPopup()
		{
			throw new NotImplementedException();
		}

		#endregion

		#region IMenu Members


		public bool HasSubItems
		{
			get { throw new NotImplementedException(); }
		}

		#endregion
	}
}
