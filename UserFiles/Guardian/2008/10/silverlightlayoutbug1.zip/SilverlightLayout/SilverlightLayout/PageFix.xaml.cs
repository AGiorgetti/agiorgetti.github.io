﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightLayout
{
	public partial class PageFix : UserControl
	{
		public PageFix()
		{
			InitializeComponent();
			this.ScrollBox.SizeChanged += new SizeChangedEventHandler(ScrollBox_SizeChanged);
		}

		void ScrollBox_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			//add a smalloffset to avoid an unwanted disabled horizontal scrollbar that appears sometimes
			ScrollContent.Width = Math.Max(ScrollBox.ViewportWidth - 1.0, 0);
		}
	}
}
