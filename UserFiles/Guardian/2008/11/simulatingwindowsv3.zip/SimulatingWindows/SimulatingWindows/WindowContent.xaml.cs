﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SimulatingWindows
{
	public partial class WindowContent : UserControl
	{
		public WindowContent()
		{
			InitializeComponent();
			this.Loaded += new RoutedEventHandler(WindowContent_Loaded);
		}

		void WindowContent_Loaded(object sender, RoutedEventArgs e)
		{
			this.btn.Click += new RoutedEventHandler(btn_Click);
			this.DataContext = DemoDataProvider.GetPerson();
		}

		void btn_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Browser.HtmlPage.Window.Alert("click");
		}
	}
}
