﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

namespace SimulatingWindows
{
	public class Person
	{
		public string Name { get; set; }
		public string Surname { get; set; }
		public string Email { get; set; }
		public string Profile { get; set; }
		public string Hobbies { get; set; }
		public string Note { get; set; }
		public string ImgPath { get; set; }
	}

	public class DemoDataProvider
	{
		public static Person GetPerson()
		{
			Person p = new Person();

			p.Name = "Alessandro";
			p.Surname = "Giorgetti";
			p.Email = "guardian@nablasoft.com";
			p.Profile = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Fusce luctus nibh id quam. Nullam feugiat ante id nisi. Mauris lacus augue, pharetra ut, congue ornare, luctus at, pede. Suspendisse in mauris. Nullam molestie rutrum justo. Cras varius diam facilisis lorem. Ut non metus eu lorem suscipit convallis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec venenatis elit adipiscing pede. Integer malesuada. Vestibulum nec nibh eget urna pellentesque ultrices. Phasellus interdum pede ac lectus. ";
			p.Hobbies = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed tincidunt. Nulla arcu. Donec vehicula lacus id libero. Morbi porttitor. Ut pellentesque nisl at urna. Nam vestibulum. Proin euismod dui ac nisl rhoncus rhoncus. Phasellus ipsum sem, faucibus eu, placerat egestas, sagittis nec, augue. Aliquam nulla purus, fermentum ut, malesuada quis, egestas et, massa. Aenean luctus. Duis aliquet elementum lectus. ";
			p.Note = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla imperdiet, nibh eu mollis varius, velit risus luctus augue, non egestas magna mauris vitae ligula. In sed nunc ac augue gravida fringilla. Morbi interdum. Duis sit amet erat at urna sodales posuere. Curabitur augue tortor, aliquet eu, luctus sit amet, tincidunt ac, arcu. Nulla facilisi. Mauris condimentum odio non sapien. Donec et neque. Pellentesque suscipit mi sed quam. Suspendisse potenti. Duis vitae ante in ligula commodo adipiscing. Mauris scelerisque dignissim velit. Proin ac ligula. Nullam et neque quis magna sollicitudin adipiscing. Curabitur hendrerit lacus id lorem. Proin ornare nunc a dolor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Morbi augue massa, luctus sed, molestie non, tristique sit amet, nisl. Sed sit amet enim ac elit varius eleifend. ";
			p.ImgPath = "Images/me.jpg";

			return p;
		}
	}
}
