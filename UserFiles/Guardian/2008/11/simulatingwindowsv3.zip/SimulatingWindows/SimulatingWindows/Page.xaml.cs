﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Nablasoft.Silverlight.Controls.Windows;

namespace SimulatingWindows
{
	public partial class Page : UserControl
	{
		public Page()
		{
			InitializeComponent();
			this.Loaded += new RoutedEventHandler(Page_Loaded);
		}

		void Page_Loaded(object sender, RoutedEventArgs e)
		{
			wm = new WindowsManager(LayoutRoot);
			
			this.btn.Click += new RoutedEventHandler(btn_Click);

			//wm.ShowWindow(new TestStyle(), "Test 1", new Point(100,100));
		}

		int i = 0;
			
		void btn_Click(object sender, RoutedEventArgs e)
		{
			i++;
			Window w = new Window();
			w.Content = new WindowContent();
			w.Caption = "Windows " + i.ToString();
			w.Width = 400;
			w.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			w.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			wm.ShowWindow(w, new Point(100, 100));
		}
		
		private WindowsManager wm = null;

		private void btnNoScrollBars_Click(object sender, RoutedEventArgs e)
		{
			i++;
			Window w = new Window();
			w.Content = new WindowContent();
			w.Caption = "Windows " + i.ToString();
			w.Width = 400;
			//w.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
			//w.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
			wm.ShowWindow(w, new Point(100, 100));
		}
	}
}
