﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Structura.Infrastructure.IOC;

namespace TestApp.TestModule1.MenuClasses
{
	public class Menu1 : TestApp.Infrastructure.IExecutable
	{
		public Menu1(IIoC ioc)
		{
			_ioc = ioc;
		}

		private IIoC _ioc;
		#region IExecutable Members

		public object Execute()
		{
			return new TestWindow1();
		}

		#endregion
	}

	public class Menu2 : TestApp.Infrastructure.IExecutable
	{
		#region IExecutable Members

		public object Execute()
		{
			return new TestWindow1();
		}

		#endregion
	}
}
