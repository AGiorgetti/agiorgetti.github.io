﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Linq;
using Structura.Infrastructure.IOC;
using Structura.Infrastructure;

namespace TestApp.AppManager.Presenter
{
	public class AppConfigurator : IAppConfigurator
	{
		#region IAppConfigurator Members

		public void BeginGetModules()
		{
			System.IO.FileStream fs = new System.IO.FileStream(AppDomain.CurrentDomain.BaseDirectory + "/Modules.xml", System.IO.FileMode.Open);
			StreamReader sr = new StreamReader(fs);
			string file = sr.ReadToEnd();
			sr.Close();
			fs.Close();

			//parse the Modules info file
			XDocument doc = XDocument.Parse(file);

			//parse the data with linq
			IEnumerable<ModuleInfo> list = from mod in doc.Descendants("ModuleInfo")
													 select new ModuleInfo
													 {
														 Id = new Guid((string)mod.Element("ID")),
														 Name = (string)mod.Element("Name"),
														 Version = (string)mod.Element("Version"),
														 Url = (string)mod.Element("Url")
													 };

			List<ModuleInfo> l = new List<ModuleInfo>();
			l.AddRange(list);
			OnGetModulesCompleted(new GetModulesCompletedEventArgs(l));
		}

		private void OnGetModuleCompleted(GetModuleCompletedEventArgs e)
		{
			if (GetModuleCompleted != null)
				GetModuleCompleted(this, e);
		}

		public event EventHandler<GetModulesCompletedEventArgs> GetModulesCompleted;

		public void BeginGetModule(ModuleInfo mi)
		{
			System.IO.FileStream fs = new System.IO.FileStream(AppDomain.CurrentDomain.BaseDirectory + mi.Url, System.IO.FileMode.Open);
			StreamReader sr = new StreamReader(fs);
			string file = sr.ReadToEnd();
			sr.Close();
			fs.Close();

			//parse the Modules info file
			XDocument doc = XDocument.Parse(file);

			var tsl = from ts in doc.Root.Element("TypeSettings").Descendants("TypeSetting")
						 select new TypeSetting(
							 (string)ts.Element("FromType"),
							 (string)ts.Element("ToType"),
							 (string)ts.Element("Name"),
							 new Uri((string)ts.Element("Uri"), UriKind.Relative)
						);

			var mil = from mie in doc.Root.Element("Menu").Element("Items").Descendants("Item")
						 select new MenuItemInfo
						 {
							 Name = (string)mie.Element("Name"),
							 TypeSettingName = (string)mie.Element("TypeSettingName")
						 };

			var miname = (string)doc.Root.Element("Menu").Element("Name");

			var typeList = new List<TypeSetting>();
			typeList.AddRange(tsl);
			string menuName = miname;
			var menuitemsList = new List<MenuItemInfo>();
			menuitemsList.AddRange(mil);
			var ms = new ModuleSettings(typeList, menuName, menuitemsList);
			OnGetModuleCompleted(new GetModuleCompletedEventArgs(ms));
		}

		private void OnGetModulesCompleted(GetModulesCompletedEventArgs e)
		{
			if (GetModulesCompleted != null)
				GetModulesCompleted(this, e);
		}

		public event EventHandler<GetModuleCompletedEventArgs> GetModuleCompleted;

		#endregion

		#region IApplicationConfigurationProvider Members

		public List<Structura.Infrastructure.IOC.TypeSetting> GetConfiguration()
		{
			throw new NotImplementedException();
		}

		#endregion

		#region IAppConfigurator Members


		public string GetAssetCategoryIconUri()
		{
			throw new NotImplementedException();
		}

		#endregion

		#region IAppConfigurator Members


		public void GetAddictionalModulesToRegisterAsync()
		{
			System.IO.FileStream fs = new System.IO.FileStream(AppDomain.CurrentDomain.BaseDirectory + "/TypesConfig.xml", System.IO.FileMode.Open);
			StreamReader sr = new StreamReader(fs);
			string file = sr.ReadToEnd();
			sr.Close();
			fs.Close();

			//parse the Modules info file
			XDocument doc = XDocument.Parse(file);

			var tsl = from ts in doc.Root.Element("TypeSettings").Descendants("TypeSetting")
						 select new TypeSetting(
							 (string)ts.Element("FromType"),
							 (string)ts.Element("ToType"),
							 (string)ts.Element("Name"),
							 new Uri((string)ts.Element("Uri"), UriKind.Relative)
						);

			var typeList = new List<TypeSetting>();
			typeList.AddRange(tsl);
			OnGetAddictionalModulesToRegisterCompleted(new EnumerableResultEventArgs<TypeSetting>(typeList));
		}

		private void OnGetAddictionalModulesToRegisterCompleted(EnumerableResultEventArgs<TypeSetting> e)
		{
			if (GetAddictionalModulesToRegisterCompleted != null)
				GetAddictionalModulesToRegisterCompleted(this, e);
		}

		public event EventHandler<EnumerableResultEventArgs<TypeSetting>> GetAddictionalModulesToRegisterCompleted;

		#endregion
	}
}
