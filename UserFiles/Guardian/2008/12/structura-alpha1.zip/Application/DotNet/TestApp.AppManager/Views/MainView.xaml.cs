﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TestApp.AppManager.View;
using Structura.Infrastructure.IOC;
using Castle.Windsor;
using TestApp.Infrastructure;
using Structura.Infrastructure.ViewModel;
using TestApp.AppManager.Presenter;
using Structura.Utils;

namespace TestApp.AppManager.Views
{
	/// <summary>
	/// Interaction logic for MainView.xaml
	/// </summary>
	public partial class MainView : Structura.Infrastructure.ViewModel.View, IMainView
	{
		public MainView()
		{
			InitializeComponent();

			UIThread.Dispatcher = this.Dispatcher;

			this.Loaded += new RoutedEventHandler(MainView_Loaded);

			//_AppManager = new TestApp.AppManager.Presenter.AppManager();
			this.Controller = new AppManager.Presenter.AppManagerController();
		}

		void MainView_Loaded(object sender, RoutedEventArgs e)
		{
			(Controller as AppManagerController).Init(this, new CastleWindorIOC(new WindsorContainer()));
		}

		#region IMainView Members

		public void AddMainMenu(string menuText, List<TestApp.AppManager.Presenter.MenuItemInfo> menuItems)
		{
			// create the main menu item
			MenuItem mmi = new MenuItem();
			mmi.Header = menuText;
			// add teh submenu voices
			foreach (var mi in menuItems)
			{
				var newMi = new MenuItem();
				newMi.Header = mi.Name;
				newMi.Tag = mi.TypeSettingName;
				newMi.Click += (sender, e) =>
					 {
						 IExecutable exe = (Controller as AppManagerController).IoC.Resolve<IExecutable>((sender as MenuItem).Tag.ToString());
						 object obj = exe.Execute();
						 if (obj != null)
						 {
							 (obj as Window).Show();
						 }
					 };
				mmi.Items.Add(newMi);
			}

			// add the main meunn items
			MainMenu.Items.Add(mmi);
		}

		public void DisplayModules(List<TestApp.AppManager.Presenter.ModuleInfo> modules)
		{
			// do nothing
		}

		public void DisplayModuleData(TestApp.AppManager.Presenter.ModuleSettings ms)
		{
			// do nothing
		}

		#endregion

		#region IView Members


		public override void UpdateInterface()
		{
			// do nothing
		}

		#endregion
	}
}
