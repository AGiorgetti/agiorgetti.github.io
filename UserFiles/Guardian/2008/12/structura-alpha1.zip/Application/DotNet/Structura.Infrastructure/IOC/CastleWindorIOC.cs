﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.Windsor;

namespace Structura.Infrastructure.IOC
{
	public class CastleWindorIOC : IIoC
	{
		private readonly IWindsorContainer _castleContainer;

		public CastleWindorIOC(IWindsorContainer castleContainer)
		{
			_castleContainer = castleContainer;
		}

		#region IIoC Members

		public void BeginResolve(Type type, string name)
		{
			BeginResolve(type, name, null);
		}

		public void BeginResolve(Type type, string name, ResolveCompletedCallback callback)
		{
			object t = null;
			try
			{
				t = _castleContainer.Resolve(name, type);
			}
			catch (Exception e)
			{
				//todo: log the error some way
			}
			OnResolveCompleted(t, callback);
		}

		public void BeginResolve<T>(string name, ResolveCompletedCallback<T> callback)
		{
			T t = default(T);
			try
			{
				t = _castleContainer.Resolve<T>(name);
			}
			catch (Exception e)
			{
				//todo: log the error some way
			}
			OnResolveCompleted(t, callback);
		}

		public object Resolve(Type type, string name)
		{
            if (name == null)
                name = type.ToString();
			return _castleContainer.Resolve(name, type);
		}

		public T Resolve<T>(string name)
		{
            if (name == null)
                name = typeof(T).ToString();
			return _castleContainer.Resolve<T>(name);
		}

		public event EventHandler<ResolveCompletedEventArgs> ResolveCompleted;

		public void RegisterType(Type fromType, Type toType, string name)
		{
			_castleContainer.AddComponent(name, fromType, toType);
		}

		public void RegisterType(Type fromType, string toType, string name, Uri uri)
		{
			_castleContainer.AddComponent(name, fromType, Type.GetType(toType));
			//throw new ApplicationException("Not needed in a wpf application, there's no need to download assemblies");
		}

		public void RegisterInstance(Type FromType, string name, object instance)
		{
            // castle do not allows to have null values for service names to specify the
            // default instance (the first one will always be used). Unity instead uses as the default
            // instance for type resolution the one without any service name, otherwise you have to explicitly
            // call for the named type.
            if (name == null)
                name = FromType.ToString();
			_castleContainer.Kernel.AddComponentInstance(name, FromType, instance);
		}

		public event EventHandler<DownloadPackageEventArgs> DownloadStarted;

		public event EventHandler<DownloadPackageEventArgs> DownloadCompleted;

		#endregion

		/// <summary>
		/// if the callback is not specified the event handles will be called, otherwise
		/// we will invoke the callback at the end of the object creation
		/// </summary>
		/// <param name="result">Object Resolved</param>
		/// <param name="func">Callback to invoke at the end of the process, if null all the event wired will be called</param>
		private void OnResolveCompleted(object result, ResolveCompletedCallback func)
		{
			if (func != null)
				func(result);
			else
				if (ResolveCompleted != null)
					ResolveCompleted(this, new ResolveCompletedEventArgs(result));
		}

		private void OnResolveCompleted<T>(T result, ResolveCompletedCallback<T> func)
		{
			if (func != null)
				func(result);
			else
				if (ResolveCompleted != null)
					ResolveCompleted(this, new ResolveCompletedEventArgs(result));
		}

	}
}
