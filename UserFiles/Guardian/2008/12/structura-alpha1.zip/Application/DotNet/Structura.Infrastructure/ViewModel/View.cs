﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Structura.Infrastructure.ViewModel
{
   /// <summary>
   /// Represents a View user control that is associated with a Controller/Presenter/ViewModel.
   /// The Controller - which will expose the data for bindings - is surfaced as the View's DataContext.
   /// </summary>
   public class View : Window, IView
   {
      /// <summary>
      /// Gets the model associated with the specified framework element.
      /// 
      /// to have designer support
      /// </summary>
      /// <param name="element">The element to lookup.</param>
      /// <returns>The associated model object if any.</returns>
      public static object GetController(UIElement obj)
      {
         return (object)obj.GetValue(ControllerProperty);
      }

      /// <summary>
      /// Sets the controller associated with the specified framework element.
      /// The model is also made available for binding by using it to set the
      /// DataContext of the element.
      /// </summary>
      /// <param name="element">The element to associate with the model.</param>
      /// <param name="value">The controller to use.</param>
      public static void SetController(UIElement obj, object value)
      {
         // obj.SetValue(ControllerProperty, value);
         ((View)obj).Controller = value as Controller;
      }

      // Using a DependencyProperty as the backing store for Controller.  This enables animation, styling, binding, etc...
      public static readonly DependencyProperty ControllerProperty =
          DependencyProperty.Register("Controller", typeof(object), typeof(View), new UIPropertyMetadata(null));


      /// <summary>
      /// Initializes an instance of a View.
      /// </summary>
      public View()
      {
      }

      /// <summary>
      /// Initializes an instance of a View with the specified model.
      /// </summary>
      /// <param name="viewModel">The associated controller.</param>
      public View(Controller viewModel)
      {
         Controller = viewModel;
      }

      /// <summary>
      /// Gets or sets the model associated with the view.
      /// </summary>
      public virtual object Controller
      {
         get
         {
            return DataContext; // (Controller)DataContext;
         }
         set
         {
            if (!(value is Controller))
               throw new ArgumentException("The value assigned must be derived from Controller");
            SetValue(ControllerProperty, value);
            DataContext = value;
            ((Controller)value).View = this;
         }
      }

      #region IView Members

      public virtual void UpdateInterface()
      {

      }

      #endregion
   }
}
