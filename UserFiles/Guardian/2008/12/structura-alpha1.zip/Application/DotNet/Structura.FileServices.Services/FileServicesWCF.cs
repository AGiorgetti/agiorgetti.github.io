﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Activation;
using Structura.FileUploader.Service;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace Structura.FileServices.Services
{
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	public class FileServicesWCF : UploaderService, IFileServices
	{
		#region IExtUploaderService Members

		public string Test()
		{
			return "Test";
		}

		#endregion

		public override int UploadDataChunk(string filename, byte[] data, int numBytes, bool append, bool complete)
		{
			int res = base.UploadDataChunk(filename, data, numBytes, append, complete);

			// do something else here.

			return res;
		}

		/// <summary>
		/// rename a file
		/// </summary>
		/// <param name="fromName">original filename</param>
		/// <param name="toName">destination file name</param>
		public void RenameFile(string fromName, string toName)
		{
			FileServiceHelpers.RenameFile(DestPath, fromName, toName, true);
		}

		/// <summary>
		/// get an image marked with the passed in ID
		/// </summary>
		/// <param name="id"></param>
		/// <param name="format">the format in which obtain the image ("png", "jpg", "bmp") the image will be converted if needed</param>
		/// <returns></returns>
		public ImageData GetImageData(Guid id, string format)
		{
			//get the data and the type of image based on the current extension
			//we suppose to have only jpeg actually
			return FileServiceHelpers.GetImageData(DestPath, id, format);
		}

		/// <summary>
		/// sposta nella cartella che contiene i file del designer
		/// </summary>
		/// <param name="sourceFile">nome del file che è stato inviato nella temp forlder</param>
		/// <param name="destFile">nuovo nome che il file assumerà nella cartella finale di destinazione</param>
		public void MoveToDesignerFolder(string sourceFile, string destFile)
		{
			// the file is in the local storage
			string localCategoryPath = GetLocalFolder(GetAppSettings().Settings[FileServicesSettings.MaintenanceDesignerStoragePath].Value);
			if (!Directory.Exists(localCategoryPath))
				Directory.CreateDirectory(localCategoryPath);

			FileServiceHelpers.MoveFile(DestPath, sourceFile, localCategoryPath, destFile, true);
		}

	}
	
}
