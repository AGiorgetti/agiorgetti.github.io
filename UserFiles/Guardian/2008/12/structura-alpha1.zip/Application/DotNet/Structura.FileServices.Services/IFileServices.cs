﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Structura.FileUploader.Service;
using System.ServiceModel;

namespace Structura.FileServices.Services
{
	[ServiceContract]
	public interface IFileServices : IUploaderService
	{
		[OperationContract]
		string Test();

		[OperationContract]
		void RenameFile(string fromName, string toName);

		[OperationContract]
		ImageData GetImageData(Guid id, string format);

		/// <summary>
		/// sposta nella cartella che contiene i file del designer
		/// </summary>
		/// <param name="sourceFile">nome del file che è stato inviato nella temp forlder</param>
		/// <param name="destFile">nuovo nome che il file assumerà nella cartella finale di destinazione</param>
		[OperationContract]
		void MoveToDesignerFolder(string sourceFile, string destFile);
	}
}
