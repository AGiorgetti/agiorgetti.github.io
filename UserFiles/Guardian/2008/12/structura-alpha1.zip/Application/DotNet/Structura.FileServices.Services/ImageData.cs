﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Structura.FileServices.Services
{
	[DataContract]
	public class ImageData
	{
		[DataMember]
		public byte[] Data;
		[DataMember]
		public int Width;
		[DataMember]
		public int Height;
		[DataMember]
		public string Type = "";
	}
}
