﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Structura.FileUploader.Service;
using System.Web.Services;
using System.ComponentModel;
using System.IO;
using System.Configuration;

namespace Structura.FileServices.Services
{
	/// <summary>
	/// Summary description for Service1
	/// </summary>
	[WebService(Namespace = "http://tempuri.org/")]
	[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
	[ToolboxItem(false)]
	// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
	// [System.Web.Script.Services.ScriptService]
	public class FileServicesWS : UploaderWebService, IFileServices
	{
		[WebMethod]
		public override int UploadDataChunk(string filename, byte[] data, int numBytes, bool append, bool complete)
		{
			return base.UploadDataChunk(filename, data, numBytes, append, complete);
		}

		[WebMethod]
		public string Test()
		{
			return "Test";
		}

		/// <summary>
		/// rename a file
		/// </summary>
		/// <param name="fromName">original filename</param>
		/// <param name="toName">destination file name</param>
		[WebMethod]
		public void RenameFile(string fromName, string toName)
		{
			FileServiceHelpers.RenameFile(DestPath, fromName, toName, true);
		}

		/// <summary>
		/// get an image marked with the passed in ID
		/// </summary>
		/// <param name="id"></param>
		/// <param name="format">the format in which obtain the image ("png", "jpg", "bmp") the image will be converted if needed</param>
		/// <returns></returns>
		[WebMethod]
		public ImageData GetImageData(Guid id, string format)
		{
			//get the data and the type of image based on the current extension
			//we suppose to have only jpeg actually
			return FileServiceHelpers.GetImageData(DestPath, id, format);
		}

		//[WebMethod]
		//public void MoveToCategoryIconsFolder(string file)
		//{
		//   // the file is in the local storage
		//   string localCategoryPath = Server.MapPath(ConfigurationManager.AppSettings[FileServicesSettings.CategoryIconStoragePath]);
		//   FileServiceHelpers.MoveFile(DestPath, file, localCategoryPath, file, true);
		//}

	}
}
