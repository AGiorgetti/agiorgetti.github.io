﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace Structura.FileServices.Services
{
	public static class FileServiceHelpers
	{
		public static void MoveFile(string sourceFolder, string sourceName, string destFolder, string newName, bool overwrite)
		{
			string fromFile = Path.Combine(sourceFolder, sourceName);
			string destFile = Path.Combine(destFolder, newName);
			if ((overwrite == true) && (File.Exists(destFile)))
				File.Delete(destFile);
			File.Move(fromFile, destFile);
		}

		public static void RenameFile(string folder, string fromName, string toName, bool overwrite)
		{
			string toFile = Path.Combine(folder, toName);
			if ((overwrite == true) && (File.Exists(toFile)))
				File.Delete(toFile);
			File.Move(Path.Combine(folder, fromName), toFile);
		}

		/// <summary>
		/// get an image marked with the passed in ID
		/// </summary>
		/// <param name="id"></param>
		/// <param name="format">the format in which obtain the image ("png", "jpg", "bmp") the image will be converted if needed</param>
		/// <returns></returns>
		public static ImageData GetImageData(string sourceFolder, Guid id, string format)
		{
			//get the data and the type of image based on the current extension
			//we suppose to have only jpeg actually
			string filepath = Path.Combine(sourceFolder, id.ToString());
			if (!File.Exists(filepath))
				return null;
			ImageData imgdata = new ImageData();
			Image img = new Bitmap(filepath);
			imgdata.Width = img.Width;
			imgdata.Height = img.Height;
			imgdata.Type = format;
			MemoryStream ms = new MemoryStream();
			img.Save(ms, GetImageFormat(format));
			byte[] arr = ms.ToArray();
			ms.Close();
			img.Dispose();
			imgdata.Data = arr;
			return imgdata;
		}

		public static ImageFormat GetImageFormat(string format)
		{
			if (string.IsNullOrEmpty(format))
				format = "png";
			switch (format.ToLower())
			{
				case "jpg":
					return ImageFormat.Jpeg;
				case "bmp":
					return ImageFormat.Bmp;
				default:
					return ImageFormat.Png;
			}
		}
	}
}
