﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Structura.FileServices.Services
{
	public class FileServicesSettings
	{
		public const string MaintenanceDesignerStoragePath = "Maintenance.FileService.StoragePath.Designer";
	}
}
