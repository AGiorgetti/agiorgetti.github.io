﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Structura.Utils
{
	public static partial class Helpers
	{
		public static T DeepClone<T>(this T obj)
		{
			T cloned = default(T);
			var serializer = new BinaryFormatter();
			using (var ms = new MemoryStream())
			{
				serializer.Serialize(ms, obj);
				ms.Position = 0;
				cloned = (T)serializer.Deserialize(ms);
			}
			return cloned;
		}
	}
}
