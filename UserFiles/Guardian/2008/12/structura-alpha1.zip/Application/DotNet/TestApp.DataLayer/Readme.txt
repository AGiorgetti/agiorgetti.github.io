﻿Layer di accesso dati, implementa l'interfaccia IDataLayer ed internamente si appoggia a TestApp.DataAccessLayer per eseguire l'accesso dati reale

per il momento manteniamo il pattern di accesso mediante webservice
è probabile che si possa del tutto convertire questo layer per eseguire chiamate dirette