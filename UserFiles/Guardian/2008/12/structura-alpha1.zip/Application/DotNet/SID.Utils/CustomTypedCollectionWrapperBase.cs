using System;
using System.ComponentModel;
using System.Collections;

namespace SID.Utils
{
  /// <summary>
  /// classe base che wrappa una generica collection funge
  /// come base per collection tipizzate che possono essere utilizzate
  /// con NHibernate
  /// 
  /// todo: implementare ITypedList
  /// </summary>
  [Serializable()]
  public class CustomTypedCollectionWrapperBase : //MarshalByValueComponent,
    IList,
    IBindingList
  {
    public CustomTypedCollectionWrapperBase(Type type, IList list) : 
      base()
    {
      _type = type;
      internalList = list;
    }

    protected IList internalList;
    protected Type _type;

    #region "Membri di  IList"

    public bool IsReadOnly
    {
      get
      {
        return internalList.IsReadOnly;
      }
    }

    public virtual object this[int index]
    {
      get
      {
        if ((index < 0) || (index >= internalList.Count))
          return null;
        return internalList[index];
      }
      set
      {
        internalList[index] = value;
        OnListChanged(new ListChangedEventArgs(ListChangedType.ItemChanged, index));
      }
    }

    public void RemoveAt(int index)
    {
      internalList.RemoveAt(index);
      OnListChanged(new ListChangedEventArgs(ListChangedType.ItemDeleted, index));
    }

    public void Insert(int index, object value)
    {
      internalList.Insert(index, value);
      OnListChanged(new ListChangedEventArgs(ListChangedType.ItemAdded, index));
    }

    public void Remove(object value)
    {
      int i = internalList.IndexOf(value);
      if (i >= 0)
        RemoveAt(i);
//      internalList.Remove(value);
//      OnListChanged(new ListChangedEventArgs(ListChangedType.ItemDeleted, i));
    }

    public bool Contains(object value)
    {
      return internalList.Contains(value);
    }

    public void Clear()
    {
      internalList.Clear();
      OnListChanged(new ListChangedEventArgs(ListChangedType.Reset,-1));
    }

    public int IndexOf(object value)
    {
      return internalList.IndexOf(value);
    }

    public int Add(object value)
    {
      int i = internalList.Add(value);
      OnListChanged(new ListChangedEventArgs(ListChangedType.ItemAdded, i));
      return i;
    }

    public bool IsFixedSize
    {
      get
      {
        return internalList.IsFixedSize;
      }
    }

    #endregion

    #region Membri di ICollection

    public bool IsSynchronized
    {
      get
      {
        return internalList.IsSynchronized;
      }
    }

    public int Count
    {
      get
      {
        return internalList.Count;
      }
    }

    public void CopyTo(Array array, int index)
    {
      internalList.CopyTo(array, index);
    }

    public object SyncRoot
    {
      get
      {
        return internalList.SyncRoot;
      }
    }

    #endregion

    #region Membri di IEnumerable

    public IEnumerator GetEnumerator()
    {
      return internalList.GetEnumerator();
    }

    #endregion
  
    #region Membri di IBindingList

    private void OnListChanged(System.ComponentModel.ListChangedEventArgs e)
    {
      if (ListChanged != null)
        ListChanged(this,e);
    }

    public void AddIndex(PropertyDescriptor property)
    {
      throw new NotSupportedException();
    }

    public virtual bool AllowNew
    {
      get
      {
        if (_allowNewDefaultValue)
        {
          if ((internalList.IsReadOnly == true) || (internalList.IsFixedSize == true))
            return false;
          return true;
        }
        return _allowNew;      
      }
      set
      {
        _allowNewDefaultValue = false;
        _allowNew = value;
      }
    }
    private bool _allowNew = false;
    private bool _allowNewDefaultValue = true;

    /// <summary>
    /// reset allownew to use the default value (ie depends on the collection wrapped)
    /// </summary>
    public void ResetAllowNew()
    {
      _allowNewDefaultValue = true;
    }

    private System.ComponentModel.PropertyDescriptor mSortProp;
    private bool mIsSorted;
    private System.ComponentModel.ListSortDirection mSortDirection = System.ComponentModel.ListSortDirection.Ascending;
    
    public void ApplySort(PropertyDescriptor property, ListSortDirection direction)
    {
      if (internalList.Count > 0)
      {
        mSortProp = property;
        mIsSorted = true;
        // creo il comparatore generico
        SID.Utils.BaseClassCompare comp = new SID.Utils.BaseClassCompare(property.Name, internalList[0]);
        ArrayList al = ArrayList.Adapter(internalList);
        al.Sort(comp);
        if (direction == System.ComponentModel.ListSortDirection.Descending)
          al.Reverse();
        mSortDirection = direction;
        OnListChanged(new System.ComponentModel.ListChangedEventArgs(System.ComponentModel.ListChangedType.Reset, property));
      }
    }

    public PropertyDescriptor SortProperty
    {
      get
      {
        return mSortProp;
      }
    }

    public int Find(PropertyDescriptor property, object key)
    {
      throw new NotSupportedException();
      //return 0;
    }

    public bool SupportsSorting
    {
      get
      {
        return true;
      }
    }

    public bool IsSorted
    {
      get
      {
        return mIsSorted;
      }
    }

    public virtual bool AllowRemove
    {
      get
      {
        if (_allowRemoveDefaultValue)
        {
          if ((internalList.IsReadOnly == true) || (internalList.IsFixedSize == true))
            return false;
          return true;
        }
        return _allowRemove;
      }
      set
      {
        _allowRemoveDefaultValue = false;
        _allowRemove = value;
      }
    }
    private bool _allowRemove = false;
    private bool _allowRemoveDefaultValue = true;

    public void ResetAllowRemove()
    {
      _allowRemoveDefaultValue = true;
    }

    public bool SupportsSearching
    {
      get
      {
        return false;
      }
    }

    public ListSortDirection SortDirection
    {
      get
      {
        return mSortDirection;
      }
    }

    public event ListChangedEventHandler ListChanged;

    public bool SupportsChangeNotification
    {
      get
      {
        return true;
      }
    }

    public void RemoveSort()
    {
      throw new NotSupportedException();
    }

    public virtual object AddNew()
    {
      throw new NotImplementedException();
    }

    public bool AllowEdit
    {
      get
      {
        return _allowEdit;
      }
      set
      {
        _allowEdit = value;
      }
    }
    private bool _allowEdit = true;

    public void ResetAllowEdit()
    {
      _allowEdit = true;
    }

    public void RemoveIndex(PropertyDescriptor property)
    {
      throw new NotSupportedException();
    }

    #endregion

	
    //		public override bool Equals(object o)
    //		{
    //			return SID.Utils.Equality.GenericEquals(this, o, false);
    //		}

    public void Sort(string property, ListSortDirection direction)
    {
      if (internalList.Count > 0)
      {
        mSortProp = TypeDescriptor.GetProperties(internalList[0])[property];
        ApplySort(mSortProp, direction);	  
      }
    }

    public bool Contains(string propertName, object val)
    {
      foreach(object o in internalList)
      {
        //recupero con reflection il valore della propriet� dell'oggetto
        System.Type t = o.GetType();
        System.Reflection.PropertyInfo pi = t.GetProperty(propertName);
        if ((pi != null) && (pi.GetValue(o, null).Equals(val)))
          return true;
      }
      return false;
    }
  }
}
