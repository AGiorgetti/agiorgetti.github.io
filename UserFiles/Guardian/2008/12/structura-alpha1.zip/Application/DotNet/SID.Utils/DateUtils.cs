using System;
using System.Text;

namespace SID.Utils
{
   public class DateUtils
   {
      public static string FormatDate(DateTime date)
      {
         return date.ToString("dd/MM/yyyy");
      }

      /// <summary>
      /// elimina eventuali millisecondi dalla data attuale
      /// </summary>
      /// <param name="date"></param>
      /// <returns></returns>
      public static DateTime ConvertDate(DateTime date)
      {
         return new DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute, date.Second);
      }

      public static DateTime Now
      {
         get { return ConvertDate(DateTime.Now); }
      }

      public static DateInterval GetLastDay()
      {
         DateInterval di = new DateInterval();
         di.StartDate = BuildStartDate(Now.Subtract(new TimeSpan(1, 0, 0, 0)));
         di.EndDate = BuildEndDate(Now);
         return di;
      }

      public static DateInterval GetLastWeek()
      {
         DateInterval di = new DateInterval();
         di.StartDate = BuildStartDate(Now.Subtract(new TimeSpan(6+(int)Now.DayOfWeek, 0, 0, 0)));
         di.EndDate = BuildEndDate(di.StartDate.AddDays(6));
         
         //melli,
         //todo: error dayofweek da un numerno da 1 a 7 non il primo giorno della sttimana
         //di.EndDate = Now.Subtract(new TimeSpan(Now.DayOfWeek, 0, 0, 0)).Date;
         //di.StartDate = Now.Subtract(new TimeSpan(Now.DayOfWeek + 7 - 1, 0, 0, 0)).Date;
         return di;
      }

      public static DateInterval GetLastMonth()
      {
         DateInterval di = new DateInterval();
         DateTime startdate = Now;
         startdate = startdate.AddMonths(-1);
         startdate = new DateTime(startdate.Year, startdate.Month, 1, 0, 0, 0);
         DateTime enddate = startdate.AddMonths(1).AddDays(-1);
         di.StartDate = BuildStartDate(startdate);
         di.EndDate = BuildEndDate(enddate);
         return di;
      }

      public static DateInterval GetLastYear()
      {
         DateInterval di = new DateInterval();
         DateTime startdate= new DateTime(Now.Year, 1, 1);
         DateTime enddate = startdate.AddYears(1).AddDays(-1);
         di.StartDate = BuildStartDate(startdate);
         di.EndDate = BuildEndDate(enddate);
         return di;
      }

      public static DateInterval GetLastSemester()
      {
         DateInterval di = new DateInterval();
         int startmonth = 1;
         int endmonth = 7;
         int startyear = Now.Year;
         int endyear = startyear;

         if (Now.Month > 6)
         {
            startmonth = 7;
            endmonth = 1;
            endyear += 1;
         }
         di.StartDate = BuildStartDate(new DateTime(startyear, startmonth, 1));
         di.EndDate = BuildEndDate((new DateTime(endyear, endmonth, 1)).AddDays(-1));
         return di;
      }

      public static DateInterval GetFirstSemester()
      {
         DateInterval di = new DateInterval();
         di.StartDate = BuildStartDate(new DateTime(Now.Year, 1, 1));
         di.EndDate = BuildEndDate((new DateTime(Now.Year, 7, 1)).AddDays(-1));
         return di;
      }

      public static DateInterval GetSecondSemester()
      {
         DateInterval di = new DateInterval();
         di.StartDate = BuildStartDate(new DateTime(Now.Year, 7, 1));
         di.EndDate = BuildEndDate((new DateTime(Now.Year + 1, 1, 1)).AddDays(-1));
         return di;
      }

      /// <summary>
      /// costruisce una data nel formato gg mm yyyy del parametro passato
      /// e con ora associata 23:59:59 la data di fine di un giorno per il
      /// filtro
      /// </summary>
      /// <param name="d"></param>
      /// <returns></returns>
      public static DateTime BuildStartDate(DateTime d)
      {
        DateTime dt = new DateTime(d.Year, d.Month, d.Day, 0, 0, 0);
        return dt;
      }

      /// <summary>
      /// costruisce una data nel formato gg mm yyyy del parametro passato
      /// e con ora associata 0:00:00 la data di inizio di un giorno per il
      /// filtro
      /// </summary>
      /// <param name="d"></param>
      /// <returns></returns>
      public static DateTime BuildEndDate(DateTime d)
      {
         DateTime dt = new DateTime(d.Year, d.Month, d.Day, 23, 59, 59);
         return dt;
      }
        
   }
}
