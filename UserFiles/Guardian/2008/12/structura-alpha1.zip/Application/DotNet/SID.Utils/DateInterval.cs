using System;
using System.Text;

namespace SID.Utils
{
   public class DateInterval
   {
      public DateTime StartDate
      {
         get { return mStartDate; }
         set { mStartDate = value; }
      }
      private DateTime mStartDate;

      public DateTime EndDate
      {
         get { return mEndDate; }
         set { mEndDate = value; }
      }
      private DateTime mEndDate;
   }
}
