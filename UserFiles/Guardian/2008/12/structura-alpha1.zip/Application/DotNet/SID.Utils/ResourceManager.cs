using System;
using System.IO;
using System.Reflection;

namespace SID.Utils
{
	/// <summary>
	/// Descrizione di riepilogo per ResourceManager.
	/// </summary>
	public class ResourceManager
	{
		public ResourceManager()
		{
			//
			// TODO: aggiungere qui la logica del costruttore
			//
		}

		public static void WriteResourceToFile(System.Reflection.Assembly assembly, string resourceName, string fileName) 
		{
			using (Stream s = assembly.GetManifestResourceStream(resourceName)) 
			{
				if (s != null) 
				{
					byte[] buffer = new byte[s.Length];
					char[] sb = new char[s.Length];
					s.Read(buffer, 0, (int)(s.Length));
					using(System.IO.FileStream sw = new FileStream(fileName, System.IO.FileMode.Create)) 
					{
						sw.Write(buffer,0,buffer.Length);
						sw.Flush();
					}
				}   
			}
		}
	}
}
