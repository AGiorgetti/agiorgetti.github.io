using System;
using System.ComponentModel;
using System.Reflection;
using System.Collections;

namespace SID.Utils
{
  [Serializable()]
  public class BaseClassCompare : IComparer
  {
    #region Private Fields
    PropertyInfo propInfo;
    #endregion
    #region Costructor
    /// <summary>
    /// Imposta la propriet� 
    /// </summary>
    /// <param name="key">la propriet� da ordinare</param>
    /// <param name="item">l'oggetto da ordinare</param>
    public BaseClassCompare(string key, object item)
    {
      //recupero la propriet�
      Type _type = item.GetType();
      propInfo = _type.GetProperty(key);
      if (propInfo == null)
      {
        throw new ArgumentException("Property not found", key);
      }

    }
    #endregion
    #region Comparer
    /// <summary>
    /// Implementazione dell'interfaccia IComparer
    /// </summary>
    /// <param name="x">primo oggetto</param>
    /// <param name="y">secondo oggetto</param>
    /// <returns></returns>
    public int Compare(object x, object y)
    {
      IComparable a = (IComparable)propInfo.GetValue(x,null);
      return a.CompareTo(propInfo.GetValue(y,null));
    }
 

  }
  #endregion
} // end class - BaseClassCompare

