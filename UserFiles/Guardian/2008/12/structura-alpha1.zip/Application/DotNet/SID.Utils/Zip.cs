using System;
using System.Collections;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace SID.Utils
{
	namespace Zip
	{
		public class ZipUtil
		{
			public delegate void FileListGeneratedEventHandler(ArrayList list);
			public delegate void FileZippedEventHandler(string file);
			
			public static event FileListGeneratedEventHandler FileListGenerated;
			public static event FileZippedEventHandler FileZipped;

			private static void OnFileListGenerated(ArrayList list)
			{
				if (FileListGenerated != null)
					FileListGenerated(list);
			}

			private static void OnFileZipped(string file)
			{
				if (FileZipped != null)
					FileZipped(file);
			}

			/// <summary>
			/// effettua lo zip delle cartelle
			/// </summary>
			/// <param name="inputFolderPath"></param>
			/// <param name="outputPathAndFile"></param>
			/// <param name="exclusionList">lista di directory di esclusione</param>
			/// <param name="password"></param>
			public static void ZipFiles(string inputFolderPath, string outputPathAndFile, System.Collections.Specialized.StringCollection exclusionList, string password)
			{
				PreProcessExclusionList(ref exclusionList);
				ArrayList ar = GenerateFileList(inputFolderPath, exclusionList); // generate file list
				OnFileListGenerated(ar);
				int TrimLength = (new DirectoryInfo(inputFolderPath)).ToString().Length; //(Directory.GetParent(inputFolderPath)).ToString().Length;
				// find number of chars to remove     // from orginal file path
				TrimLength += 1; //remove '\'
				FileStream ostream;
				byte[] obuffer;
				string outPath = outputPathAndFile; //inputFolderPath + @"\" + outputPathAndFile;
				ZipOutputStream oZipStream = new ZipOutputStream(File.Create(outPath)); // create zip stream
				if (password != null && password != String.Empty)
					oZipStream.Password = password;
				oZipStream.SetLevel(9); // maximum compression
				ZipEntry oZipEntry;
				foreach (string Fil in ar) // for each file, generate a zipentry
				{
					oZipEntry = new ZipEntry(Fil.Remove(0, TrimLength));
					oZipStream.PutNextEntry(oZipEntry);

					if (!Fil.EndsWith(@"/")) // if a file ends with '/' its a directory
					{
						ostream = File.OpenRead(Fil);
						obuffer = new byte[ostream.Length];
						ostream.Read(obuffer, 0, obuffer.Length);
						oZipStream.Write(obuffer, 0, obuffer.Length);
					}

					OnFileZipped(Fil);
				}
				oZipStream.Finish();
				oZipStream.Close();
			}

			private static void PreProcessExclusionList(ref System.Collections.Specialized.StringCollection exclusionList)
			{
				for(int i = 0; i < exclusionList.Count; i++)
					exclusionList[i] = exclusionList[i].TrimEnd(new char[] {'/', '\\'});
			}

			private static ArrayList GenerateFileList(string Dir, System.Collections.Specialized.StringCollection exclusionList)
			{
				ArrayList fils = new ArrayList();
				bool Empty = true;
				foreach (string file in Directory.GetFiles(Dir)) // add each file in directory
				{
					//check for the exclusion list
					if (!Exclude(file, exclusionList))
					{
						fils.Add(file);
						Empty = false;
					}
				}

				if (Empty)
				{
					if (Directory.GetDirectories(Dir).Length == 0)
						// if directory is completely empty, add it
					{
						//todo: check for the exclusion list
						if (!Exclude(Dir + @"/", exclusionList))
							fils.Add(Dir + @"/");
					}
				}

				foreach (string dirs in Directory.GetDirectories(Dir)) // recursive
				{
					foreach (string file in GenerateFileList(dirs, exclusionList))
					{
						//check for the exclusion list
						if (!Exclude(file, exclusionList))
							fils.Add(file);
					}
				}
				return fils; // return file list
			}

			private static bool Exclude(string filename, System.Collections.Specialized.StringCollection exclusionList)
			{
				for (int i = 0; i < exclusionList.Count; i++)
					if (filename.StartsWith(exclusionList[i]))
						return true;
				return false;
			}

			public static void UnZipFiles(string zipPathAndFile, string outputFolder, string password, bool deleteZipFile)
			{
				ZipInputStream s = new ZipInputStream(File.OpenRead(zipPathAndFile));
				if (password != null && password != String.Empty)
					s.Password = password;
				ZipEntry theEntry;
				string tmpEntry = String.Empty;
				while ((theEntry = s.GetNextEntry()) != null)
				{
					string directoryName = outputFolder;
					string fileName = Path.GetFileName(theEntry.Name);
					// create directory 
					if (directoryName != "")
					{
						Directory.CreateDirectory(directoryName);
					}
					if (fileName != String.Empty)
					{
//						if (theEntry.Name.IndexOf(".ini") < 0)
//						{
							string fullPath = directoryName + "\\" + theEntry.Name;
							fullPath = fullPath.Replace("\\ ", "\\");
							string fullDirPath = Path.GetDirectoryName(fullPath);
							if (!Directory.Exists(fullDirPath)) Directory.CreateDirectory(fullDirPath);
							FileStream streamWriter = File.Create(fullPath);
							int size = 2048;
							byte[] data = new byte[2048];
							while (true)
							{
								size = s.Read(data, 0, data.Length);
								if (size > 0)
								{
									streamWriter.Write(data, 0, size);
								}
								else
								{
									break;
								}
							}
							streamWriter.Close();
//						}
					}
				}
				s.Close();
				if (deleteZipFile)
					File.Delete(zipPathAndFile);
			}
		}
	}
}
