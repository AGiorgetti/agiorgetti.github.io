using System;
using System.Text;

namespace SID.Utils
{
   public class StringUtils
   {
      /// <summary>
      /// formatta una stringa modificando i caratteri impossibili da rappresentare o codificandoli 
      /// opportunamente
      /// </summary>
      /// <param name="str"></param>
      /// <returns></returns>
      public static string FormatForDisplay(string str)
      {
         return str.Replace("&", "&amp;");
      }
   }
}
