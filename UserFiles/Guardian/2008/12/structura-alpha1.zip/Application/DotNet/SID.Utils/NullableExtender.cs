using System;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Windows.Forms;

namespace SID.Utils
{
	/// <summary>
	/// Descrizione di riepilogo per Component1.
	/// </summary>
	[ProvideProperty("NullableBinding", typeof(TextBox))]
	public class NullableExtender : System.ComponentModel.Component, IExtenderProvider
	{
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public NullableExtender(System.ComponentModel.IContainer container)
		{
			///
			/// Necessario per il supporto della finestra di progettazione per la composizione della classe Windows.Forms
			///
			container.Add(this);
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		public NullableExtender()
		{
			///
			/// Necessario per il supporto della finestra di progettazione per la composizione della classe Windows.Forms
			///
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent
			//
		}

		/// <summary> 
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		#region Codice generato da Progettazione componenti
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		private System.Collections.Hashtable _nullables = new Hashtable();

		#region IExtenderProvider Members

		public bool CanExtend(object extendee)
		{
			return extendee is TextBox;
		}

		#endregion

		/// <summary>
		/// When parsing, set the value to null if the value is empty.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void NullableExtender_Parse(object sender, ConvertEventArgs e)
		{
			if (e.Value == null || e.Value.ToString().Length == 0)
			{
				e.Value = null;
			}
		}

		private void NullableExtender_Format(object sender, ConvertEventArgs e)
		{
			if (e.Value == null || e.Value.ToString().Length == 0)
			{
				e.Value = null;
			}
		}

		#region "Extender property"
		/// <summary>
		/// This is the extender property. It is actually a method because it takes the control.
		/// </summary>
		/// <param name="control"></param>
		[DefaultValue(false),
		Category("Data")]
		public bool GetNullableBinding(Control control)
		{
			bool nullableBinding = false;
			if (_nullables.ContainsKey(control) == true)
				nullableBinding = (bool)_nullables[control];
			return nullableBinding;
		}

		/// <summary>
		/// This is the extender property. It is actually a method because it takes the control.
		/// </summary>
		/// <param name="control"></param>
		/// <param name="nullable"></param>
		public void SetNullableBinding(Control control, bool nullable)
		{
			if (_nullables.ContainsKey(control))
				_nullables[control] = nullable;
			else
				_nullables.Add(control, nullable);
			if (nullable)
			{
				Binding binding = control.DataBindings["Text"];
				if (binding != null)
				{
					// When the NullableBinding property is set to true and the textbox already has
					// data bound to the "Text" property
					binding.Parse +=new ConvertEventHandler(NullableExtender_Parse);  //+= NullableExtender_Parse;
					binding.Format += new ConvertEventHandler(NullableExtender_Format);
				}	
				else
				{
					// If the "Text" property doesn't already have any data bound to it.
					control.DataBindings.CollectionChanged +=new CollectionChangeEventHandler(DataBindings_CollectionChanged);  //+= DataBindings_CollectionChanged;
				}
			}
		}

		/// <summary>
		/// Adds the Parse function on CollectionChanged event.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void DataBindings_CollectionChanged(object sender, CollectionChangeEventArgs e)
		{
			ControlBindingsCollection bindings = (ControlBindingsCollection)sender;
			Binding binding = bindings["Text"];
			if (binding != null)
			{
				// When the NullableBinding property is set to true and the textbox already has
				binding.Parse +=new ConvertEventHandler(NullableExtender_Parse);   //NullableExtender_Parse;
				binding.Format += new ConvertEventHandler(NullableExtender_Format);
			}	
		}

		#endregion
	}
}
