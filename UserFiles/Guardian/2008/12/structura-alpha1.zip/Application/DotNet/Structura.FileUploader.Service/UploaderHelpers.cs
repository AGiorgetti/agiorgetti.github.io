﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Structura.FileUploader.Service
{
	public class UploaderHelpers
	{
		public static int WriteDataChunk(string filename, byte[] data, int numBytes, bool append, string folder)
		{
			if (!System.IO.Directory.Exists(folder))
				System.IO.Directory.CreateDirectory(folder);
			string filepath = Path.Combine(folder, filename);
			//if the file doesn't exist create it, otherwise append to it
			FileMode fm = FileMode.Create;
			if (append)
				fm = FileMode.Append;
			using (FileStream fs = new FileStream(filepath, fm, FileAccess.Write))
			{
				fs.Write(data, 0, numBytes);
			}
			return numBytes;
		}

		public static long GetBytes(string filename, string folder)
		{
			string filepath = Path.Combine(folder, filename);
			if (!File.Exists(filepath))
				return 0;
			FileStream fs = System.IO.File.OpenRead(filepath);
			long lenght = fs.Length;
			fs.Close();
			return lenght;
		}
	}
}
