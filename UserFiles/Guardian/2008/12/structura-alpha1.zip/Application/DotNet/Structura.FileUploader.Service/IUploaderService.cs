﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Structura.FileUploader.Service
{
	// NOTE: If you change the interface name "IService1" here, you must also update the reference to "IService1" in App.config.
	[ServiceContract]
	public interface IUploaderService
	{
		[OperationContract]
		int UploadDataChunk(string filename, byte[] data, int numBytes, bool append, bool complete);

		//[OperationContract(Name = "UploadDatachunck2")]
		//int UploadDatachunck(string filename, string data, int numBytes, bool append);

		[OperationContract]
		long GetBytes(string filename);

		// [OperationContract]
		// string Test();
	}

	//[ServiceContract]
	//public interface IExtUploaderService : IUploaderService
	//{
	//   [OperationContract]
	//   string Test();
	//}
}
