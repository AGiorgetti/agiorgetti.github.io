﻿DotNet Project

Basic services for uploading files to a server folder