﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.IO;
using System.ServiceModel.Activation;
using System.Configuration;
using System.Web.Configuration;
using System.Web.Hosting;

namespace Structura.FileUploader.Service
{
	//[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	//public class ExtUploaderService : UploaderService, IExtUploaderService
	//{
	//   #region IExtUploaderService Members

	//   public string Test()
	//   {
	//      return "Test";
	//   }

	//   #endregion
	//}

	// NOTE: If you change the class name "Service1" here, you must also update the reference to "Service1" in App.config.
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	public class UploaderService : IUploaderService
	{
		static UploaderService()
		{
			DestPath = GetDestFolder();
		}

		public static string DestPath { get; set; }

		/// <summary>
		/// upload the data to a file
		/// </summary>
		/// <param name="filename"></param>
		/// <param name="data"></param>
		/// <param name="numBytes"></param>
		/// <param name="append"></param>
		/// <returns>the number of bytes written</returns>
		public virtual int UploadDataChunk(string filename, byte[] data, int numBytes, bool append, bool complete)
		{
			return UploaderHelpers.WriteDataChunk(filename, data, numBytes, append, DestPath);
		}

		public virtual long GetBytes(string filename)
		{
			return UploaderHelpers.GetBytes(filename, DestPath);
		}

		protected static AppSettingsSection GetAppSettings()
		{
			VirtualPathExtension extension = OperationContext.Current.Host.Extensions.Find<VirtualPathExtension>();
			Configuration config = WebConfigurationManager.OpenWebConfiguration(extension.VirtualPath);
			return config.AppSettings;
		}

		protected static string GetDestFolder()
		{
			string DestPath = GetAppSettings().Settings[FileServicesSettings.FileServiceStoragePath].Value;
			return GetLocalFolder(DestPath);
		}

		protected static string GetLocalFolder(string relativePath)
		{
			string folder = relativePath;
			if (relativePath.StartsWith("~"))
				folder = relativePath.Replace("~", HostingEnvironment.ApplicationPhysicalPath);
			return folder;
		}
		
		//public int UploadDatachunck(string filename, string data, int numBytes, bool append)
		//{
		//   string folder = GetDestFolder();

		//   byte[] arr = Convert.FromBase64String(data);

		//   return UploaderHelpers.WriteDataChunk(filename, arr, numBytes, append, folder);
		//}
	}
}
