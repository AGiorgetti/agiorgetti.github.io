﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Services;
using System.ComponentModel;
using System.Configuration;

namespace Structura.FileUploader.Service
{
	/// <summary>
	/// Summary description for Service1
	/// </summary>
	[WebService(Namespace = "http://tempuri.org/")]
	[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
	[ToolboxItem(false)]
	// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
	// [System.Web.Script.Services.ScriptService]
	public class UploaderWebService : System.Web.Services.WebService, IUploaderService
	{
		static UploaderWebService()
		{
			DestPath = ConfigurationManager.AppSettings[FileServicesSettings.FileServiceStoragePath];
		}

		public static string DestPath { get; set; }

		/// <summary>
		/// upload the data to a file
		/// </summary>
		/// <param name="filename"></param>
		/// <param name="data"></param>
		/// <param name="numBytes"></param>
		/// <param name="append"></param>
		/// <returns>the number of bytes written</returns>
		[WebMethod]
		public virtual int UploadDataChunk(string filename, byte[] data, int numBytes, bool append, bool complete)
		{
			string folder = Server.MapPath(DestPath);

			return UploaderHelpers.WriteDataChunk(filename, data, numBytes, append, folder);
		}

		[WebMethod]
		public virtual long GetBytes(string filename)
		{
			string folder = Server.MapPath(DestPath);

			return UploaderHelpers.GetBytes(filename, folder);
		}
	}
}
