﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Structura.FileUploader.Service
{
	public class UploaderHandler : IHttpHandler
	{

		static UploaderHandler()
		{
			DestPath = System.Configuration.ConfigurationManager.AppSettings[FileServicesSettings.FileServiceStoragePath];
		}

		public static string DestPath { get; set; }
		
		protected HttpContext Context;

		public virtual void ProcessRequest(HttpContext context)
		{
			Context = context;
			string uploadPath = context.Server.MapPath(DestPath);
			FileUpload fileUpload = new FileUpload();
			fileUpload.FileUploadCompleted += new FileUploadCompletedEvent(FileUpload_FileUploadCompleted);
			fileUpload.ProcessRequest(context, uploadPath);
		}

		protected virtual void FileUpload_FileUploadCompleted(object sender, FileUploadCompletedEventArgs args)
		{
			// throw new NotImplementedException();
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}
}
