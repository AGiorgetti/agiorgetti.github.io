﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TestApp.Infrastructure;
using Structura.Infrastructure.IOC;
using Structura.Infrastructure.ViewModel;

namespace TestApp.InvoiceModule
{
   public class MenuManageClients : TestApp.Infrastructure.IExecutable
   {
      public MenuManageClients(IIoC ioc)
      {
         _ioc = ioc;
      }

      private IIoC _ioc;
      #region IExecutable Members

      public object Execute()
      {
         return new TestApp.InvoiceModule.View.ManageClients(_ioc);
      }

      #endregion
   }

   public class MenuManageInvoices : TestApp.Infrastructure.IExecutable
   {
      public MenuManageInvoices(IIoC ioc)
      {
         _ioc = ioc;
      }

      private IIoC _ioc;
      #region IExecutable Members

      public object Execute()
      {
         return new TestApp.InvoiceModule.View.ManageInvoices(_ioc);
      }

      #endregion
   }
}
