﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Structura.Infrastructure.ViewModel;
using Structura.Infrastructure.IOC;
using TestApp.Silverlight.InvoiceModule.Controller;
using TestApp.Entities;

namespace TestApp.InvoiceModule.View
{
   /// <summary>
   /// Interaction logic for EditClient.xaml
   /// </summary>
   public partial class EditClient : ViewExt
   {
      public EditClient(IIoC ioc) :
			base(ioc)
      {
         InitializeComponent();

         Controller = new EditClientController();
         (Controller as EditClientController).Init(null);
      }

      public EditClient(IIoC ioc, Client client) :
         base(ioc)
      {
         InitializeComponent();

         Controller = new EditClientController();
         (Controller as EditClientController).Init(client);
      }

      private void btnSave_Click(object sender, RoutedEventArgs e)
      {
         Waiting.Start();
         (Controller as EditClientController).SaveAsync();
      }

      private void btnCancel_Click(object sender, RoutedEventArgs e)
      {
         Close();
      }

      public override void UpdateInterface()
      {
         Waiting.Stop();
      }
   }
}
