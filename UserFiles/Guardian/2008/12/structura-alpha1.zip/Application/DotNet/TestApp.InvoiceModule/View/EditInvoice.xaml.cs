﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Structura.Infrastructure.ViewModel;
using Structura.Infrastructure.IOC;
using TestApp.Silverlight.InvoiceModule.Controller;
using TestApp.Entities;

namespace TestApp.InvoiceModule.View
{
   /// <summary>
   /// Interaction logic for EditInvoice.xaml
   /// </summary>
   public partial class EditInvoice : ViewExt
   {
      public EditInvoice(IIoC ioc) :
			base(ioc)
      {
         InitializeComponent();
         Waiting.Start();
         Controller = new EditInvoiceController();
         (Controller as EditInvoiceController).Init(null);
      }

      public EditInvoice(IIoC ioc, Invoice invoice) :
         base(ioc)
      {
         InitializeComponent();

         Waiting.Start();
         Controller = new EditInvoiceController();
         (Controller as EditInvoiceController).Init(invoice);
      }

      private void btnSave_Click(object sender, RoutedEventArgs e)
      {
         Waiting.Start();
         (Controller as EditInvoiceController).SaveAsync();
      }

      private void btnCancel_Click(object sender, RoutedEventArgs e)
      {
         Close();
      }

      public override void UpdateInterface()
      {
         Waiting.Stop();
      }

      private void BtnAddInvoiceItem_Click(object sender, RoutedEventArgs e)
      {
         (Controller as EditInvoiceController).AddInvoiceItem();
      }

      private void DeleteItemClick(object sender, RoutedEventArgs e)
      {
         InvoiceItem ii = ((sender as Button).Tag as InvoiceItem);
         string msg = string.Format("Are you sure you want to delete the element: {0} {1} ?", ii.Code, ii.Name);
         if (MessageBox.Show(msg, "confirm", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
         {
            GridInvoiceItems.Focus();
            (Controller as EditInvoiceController).RemoveInvoiceItem(ii);
            GridInvoiceItems.InvalidateArrange();
         }
      }
   }
}
