﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Structura.Infrastructure.ViewModel;
using TestApp.Silverlight.InvoiceModule.Controller;
using Structura.Infrastructure.IOC;
using TestApp.Entities;

namespace TestApp.InvoiceModule.View
{
   /// <summary>
   /// Interaction logic for ManageInvoices.xaml
   /// </summary>
   public partial class ManageInvoices : Structura.Infrastructure.ViewModel.ViewExt, IManageInvoicesView
   {
      public ManageInvoices(IIoC ioc)
         : base(ioc)
      {
         InitializeComponent();
         _controller = new ManageInvoicesController();
         Controller = _controller;
         GetData();
      }

      private ManageInvoicesController _controller;

      private void GetData()
      {
         Waiting.Start();
         _controller.GetDataAsync();
      }

      public override void UpdateInterface()
      {
         Waiting.Stop();
      }

      //private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
      //{
      //   double h = LayoutRoot.RowDefinitions[1].ActualHeight;
      //   ElementsGrid.Height = h;
      //   ElementsGrid.MaxHeight = h;
      //}

      private void Edit_Click(object sender, RoutedEventArgs e)
      {
         ElementsGrid.Focus();
         _controller.EditInvoice((sender as Button).Tag as Invoice);
      }

      private void Delete_Click(object sender, RoutedEventArgs e)
      {
         Invoice invoice = (sender as Button).Tag as Invoice;
         string msg = string.Format("Are you sure you want to delete the invoice number: {0} ?", invoice.Number);
         if (MessageBox.Show(msg, "confirm", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
         {
            // remember the bug on the datagrid diplay/render
            ElementsGrid.Focus();
            Waiting.Start();
            _controller.DeleteAsync(invoice);
         }
      }

      private void Refresh_Click(object sender, RoutedEventArgs e)
      {
         GetData();
      }

      private void Add_Click(object sender, RoutedEventArgs e)
      {
         // remember the bug on the datagrid diplay/render
         ElementsGrid.Focus();
         _controller.CreateInvoice();
      }

      #region IManageInvoicesView Members

      public void ShowEditInvoice(Invoice invoice)
      {
         var ec = new View.EditInvoice(IOC, invoice);
         ec.Title = (invoice == null) ? "New Invoice" : "Edit Invoice";
         ec.ShowDialog();
      }

      #endregion
   }
}
