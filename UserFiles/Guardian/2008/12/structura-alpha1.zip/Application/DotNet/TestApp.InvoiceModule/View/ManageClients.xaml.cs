﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Structura.Infrastructure.ViewModel;
using TestApp.Silverlight.InvoiceModule.Controller;
using TestApp.Entities;
using Structura.Infrastructure.IOC;

namespace TestApp.InvoiceModule.View
{
   /// <summary>
   /// Interaction logic for ManageClients.xaml
   /// </summary>
   public partial class ManageClients : ViewExt, IManageClientsView
   {
      private ManageClientsController _controller;
      
      public ManageClients(IIoC ioc)
         : base(ioc)
      {
         InitializeComponent();

         _controller = new ManageClientsController();
         Controller = _controller;
         _controller = Controller as ManageClientsController;
         GetData();
      }

      private void GetData()
      {
         Waiting.Start();
         _controller.GetClientsAsync();
      }

      public override void UpdateInterface()
      {
         Waiting.Stop();
      }

      #region IManageClientsView Members

      public void ShowEditClient(Client client)
      {
         var ec = new View.EditClient(IOC, client);
         ec.Title = (client == null) ? "New Client" : "Edit Client";
         ec.ShowDialog();
      }

      #endregion

      private void UserControl_SizeChanged(object sender, SizeChangedEventArgs e)
      {
         double h = LayoutRoot.RowDefinitions[1].ActualHeight;
         ElementsGrid.Height = h;
         ElementsGrid.MaxHeight = h;
      }

      private void Edit_Click(object sender, RoutedEventArgs e)
      {
         ElementsGrid.Focus();
         _controller.EditClient((sender as Button).Tag as Client);
      }

      private void Delete_Click(object sender, RoutedEventArgs e)
      {
         Client client = (sender as Button).Tag as Client;
         string msg = string.Format("Are you sure you want to delete client\n{0} {1}?", client.Surname, client.Name);
         if (MessageBox.Show(msg, "confirm", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
         {
            ElementsGrid.Focus();
            Waiting.Start();
            _controller.DeleteClientAsync(client);
         }
      }

      private void Refresh_Click(object sender, RoutedEventArgs e)
      {
         GetData();
      }

      private void Add_Click(object sender, RoutedEventArgs e)
      {
         ElementsGrid.Focus();
         _controller.CreateClient();
      }
   }
}
