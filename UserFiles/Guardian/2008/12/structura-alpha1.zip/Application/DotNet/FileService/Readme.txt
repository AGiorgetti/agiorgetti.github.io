﻿Per i siti web e le parti del sito che necessitano di visualizzaizone immagini non è probabilemnte conveniente richiedere gli stream 
o le immagini con le funzioni GetImage o GetStream.
è più semplice che il FileService effettui una doppia copia delle immagini che vengono inserite e che devono essere accessibili all'estrno.

una copia sulla cartella/repository privato.
una copia nel repository ad accesso pubblico.
I file nel repository pubblico vengono denominati con l'id relativo alla risorsa di appartenenza ed estensione proprio del file originario
(avremo così guid.png per le immagini etc etc...)

il sistema di cartelle è il seguente

~\Storage									-generica cartella ad accesso pubblico
~\Storage\Maintenance\Designer      -cartella in cui vanno inseiriti tutti i file immagine propri del designer per accesso al sito web.