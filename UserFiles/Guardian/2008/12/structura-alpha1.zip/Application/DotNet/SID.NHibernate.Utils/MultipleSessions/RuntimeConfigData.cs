using System;
using System.Text;
using System.Collections.Specialized;

namespace SID.NHibernateUtils.MultipleSessions
{
	public class RuntimeConfigData
	{
		public string Id;

		/// <summary>
		/// se impostato a true viene automaticamente aperta una transazione la prima volta che si
		/// chiede una GetSessionFrom() al session manager,altrimenti le transazioni vanno aperte e 
		/// chiuse manualmente
		/// </summary>
		public bool Transactional = false;

		/// <summary>
		/// specifica se effettuare il caching della sessione o meno, la sessione viene cachata sulla 
		/// base della connection string
		/// </summary>
		public bool UseSessionCaching = true;

		public NameValueCollection Properties
		{
			get { return mProperties; }
		}
		private NameValueCollection mProperties = new NameValueCollection();

		public StringCollection Assemblies
		{
			get { return mAssemblies; }
		}
		private StringCollection mAssemblies = new StringCollection();

		public bool Equals(RuntimeConfigData obj)
		{
			return Equals(obj.Id, Id);
		}

		public override bool Equals(object obj)
		{
			if (obj.GetType() != typeof(RuntimeConfigData)) return false;
			return Equals((RuntimeConfigData)obj);
		}

		public override int GetHashCode()
		{
			return (Id != null ? Id.GetHashCode() : 0);
		}
	}
}
