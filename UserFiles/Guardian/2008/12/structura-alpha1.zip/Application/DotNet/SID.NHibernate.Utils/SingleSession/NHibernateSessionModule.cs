using System;
using System.Web;

namespace SID.NHibernateUtils.SingleSession
{
   /// <summary>
   /// Implements the Open-Session-In-View pattern using <see cref="NHibernateSessionManager" />.
   /// Assumes that each HTTP request is given a single transaction for the entire page-lifecycle.
   /// Inspiration for this class came from Ed Courtenay at 
   /// http://sourceforge.net/forum/message.php?msg_id=2847509.
   /// </summary>
   public class NHibernateSessionModule : IHttpModule
   {
      public void Init(HttpApplication context)
      {
         context.BeginRequest += new EventHandler(BeginTransaction);
         context.EndRequest += new EventHandler(CommitAndCloseSession);
         context.PostRequestHandlerExecute += new EventHandler(FlushSession);
      }

      /// <summary>
      /// Opens a session within a transaction at the beginning of the HTTP request.
      /// This doesn't actually open a connection to the database until needed.
      /// </summary>
      private void BeginTransaction(object sender, EventArgs e)
      {
         NHibernateSessionManager.Instance.BeginTransaction();
      }

      /// <summary>
      /// Commits and closes the NHibernate session provided by the supplied <see cref="NHibernateSessionManager"/>.
      /// Assumes a transaction was begun at the beginning of the request; but a transaction or session does
      /// not *have* to be opened for this to operate successfully.
      /// </summary>
      private void CommitAndCloseSession(object sender, EventArgs e)
      {
         try
         {
            NHibernateSessionManager.Instance.CommitTransaction();
         }
         finally
         {
            NHibernateSessionManager.Instance.CloseSession();
         }
      }

      /// <summary>
      /// flush any nhib session to modify the status of object (if binded to asp.net session state)
      /// before they get persisted to aspnet session repository (inproc, outofprocess, sqlstate etc..)
      /// in such a way the object status in nhib is the same as in the session object otherwise we
      /// ca have a mismatch between the 2..ie object persisted in aspnet session state before nhib gets flushed
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>
      private void FlushSession(object sender, EventArgs e)
      {
         NHibernateSessionManager.Instance.FlushSession();
      }

      public void Dispose() { }
   }
}
