using System;
using System.Text;
using System.Configuration;

namespace SID.NHibernateUtils.MultipleSessions
{
   public sealed class SessionFactoriesCollection : System.Collections.CollectionBase
   {
     public int Add( SessionFactoryElement val )  
     {
       return( List.Add( val ) );
     }

     public int IndexOf( SessionFactoryElement val )  
     {
       return( List.IndexOf( val ) );
     }

     public void Insert( int index, SessionFactoryElement val )  
     {
       List.Insert( index, val );
     }

     public void Remove( SessionFactoryElement val )  
     {
       List.Remove( val );
     }

     public bool Contains( SessionFactoryElement val )  
     {
       return( List.Contains( val ) );
     }

     public SessionFactoryElement this[ int index ]  
     {
       get  
       {
         return( (SessionFactoryElement) List[index] );
       }
       set  
       {
         List[index] = value;
       }
     }
		
   }
}
