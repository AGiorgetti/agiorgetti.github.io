using System;
using System.Text;
using System.Configuration;
using System.Xml;
using System.Xml.Serialization;

namespace SID.NHibernateUtils.MultipleSessions
{
   public class SessionFactoryElement //: ConfigurationElement
   {
      public SessionFactoryElement() { }

      public SessionFactoryElement(string name, string configPath)
      {
         Name = name;
         FactoryConfigPath = configPath;
      }

      //[ConfigurationProperty("name", IsRequired = true, IsKey = true, DefaultValue = "Not Supplied")]
      [XmlAttribute()]
      public string Name
      {
         get { return _name; }
         set { _name = value; }
      }
      private string _name;

      //[ConfigurationProperty("factoryConfigPath", IsRequired = true, DefaultValue = "Not Supplied")]
     [XmlAttribute()]
      public string FactoryConfigPath
      {
         get { return _factoryConfigPath; }
         set { _factoryConfigPath = value; }
      }
      private string _factoryConfigPath;

      //[ConfigurationProperty("isTransactional", IsRequired = false, DefaultValue = false)]
     [XmlAttribute()]
      public bool IsTransactional
      {
         get { return _isTransactional; }
         set { _isTransactional = value; }
      }
      private bool _isTransactional;
   }
}
