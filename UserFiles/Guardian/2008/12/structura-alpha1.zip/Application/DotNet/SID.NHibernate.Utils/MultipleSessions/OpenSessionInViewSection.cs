using System;
using System.Text;
using System.Configuration;

namespace SID.NHibernateUtils.MultipleSessions
{
   /// <summary>
   /// Encapsulates a section of Web/App.config to declare which session factories are to be created.
   /// Kudos go out to 
   /// http://msdn2.microsoft.com/en-us/library/system.configuration.configurationcollectionattribute.aspx
   /// for this technique - it was by far the best overview of the subject.
   /// </summary>
//   public class OpenSessionInViewSection : ConfigurationSection
//   {
//      [ConfigurationProperty("sessionFactories", IsDefaultCollection = false)]
//      [ConfigurationCollection(typeof(SessionFactoriesCollection), AddItemName = "sessionFactory",
//          ClearItemsName = "clearFactories")]
//      public SessionFactoriesCollection SessionFactories
//      {
//         get
//         {
//            SessionFactoriesCollection sessionFactoriesCollection =
//                (SessionFactoriesCollection)base["sessionFactories"];
//            return sessionFactoriesCollection;
//         }
//      }
//   }

  public class OpenSessionInViewSection
  {
    private SessionFactoriesCollection _SessionFactories;

    public SessionFactoriesCollection SessionFactories
    {
      get
      {
        if (_SessionFactories == null) { _SessionFactories = new SessionFactoriesCollection(); }
        return _SessionFactories;
      }
      set{_SessionFactories = value;}
    }
  }
}