using System;
using System.Runtime.Remoting.Messaging;
using System.Web;
using System.Web.Caching;
using NHibernate;
using NHibernate.Cache;
using NHibernate.Cfg;
using System.Collections;
using System.IO;

namespace SID.NHibernateUtils.MultipleSessions
{
	/// <summary>
	/// Handles creation and management of sessions and transactions.  It is a singleton because 
	/// building the initial session factory is very expensive. Inspiration for this class came 
	/// from Chapter 8 of Hibernate in Action by Bauer and King.  Although it is a sealed singleton
	/// you can use TypeMock (http://www.typemock.com) for more flexible testing.
	/// </summary>
	public sealed class NHibernateSessionManager
	{
		#region "Thread-safe, lazy Singleton"

		/// <summary>
		/// This is a thread-safe, lazy singleton.  See http://www.yoda.arachsys.com/csharp/singleton.html
		/// for more details about its implementation.
		/// </summary>
		public static NHibernateSessionManager Instance
		{
			get
			{
				return Nested.NHibernateSessionManager;
			}
		}

		/// <summary>
		/// Private constructor to enforce singleton
		/// </summary>
		private NHibernateSessionManager() { }

		/// <summary>
		/// Assists with ensuring thread-safe, lazy singleton
		/// </summary>
		private class Nested
		{
			static Nested() { }
			internal static readonly NHibernateSessionManager NHibernateSessionManager =
				 new NHibernateSessionManager();
		}

		#endregion

		/// <summary>
		/// This method attempts to find a session factory in the <see cref="HttpRuntime.Cache" /> 
		/// via its config file path; if it can't be found it creates a new session factory and adds
		/// it the cache.  Note that even though this uses HttpRuntime.Cache, it should still work in 
		/// Windows applications; see http://www.codeproject.com/csharp/cacheinwinformapps.asp for an
		/// examination of this.
		/// </summary>
		/// <param name="sessionFactoryConfigPath">Path location of the factory config</param>
		private ISessionFactory GetSessionFactoryFor(string sessionFactoryConfigPath)
		{
			if (sessionFactoryConfigPath == "")
				throw new ArgumentNullException("sessionFactoryConfigPath may not be null nor empty");

			//  Attempt to retrieve a cached SessionFactory from the HttpRuntime's cache.
			ISessionFactory sessionFactory = (ISessionFactory)HttpRuntime.Cache.Get(sessionFactoryConfigPath);

			//  Failed to find a cached SessionFactory so make a new one.
			if (sessionFactory == null)
			{
				if (!File.Exists(sessionFactoryConfigPath))
					// It would be more appropriate to throw a more specific exception than ApplicationException
					throw new ApplicationException(
						 "The config file at '" + sessionFactoryConfigPath + "' could not be found");

				NHibernate.Cfg.Configuration cfg = new NHibernate.Cfg.Configuration();
				cfg.Configure(sessionFactoryConfigPath);

				//  Now that we have our Configuration object, create a new SessionFactory
				sessionFactory = cfg.BuildSessionFactory();

				if (sessionFactory == null)
				{
					throw new InvalidOperationException("cfg.BuildSessionFactory() returned null.");
				}

				HttpRuntime.Cache.Add(sessionFactoryConfigPath, sessionFactory, null, DateTime.Now.AddDays(7),
					 TimeSpan.Zero, CacheItemPriority.High, null);
			}

			return sessionFactory;
		}

		public void RegisterInterceptorOn(string sessionFactoryConfigPath, IInterceptor interceptor)
		{
			ISession session = (ISession)contextSessions[sessionFactoryConfigPath];

			if (session != null && session.IsOpen)
			{
				throw new CacheException("You cannot register an interceptor once a session has already been opened");
			}

			GetSessionFrom(sessionFactoryConfigPath, true, interceptor);
		}

		public ISession GetSessionFrom(string sessionFactoryConfigPath, bool useSessionCaching)
		{
			return GetSessionFrom(sessionFactoryConfigPath, useSessionCaching, null);
		}

		private ISession GetSessionFrom(string sessionFactoryConfigPath, bool useSessionCaching, IInterceptor interceptor)
		{
			ISession session = null;
			if (useSessionCaching)
				session = (ISession)contextSessions[sessionFactoryConfigPath];

			if (session == null)
			{
				if (interceptor != null)
				{
					session = GetSessionFactoryFor(sessionFactoryConfigPath).OpenSession(interceptor);
				}
				else
				{
					session = GetSessionFactoryFor(sessionFactoryConfigPath).OpenSession();
				}
				session.FlushMode = NHibernate.FlushMode.Never;

				if (useSessionCaching)
					contextSessions[sessionFactoryConfigPath] = session;
			}

			if (session == null)
				// It would be more appropriate to throw a more specific exception than ApplicationException
				throw new ApplicationException("session was null");

			return session;
		}

		public void CloseSessionOn(string sessionFactoryConfigPath)
		{
			ISession session = (ISession)contextSessions[sessionFactoryConfigPath];
			contextSessions.Remove(sessionFactoryConfigPath);

			if (session != null && session.IsOpen)
			{
				session.Close();
			}
		}

		public void FlushSessionOn(RuntimeConfigData data)
		{
			ISession session = (ISession)contextSessions[data.Id];

			if (session != null && session.IsOpen)
			{
				session.Flush();
			}
		}

		public void CloseSessionOn(RuntimeConfigData data)
		{
			ISession session = null;
			if (data.UseSessionCaching)
				session = (ISession)contextSessions[data.Id];
			if (contextSessions.Contains(data.Id))
				contextSessions.Remove(data.Id);

			if (session != null && session.IsOpen)
			{
				session.Close();
			}
		}

		public void CloseUncachedSession(RuntimeConfigData data, ISession s)
		{
			if (data.UseSessionCaching == false)
				if (s != null && s.IsOpen)
					s.Close();
		}

		public void FlushSessionOn(string sessionFactoryConfigPath)
		{
			ISession session = (ISession)contextSessions[sessionFactoryConfigPath];

			if (session != null && session.IsOpen)
			{
				session.Flush();
			}
		}

		public void BeginTransactionOn(string sessionFactoryConfigPath)
		{
			ITransaction transaction = (ITransaction)contextTransactions[sessionFactoryConfigPath];

			if (transaction == null)
			{
				transaction = GetSessionFrom(sessionFactoryConfigPath, true).BeginTransaction();
				contextTransactions.Add(sessionFactoryConfigPath, transaction);
			}
		}

		public void CommitTransactionOn(string sessionFactoryConfigPath)
		{
			ITransaction transaction = (ITransaction)contextTransactions[sessionFactoryConfigPath];

			try
			{
				if (transaction != null && !transaction.WasCommitted && !transaction.WasRolledBack)
				{
					transaction.Commit();
					contextTransactions.Remove(sessionFactoryConfigPath);
				}
			}
			catch (HibernateException)
			{
				RollbackTransactionOn(sessionFactoryConfigPath);
				throw;
			}
		}

		public void RollbackTransactionOn(string sessionFactoryConfigPath)
		{
			ITransaction transaction = (ITransaction)contextTransactions[sessionFactoryConfigPath];

			try
			{
				contextTransactions.Remove(sessionFactoryConfigPath);

				if (transaction != null && !transaction.WasCommitted && !transaction.WasRolledBack)
				{
					transaction.Rollback();
				}
			}
			finally
			{
				CloseSessionOn(sessionFactoryConfigPath);
			}
		}

		/// <summary>
		/// Since multiple databases may be in use, there may be one transaction per database 
		/// persisted at any one time.  The easiest way to store them is via a hashtable
		/// with the key being tied to session factory.
		/// </summary>
		private Hashtable contextTransactions
		{
			get
			{
				if (IsInWebContext())
				{
					if (HttpContext.Current.Items["CONTEXT_TRANSACTIONS"] == null)
					{
						HttpContext.Current.Items["CONTEXT_TRANSACTIONS"] = new Hashtable();
					}
					return (Hashtable)HttpContext.Current.Items["CONTEXT_TRANSACTIONS"];
				}
				else
				{
					if (CallContext.GetData("CONTEXT_TRANSACTIONS") == null)
					{
						CallContext.SetData("CONTEXT_TRANSACTIONS", new Hashtable());
					}
					return (Hashtable)CallContext.GetData("CONTEXT_TRANSACTIONS");
				}
			}
		}

		/// <summary>
		/// Since multiple databases may be in use, there may be one session per database 
		/// persisted at any one time.  The easiest way to store them is via a hashtable
		/// with the key being tied to session factory.
		/// </summary>
		private Hashtable contextSessions
		{
			get
			{
				if (IsInWebContext())
				{
					if (HttpContext.Current.Items["CONTEXT_SESSIONS"] == null)
					{
						HttpContext.Current.Items["CONTEXT_SESSIONS"] = new Hashtable();
					}
					return (Hashtable)HttpContext.Current.Items["CONTEXT_SESSIONS"];
				}
				else
				{
					if (CallContext.GetData("CONTEXT_SESSIONS") == null)
					{
						CallContext.SetData("CONTEXT_SESSIONS", new Hashtable());
					}
					return (Hashtable)CallContext.GetData("CONTEXT_SESSIONS");
				}
			}
		}

		private bool IsInWebContext()
		{
			return HttpContext.Current != null;
		}

		/// <summary>
		/// This method attempts to find a session factory in the <see cref="HttpRuntime.Cache" /> 
		/// via its config file path; if it can't be found it creates a new session factory and adds
		/// it the cache.  Note that even though this uses HttpRuntime.Cache, it should still work in 
		/// Windows applications; see http://www.codeproject.com/csharp/cacheinwinformapps.asp for an
		/// examination of this.
		/// 
		/// It uses runtime configuration instad of fileconfiguration
		/// </summary>
		/// <param name="data">configuration data</param>
		private ISessionFactory GetSessionFactoryFor(RuntimeConfigData data)
		{
			//  Attempt to retrieve a cached SessionFactory from the HttpRuntime's cache.
			ISessionFactory sessionFactory = (ISessionFactory)HttpRuntime.Cache.Get(data.Id);

			//  Failed to find a cached SessionFactory so make a new one.
			if (sessionFactory == null)
			{
				NHibernate.Cfg.Configuration cfg = GetConfiguration(data);

				//  Now that we have our Configuration object, create a new SessionFactory
				sessionFactory = cfg.BuildSessionFactory();

				if (sessionFactory == null)
				{
					throw new InvalidOperationException("cfg.BuildSessionFactory() returned null.");
				}

				HttpRuntime.Cache.Add(data.Id, sessionFactory, null, DateTime.Now.AddDays(7),
					 TimeSpan.Zero, CacheItemPriority.High, null);
			}

			return sessionFactory;
		}

		public static NHibernate.Cfg.Configuration GetConfiguration(RuntimeConfigData data)
		{
			NHibernate.Cfg.Configuration cfg = new NHibernate.Cfg.Configuration();
			for (int i = 0; i < data.Properties.Count; i++)
				cfg.SetProperty(data.Properties.GetKey(i), data.Properties[i]);
			for (int i = 0; i < data.Assemblies.Count; i++)
			{
				cfg.AddAssembly(data.Assemblies[i]);
			}
			return cfg;
		}

		public void RegisterInterceptorOn(RuntimeConfigData data, IInterceptor interceptor)
		{
			if (data.UseSessionCaching == true)
			{
				ISession session = (ISession)contextSessions[data.Id];

				if (session != null && session.IsOpen)
				{
					throw new CacheException("You cannot register an interceptor once a session has already been opened");
				}

				GetSessionFrom(data, interceptor);
			}
			else
				throw new ApplicationException("Unable to attach an Interceptor to a NON cached session.");
		}

		public ISession GetSessionFrom(RuntimeConfigData data)
		{
			return GetSessionFrom(data, null);
		}

		private ISession GetSessionFrom(RuntimeConfigData data, IInterceptor interceptor)
		{
			ISession session = null;
			if (data.UseSessionCaching == true)
				session = (ISession)contextSessions[data.Id];

			if (session == null)
			{
				if (interceptor != null)
				{
					session = GetSessionFactoryFor(data).OpenSession(interceptor);
				}
				else
				{
					session = GetSessionFactoryFor(data).OpenSession();
				}
				session.FlushMode = NHibernate.FlushMode.Never;

				if (data.UseSessionCaching == true)
					contextSessions[data.Id] = session;
			}

			if (session == null)
				// It would be more appropriate to throw a more specific exception than ApplicationException
				throw new ApplicationException("session was null");

			// check for transaction
			if (data.Transactional == true)
			{
				ITransaction transaction = (ITransaction)contextTransactions[data.Id];
				if (transaction == null)
				{
					transaction = session.BeginTransaction();
					contextTransactions.Add(data.Id, transaction);
				}
			}
					
			return session;
		}

		public void BeginTransactionOn(RuntimeConfigData data)
		{
			if (data.UseSessionCaching == true)
			{
				ITransaction transaction = (ITransaction)contextTransactions[data.Id];

				if (transaction == null)
				{
					transaction = GetSessionFrom(data).BeginTransaction();
					contextTransactions.Add(data.Id, transaction);
				}
			}
			else
				throw new ApplicationException("Unable to open Transaction in a NON cached session.");
		}

		public void CommitTransactionOn(RuntimeConfigData data)
		{
			ITransaction transaction = (ITransaction)contextTransactions[data.Id];

			try
			{
				if (transaction != null && !transaction.WasCommitted && !transaction.WasRolledBack)
				{
					transaction.Commit();
					contextTransactions.Remove(data.Id);
				}
			}
			catch (HibernateException)
			{
				RollbackTransactionOn(data);
				throw;
			}
		}

		public void RollbackTransactionOn(RuntimeConfigData data)
		{
			ITransaction transaction = (ITransaction)contextTransactions[data.Id];

			try
			{
				contextTransactions.Remove(data.Id);

				if (transaction != null && !transaction.WasCommitted && !transaction.WasRolledBack)
				{
					transaction.Rollback();
				}
			}
			finally
			{
				CloseSessionOn(data);
			}
		}

		public void CommitAllTransactions()
		{
			string[] ks = new string[contextSessions.Keys.Count];
			contextSessions.Keys.CopyTo(ks, 0);
			foreach (string s in ks)
			{
				CommitTransactionOn(s);
			}
		}

		public void CloseAllSessions()
		{
			string[] ks = new string[contextSessions.Keys.Count];
			contextSessions.Keys.CopyTo(ks, 0);
			foreach (string s in ks)
			{
				CloseSessionOn(s);
			}
		}

		public void FlushAllSessions()
		{
			string[] ks = new string[contextSessions.Keys.Count];
			contextSessions.Keys.CopyTo(ks, 0);
			foreach (string s in ks)
			{
				FlushSessionOn(s);
			}
		}
	}
}
