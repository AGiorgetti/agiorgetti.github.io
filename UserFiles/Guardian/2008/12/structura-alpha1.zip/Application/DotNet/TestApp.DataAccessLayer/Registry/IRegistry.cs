using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace TestApp.DataAccessLayer
{

	/// <summary>
	/// Contiene i settaggi base di tutta l'applicazione.
	/// </summary>
	public interface IRegistry
	{
		ConnectionStringSettings MaintenanceConnectionString { get; }

		String FilePathDirectory { get; }

		//ConnectionStringSettings UsersConnectionString { get; }
		/// <summary>
		/// Directory dove vengono uploadati i file, ad esempio per i report, o per altre neecssit�
		/// </summary>
		String UploadPathDirectory { get; }

		string DebugSql { get; }
	}
}
