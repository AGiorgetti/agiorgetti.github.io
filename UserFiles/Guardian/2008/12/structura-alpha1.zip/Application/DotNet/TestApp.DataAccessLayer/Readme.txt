﻿Server side code:

Registry - contiene i settaggi dell'applicativo per la connessione ai database.