﻿using System;
using System.Collections.Generic;
using System.Text;
using SID.NHibernateUtils.MultipleSessions;
using SID.BaseServices;
using SID.BaseServices.Data;
using SID.BaseServices.Data.QueryModel;
using SID.Interfaces.CommonInterfaces;
using SID.Interfaces;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using TestApp.Entities;
using NHibernate;

namespace TestApp.DataAccessLayer
{
	public class TestAppNHib : UnitOfWorkDao<TestAppNHibUoWProvider>
	{
        private static RuntimeConfigData nhibcfg
		{
			get
			{
				return ((TestAppNHibUoWProvider)iProvider).Nhibconf;
			}
		}

		public static void BuildDatabase()
		{
			Configuration cfg = NHibernateSessionManager.GetConfiguration(nhibcfg);
			SchemaExport se = new SchemaExport(cfg);
			se.Drop(false, true);
			se.Create(false, true);
		}
	}

	public class TestAppNHib<T> : UnitOfWorkDao<T, TestAppNHibUoWProvider<T>>
	{
		public static void BuildDatabase()
		{
			Configuration cfg = NHibernateSessionManager.GetConfiguration(
				((TestAppNHibUoWProvider<T>)iProvider).Nhibconf);
			SchemaExport se = new SchemaExport(cfg);
			se.Drop(false, true);
			se.Create(false, true);	
		}
	}
}
