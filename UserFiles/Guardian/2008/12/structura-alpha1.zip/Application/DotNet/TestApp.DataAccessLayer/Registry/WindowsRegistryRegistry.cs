using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using Microsoft.Win32;

namespace TestApp.DataAccessLayer
{

	/// <summary>
	/// Perdonate il gioco di parole, questo registry prende i settaggi dal registry di windows.
	/// </summary>
	class WindowsRegistryRegistry : RegistryBase
	{
		public WindowsRegistryRegistry()
		{
			RegistryKey key = Microsoft.Win32.Registry.CurrentUser;
			RegistryKey connservice = key.OpenSubKey("Software\\Maintenance");
			if (connservice == null)
				throw new ApplicationException(String.Format("To use the registry setting we need a key {0} with two values {1} and {2}",
						  "HCKU\\Software\\Maintenance", "Maintenance", "Users"));
			MaintenanceConnectionString = new ConnectionStringSettings("Maintenance", connservice.GetValue("Maintenace").ToString(), "System.Data.SqlClient");
			//UsersConnectionString = new ConnectionStringSettings("User", connservice.GetValue("Users").ToString(), "System.Data.SqlClient");
			
			FilePathDirectory = connservice.GetValue("FilePathDirectory").ToString();
			UploadPathDirectory = connservice.GetValue("UploadPathDirectory").ToString();

			DebugSql = connservice.GetValue("DebugSql").ToString();
		}
	}
}
