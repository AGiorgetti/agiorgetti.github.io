using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace TestApp.DataAccessLayer
{

	/// <summary>
	/// Implementazione del Registry pattern che internamente utilizza 
	/// i settaggi di AppConfig per le impostazioni
	/// </summary>
	public class AppSettingsRegistry : RegistryBase
	{

		public AppSettingsRegistry()
		{
			if (ConfigurationManager.ConnectionStrings["Maintenance"] == null)
				throw new ApplicationException("The application needs to specify the connection string to the main database in the section ConnectionString");
			//if (ConfigurationManager.ConnectionStrings["Users"] == null)
			//   throw new ApplicationException("The application needs to specify the connection string to the Users database in the section ConnectionString");

			MaintenanceConnectionString = ConfigurationManager.ConnectionStrings["Maintenance"];
			//UsersConnectionString = ConfigurationManager.ConnectionStrings["Users"];
			
			FilePathDirectory = ConfigurationManager.AppSettings["FilePathDirectory"];
			UploadPathDirectory = ConfigurationManager.AppSettings["UploadPath"];

			string str = ConfigurationManager.AppSettings["Maintenance_DebugSql"];
			if (string.IsNullOrEmpty(str))
				DebugSql = "false";
			else
				DebugSql = str;
		}
	}
}
