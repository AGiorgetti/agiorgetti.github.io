using SID.NHibernateUtils.MultipleSessions;
using SID.BaseServices.Data;
using SID.Interfaces;
using SID.Interfaces.CommonInterfaces;

namespace TestApp.DataAccessLayer
{
	public class TestAppNhibConfigurator : IUnitOfWorkConfigurator
	{
		static RuntimeConfigData returnvalue;

		public static RuntimeConfigData InnerGetConfiguration()
		{
			if (returnvalue == null)
			{
				returnvalue = new RuntimeConfigData();
				returnvalue.Id = Registry.MaintenanceConnectionString;
				returnvalue.Transactional = false;
				returnvalue.UseSessionCaching = true;
				returnvalue.Properties.Add("dialect", "NHibernate.Dialect.MsSql2005Dialect");
				returnvalue.Properties.Add("connection.driver_class", "NHibernate.Driver.SqlClientDriver");
				returnvalue.Properties.Add("connection.provider", "NHibernate.Connection.DriverConnectionProvider");
				returnvalue.Properties.Add("connection.connection_string", Registry.MaintenanceConnectionString);
				returnvalue.Properties.Add("show_sql", "true");
				returnvalue.Properties.Add("format_sql", "true");
				returnvalue.Assemblies.Add(Registry.EntitiesAssembly);
			}
			return returnvalue;
		}

		public RuntimeConfigData GetConfiguration()
		{
			return InnerGetConfiguration();
		}

	}

	public class TestAppNHibUoWProvider<T> : UnitOfWork_NHib<T>
	{
		protected override RuntimeConfigData Initialize()
		{
			//RuntimeConfigData returnvalue = new RuntimeConfigData();
			//returnvalue.Id = Registry.MaintenanceConnectionString;
			//returnvalue.Transactional = false;
			//returnvalue.Properties.Add("dialect", "NHibernate.Dialect.MsSql2005Dialect");
			//returnvalue.Properties.Add("connection.driver_class", "NHibernate.Driver.SqlClientDriver");
			//returnvalue.Properties.Add("connection.provider", "NHibernate.Connection.DriverConnectionProvider");
			//returnvalue.Properties.Add("connection.connection_string", Registry.MaintenanceConnectionString);
			//returnvalue.Properties.Add("show_sql", "true");
			//returnvalue.Properties.Add("format_sql", "true");
			//returnvalue.Assemblies.Add(Registry.EntitiesAssembly);
			//return returnvalue;
			return TestAppNhibConfigurator.InnerGetConfiguration();
		}
	}

	public class TestAppNHibUoWProvider : UnitOfWork_NHib
	{
		protected override RuntimeConfigData Initialize()
		{
			return TestAppNhibConfigurator.InnerGetConfiguration();
		}
	}
}
