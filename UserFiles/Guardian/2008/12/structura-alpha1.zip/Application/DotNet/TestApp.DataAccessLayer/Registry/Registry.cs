using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Resources;
using System.Text;

namespace TestApp.DataAccessLayer
{

	/// <summary>
	/// Registry Pattern [POEAA]. Classe statica che utilizza internamente una 
	/// implementazione concreta.
	/// 
	/// </summary>
	public static class Registry
	{

		private static readonly IRegistry registry;
		
		static Registry()
		{
			String typeName = ConfigurationManager.AppSettings["RegistryConcreteType"];
			Type regType = Type.GetType(typeName);
			if (regType == null)
				throw new ApplicationException(String.Format("The application needs to have a valid registry type specified in AppSetting with the key {0}.", "RegistryConcreteType"));
			registry = (IRegistry)Activator.CreateInstance(regType);
		}

		public static String MaintenanceConnectionString { get { return registry.MaintenanceConnectionString.ConnectionString; } }
		public static ConnectionStringSettings MaintenanceConnection { get { return registry.MaintenanceConnectionString; } }

		//public static String UsersConnectionString { get { return registry.UsersConnectionString.ConnectionString; } }
		//public static ConnectionStringSettings UsersConnection { get { return registry.UsersConnectionString; } }

		public static String FilePathDirectory { get { return registry.FilePathDirectory; } }
		public static String UploadPathDirectory {
			get {
				if (!Directory.Exists(registry.UploadPathDirectory))
					Directory.CreateDirectory(registry.UploadPathDirectory);
				return registry.UploadPathDirectory;
			}
		}

		public static string DebugSql { get { return registry.DebugSql; } }

		public const string EntitiesAssembly = "TestApp.Entities";
	}
}
