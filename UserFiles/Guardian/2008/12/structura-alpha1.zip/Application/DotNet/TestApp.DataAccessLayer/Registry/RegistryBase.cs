﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestApp.DataAccessLayer
{
	public class RegistryBase : IRegistry
	{
		#region IRegistry Members

		public System.Configuration.ConnectionStringSettings MaintenanceConnectionString
		{ get; protected set; }

		public string FilePathDirectory
		{ get; protected set; }
		
		//public System.Configuration.ConnectionStringSettings UsersConnectionString
		//{ get; protected set; }

		public string UploadPathDirectory
		{ get; protected set; }

		public string DebugSql
		{ get; protected set; }

		#endregion
	}
}
