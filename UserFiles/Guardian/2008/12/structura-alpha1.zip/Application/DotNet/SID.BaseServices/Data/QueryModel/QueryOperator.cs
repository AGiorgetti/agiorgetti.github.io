using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel
{
    public enum QueryOperator
    {
        And,
        Or
    }
}
