using System;
using System.Collections.Generic;
using System.Text;
using SID.BaseServices.Data.QueryModel;
using NHibernate.Engine;

namespace SID.BaseServices.Data.Helpers
{
	public class FlagCheckCriterion : NHibernate.Criterion.AbstractCriterion
	{

		public FlagCheckCriterion(
			String propertyName,
			Object valueToCheck)
			: this(propertyName, valueToCheck, FlagCheckOptions.Standard) { }

		public FlagCheckCriterion(
			String propertyName, Object valueToCheck, FlagCheckOptions options)
		{

			mTypedValues = new TypedValue[0];
			mPropertyName = propertyName;
			mValueToCheck = (Int32)valueToCheck;
			mOptions = options;
		}

		public override NHibernate.Engine.TypedValue[] GetTypedValues(NHibernate.ICriteria criteria, NHibernate.Criterion.ICriteriaQuery criteriaQuery)
		{
			return mTypedValues;
		}


		private void CreateCriteriaPart(StringBuilder sb)
		{
			Int32 matchElement = 0;
			if ((mOptions & FlagCheckOptions.MatchAll) > 0)
				matchElement = mValueToCheck;
			if ((mOptions & FlagCheckOptions.CheckUnset) > 0)
			{
				//This trigger an Unset Search, search all element that have specified bytes not set
				if ((mOptions & FlagCheckOptions.MatchAll) > 0)
				{
					sb.Append(") = 0");
				}
				else
				{
					sb.AppendFormat(") <> {0}", mValueToCheck);
				}
			}
			else
			{
				//This is a normal set search
				if ((mOptions & FlagCheckOptions.MatchAll) > 0)
				{
					sb.AppendFormat(") = {0}", mValueToCheck);
				}
				else
				{
					sb.Append(") > 0");
				}
			}
		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("( {0} & {1}", mPropertyName, mValueToCheck);
			CreateCriteriaPart(sb);
			return sb.ToString();
		}

		private readonly TypedValue[] mTypedValues;
		private readonly String mPropertyName;
		private readonly Int32 mValueToCheck;
		private readonly FlagCheckOptions mOptions;

		public override NHibernate.Criterion.IProjection[] GetProjections()
		{
			throw new NotImplementedException();
		}

		public override NHibernate.SqlCommand.SqlString ToSqlString(NHibernate.ICriteria criteria, NHibernate.Criterion.ICriteriaQuery criteriaQuery, IDictionary<string, NHibernate.IFilter> enabledFilters)
		{
			String[] textArray1 = criteriaQuery.GetColumnsUsingProjection(criteria, mPropertyName);
			StringBuilder sb = new StringBuilder();
			sb.Append("(");
			sb.Append(textArray1[0]);
			sb.Append(" & ");
			sb.Append(mValueToCheck.ToString());
			CreateCriteriaPart(sb);
			return new NHibernate.SqlCommand.SqlString(sb.ToString());
		}
	}
}
