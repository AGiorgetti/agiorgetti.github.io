﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;

namespace SID.BaseServices.Data
{
	public class SqlQuery
	{
		internal DbCommand Command { get; set; }
		internal DbProviderFactory Factory { get; set; }

		internal StringBuilder query = new StringBuilder();

		internal SqlQuery(string query, CommandType cmdType)
		{
			Factory = DataAccess.GetFactory();
			Command = Factory.CreateCommand();
			Command.CommandType = cmdType;
			this.query.Append(query);
		}

		public T ExecuteScalar<T>()
		{
			T result = default(T);
			DataAccess.Execute(this, () => result = (T)Command.ExecuteScalar());
			return result;
		}
      
		/// <summary>
		/// Esegue la query, ma se la query non torna nulla allora torna il default
		/// per l'oggetto in qusetione.
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <returns></returns>
		public T ExecuteScalarWithDefault<T>()
		{
			T result = default(T);
			DataAccess.Execute(this, () =>
			                         	{
			                         		Object obj = Command.ExecuteScalar();
													result = (T) (obj ?? default(T));
			                         	});
			return result;
		}

		public Int32 ExecuteNonQuery()
		{
			Int32 result = 0;
			DataAccess.Execute(this, () => result = Command.ExecuteNonQuery());
			return result;
		}

		public void FillDataTable(DataTable dt)
		{
			DataAccess.Execute(this, () =>
			{
				using (DbDataAdapter da = Factory.CreateDataAdapter())
				{
					da.SelectCommand = Command;
					da.Fill(dt);
				}
			});
		}

		public SqlQuery SetStringParam(string commandName, string value)
		{
			SetParam(commandName, value, DbType.String);
			return this;
		}

		public SqlQuery SetInt32Param(string commandName, Int32 value)
		{
			SetParam(commandName, value, DbType.Int32);
			return this;
		}

		public SqlQuery SetDateTimeParam(string commandName, DateTime value)
		{
			SetParam(commandName, value, DbType.DateTime);
			return this;
		}

		public void SetParam(string commandName, Object value, DbType type)
		{
			String paramName = DataAccess.GetParameterName(Command, commandName);
			if (Command.CommandType == CommandType.Text)
				query.Replace("{" + commandName + "}", paramName);
			DbParameter param = Factory.CreateParameter();
			param.DbType = type;
			param.ParameterName = paramName;
			param.Value = value;
			Command.Parameters.Add(param);
		}
	}
}
