using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel {

	public enum OrderClauseCriteria {
		Ascending, Descending
	}

	public class OrderClause {

		private string propertyName;
		private OrderClauseCriteria criteria;

		public static OrderClause CreateOrderClause(String propertyName, OrderClauseCriteria criteria) {
			return new OrderClause(propertyName, criteria);
		}

		public static OrderClause CreateOrderClause(String propertyName) {
			return new OrderClause(propertyName, OrderClauseCriteria.Ascending);
		}

		public OrderClause(String propertyName, OrderClauseCriteria criteria) {
			this.propertyName = propertyName;
			this.criteria = criteria;
		}

		public OrderClause(String propertyName) : this(propertyName, OrderClauseCriteria.Ascending) { }

		public string PropertyName {
			get {
				return propertyName;
			}
		}

		public OrderClauseCriteria Criteria {
			get {
				return criteria;
			}
		}
	}
}
