﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SID.Interfaces.CommonInterfaces;
using SID.BaseServices;
using SID.NHibernateUtils.MultipleSessions;

namespace SID.BaseServices.Data
{
	public class UnitOfWorkDao<P> where P : IUnitOfWork, new()
	{

		#region TestMockingInsertion

		/// <summary>
		/// 
		/// </summary>
		/// <param name="provider"></param>
		/// <returns></returns>
		public static DisposableAction Override(IUnitOfWork provider)
		{
			IUnitOfWork realProvider = iProvider;
			iProvider = provider;
			return new DisposableAction(delegate() { iProvider = realProvider; });
		}

		#endregion

		protected static IUnitOfWork iProvider;

		/// <summary>
		/// Costruttore statico che inizializza la unitofwork da usare 
		/// </summary>
		static UnitOfWorkDao()
		{
			iProvider = new P();
		}

		#region IUnitOfWork Members

		public static void Flush()
		{
			iProvider.Flush();
		}
		public static IList<T> GetAll<T>()
		{
			return iProvider.GetAll<T>();
		}

		public static IList<T> GetAll<T>(int pageIndex, int pageSize)
		{
			return iProvider.GetAll<T>(pageIndex, pageSize);
		}

		public static IList<T> GetByCriteria<T>(SID.BaseServices.Data.QueryModel.Query query)
		{
			return iProvider.GetByCriteria<T>(query);
		}

		public static IList<T> GetByCriteria<T>(SID.BaseServices.Data.QueryModel.Query query, int pageIndex, int pageSize)
		{
			return iProvider.GetByCriteria<T>(query, pageIndex, pageSize);
		}

		public static System.Collections.IList GetProjection<T>(SID.BaseServices.Data.QueryModel.Query query)
		{
			return iProvider.GetProjection<T>(query);
		}
		public static System.Collections.IList GetProjection(String objectQuery, params Object[] parameters)
		{
			return iProvider.GetProjection(objectQuery, parameters);
		}

		public static T GetReferenceByKey<T>(object key)
		{
			return iProvider.GetReferenceByKey<T>(key);
		}

		public static T GetByKey<T>(object key)
		{
			return iProvider.GetByKey<T>(key);
		}

		public static T GetByProperty<T>(string propertyName, object value)
		{
			return iProvider.GetByProperty<T>(propertyName, value);
		}

		public static void Delete<T>(T item)
		{
			iProvider.Delete<T>(item);
		}

		public static void Delete<T>(IList<T> items)
		{
			iProvider.Delete<T>(items);
		}

		public static void Update<T>(T item)
		{
			iProvider.Update<T>(item);
		}

		public static void Save<T>(T item)
		{
			iProvider.Save<T>(item);
		}

		public static void SaveOrUpdate<T>(T item)
		{
			iProvider.SaveOrUpdate<T>(item);
		}

		public static void SaveOrUpdate<T>(IList<T> items)
		{
			iProvider.SaveOrUpdate<T>(items);
		}

		public static void Detach<T>(T item)
		{
			iProvider.Detach<T>(item);
		}

		public static void ReAttach<T>(T item)
		{
			iProvider.ReAttach<T>(item);
		}

		#endregion

	}

	public class UnitOfWorkDao<T, P> where P : IUnitOfWork<T>, new()
	{

		#region TestMockingInsertion

		/// <summary>
		/// 
		/// </summary>
		/// <param name="provider"></param>
		/// <returns></returns>
		public static DisposableAction Override(IUnitOfWork<T> provider)
		{
			IUnitOfWork<T> realProvider = iProvider;
			iProvider = provider;
			return new DisposableAction(delegate() { iProvider = realProvider; });
		}

		#endregion

		protected static IUnitOfWork<T> iProvider;

		/// <summary>
		/// Costruttore statico che inizializza la unitofwork da usare 
		/// </summary>
		static UnitOfWorkDao()
		{
			iProvider = new P();
		}

		#region IUnitOfWork Members

		public static void Flush()
		{
			iProvider.Flush();
		}
		public static IList<T> GetAll()
		{
			return iProvider.GetAll();
		}

		public static IList<T> GetAll(int pageIndex, int pageSize)
		{
			return iProvider.GetAll(pageIndex, pageSize);
		}

		public static IList<T> GetByCriteria(SID.BaseServices.Data.QueryModel.Query query)
		{
			return iProvider.GetByCriteria(query);
		}

		public static IList<T> GetByCriteria(SID.BaseServices.Data.QueryModel.Query query, int pageIndex, int pageSize)
		{
			return iProvider.GetByCriteria(query, pageIndex, pageSize);
		}

		public static System.Collections.IList GetProjection(SID.BaseServices.Data.QueryModel.Query query)
		{
			return iProvider.GetProjection(query);
		}
		public static System.Collections.IList GetProjection(String objectQuery, params Object[] parameters)
		{
			return iProvider.GetProjection(objectQuery, parameters);
		}

		public static T GetReferenceByKey(object key)
		{
			return iProvider.GetReferenceByKey(key);
		}

		public static T GetByKey(object key)
		{
			return iProvider.GetByKey(key);
		}

		public static T GetByProperty(string propertyName, object value)
		{
			return iProvider.GetByProperty(propertyName, value);
		}

		public static void Delete(T item)
		{
			iProvider.Delete(item);
		}

		public static void Delete(IList<T> items)
		{
			iProvider.Delete(items);
		}

		public static void Update(T item)
		{
			iProvider.Update(item);
		}

		public static void Save(T item)
		{
			iProvider.Save(item);
		}

		public static void SaveOrUpdate(T item)
		{
			iProvider.SaveOrUpdate(item);
		}

		public static void SaveOrUpdate(IList<T> items)
		{
			iProvider.SaveOrUpdate(items);
		}

		public static void Detach(T item)
		{
			iProvider.Detach(item);
		}

		public static void ReAttach(T item)
		{
			iProvider.ReAttach(item);
		}

		#endregion

	}
}
