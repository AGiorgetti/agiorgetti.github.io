using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel {

	[Flags()]
	public enum FlagCheckOptions {
		Standard = 0,
		CheckUnset = 1,
		MatchAll = 2,
	}
}
