using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel
{
	public sealed partial class Query
	{

		#region Factories

		public static Query CreateProjectionCount()
		{
			Query q = new Query();
			return q.Count();
		}

		public static Query CreateProjection(String property)
		{
			Query q = new Query();
			return q.ProjectProperty(property);
		}

		public static Query CreateEq(String propertyName, object value)
		{
			return Query.CreateQuery(propertyName, value, CriteriaOperator.Equal);
		}

		public static Query CreateNotEq(String propertyName, object value)
		{
			return Query.CreateQuery(propertyName, value, CriteriaOperator.NotEqual);
		}

		public static Query CreateLt(String propertyName, object value)
		{
			return Query.CreateQuery(propertyName, value, CriteriaOperator.LesserThan);
		}

		public static Query CreateLte(String propertyName, object value)
		{
			return Query.CreateQuery(propertyName, value, CriteriaOperator.LesserThanOrEqual);
		}

		public static Query CreateGt(String propertyName, object value)
		{
			return Query.CreateQuery(propertyName, value, CriteriaOperator.GreaterThan);
		}

		public static Query CreateGte(String propertyName, object value)
		{
			return Query.CreateQuery(propertyName, value, CriteriaOperator.GreaterThanOrEqual);
		}

		public static Query CreateLike(String propertyName, object value)
		{
			return Query.CreateQuery(propertyName, value, CriteriaOperator.Like);
		}

		#endregion

		public Query Eq(String propertyName, object value)
		{
			criteria.Add(Criterion.Eq(propertyName, value));
			return this;
		}

		public Query Lt(String propertyName, object value)
		{
			criteria.Add(Criterion.Lt(propertyName, value));
			return this;
		}

		public Query Lte(String propertyName, object value)
		{
			criteria.Add(Criterion.Lte(propertyName, value));
			return this;
		}

		public Query Gt(String propertyName, object value)
		{
			criteria.Add(Criterion.Gt(propertyName, value));
			return this;
		}

		public Query Gte(String propertyName, object value)
		{
			criteria.Add(Criterion.Gte(propertyName, value));
			return this;
		}

		public Query Like(String propertyName, object value)
		{
			criteria.Add(Criterion.Like(propertyName, value));
			return this;
		}

		public Query Count()
		{
			projections.Add(Projection.RowCount());
			return this;
		}

		public Query ProjectProperty(String propertyName)
		{
			projections.Add(Projection.CreateProjection(ProjectionTypes.Property, propertyName));
			return this;
		}

		public Query NotNull(String propertyName)
		{
			criteria.Add(Criterion.NotNull(propertyName));
			return this;
		}

		public Query Null(String propertyName)
		{
			criteria.Add(Criterion.Null(propertyName));
			return this;
		}

		public Query SetOrComposition()
		{
			Operator = QueryOperator.Or;
			return this;
		}

		public Query OrderBy(String propertyName)
		{
			orderClauses.Add(new OrderClause(propertyName));
			return this;
		}

		public Query ProjProp(String propertyName) {
			projections.Add(Projection.Property(propertyName));
			return this;
		}

		public Boolean DistinctProjection = false;
		public Query Distinct
		{
			get { DistinctProjection = true; return this; }
		}

	}
}
