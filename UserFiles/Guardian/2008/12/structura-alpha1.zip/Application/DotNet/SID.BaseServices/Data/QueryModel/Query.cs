using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel {
	public sealed partial class Query {

		#region Constructors

		public static Query CreateQuery(
			String				propertyName,
			object				value,
			CriteriaOperator	@operator) {
		
			Query q = new Query();
			q.Criteria.Add(Criterion.CreateCriterion(propertyName, value, @operator));
			return q;
		}

		public static Query CreateQuery(
			String					criteriaPropertyName,
			object					value,
			CriteriaOperator		@operator,
			String					orderPropertyName,
			OrderClauseCriteria	orderCriteria) {
		
			Query q = new Query();
			q.Criteria.Add(Criterion.CreateCriterion(criteriaPropertyName, value, @operator));
			q.OrderClauses.Add(OrderClause.CreateOrderClause(orderPropertyName, orderCriteria)); 
			return q;
		}

		public static Query CreateQuery(Criterion criterion) {
			Query q = new Query();
			q.Criteria.Add(criterion);
			return q;
		}
		#endregion

		#region Helpers

		public Criterion AddCriteria(
			String				propertyName,
			object				value,
			CriteriaOperator	@operator) {
		
			Criterion c = Criterion.CreateCriterion(propertyName, value, @operator);
			Criteria.Add(c);
			return c;
		}

		public Criterion AddCriteriaEq(
			String propertyName,
			object value) {
			Criterion C = Criterion.Eq(propertyName, value);
			Criteria.Add(C);
			return C;
		}

		public Projection AddProjection(
			ProjectionTypes	type,
			String				propertyName) {
			
			Projection p = Projection.CreateProjection(type, propertyName);
			Projections.Add(p);
			return p;
		}

		#endregion

		private List<Criterion>							criteria = new List<Criterion>();
		private QueryOperator							@operator;
		private IList<OrderClause>						orderClauses = new List<OrderClause>();
		private List<Projection>						projections = new List<Projection>();
		private Dictionary<String, FetchModes>		fetchModes = new Dictionary<string, FetchModes>();

		public IList<Projection> Projections {
			get {return projections;}
		}

		public IList<Criterion> Criteria {
			get {return criteria;}
		}

		public QueryOperator Operator {
			get {return @operator;}
			set {@operator = value;}
		}

		public void AddFetchModes(
			String propertypath,
			FetchModes fetchMode) {
			fetchModes.Add(propertypath, fetchMode);
		}

		public IDictionary<String, FetchModes> FetchModes() {
			return fetchModes;
		}

		//public IList<Query> SubQueries {
		//   get {
		//      return subQueries;
		//   }
		//}

		public IList<OrderClause> OrderClauses {
			get {return orderClauses;}
		}


	}
}