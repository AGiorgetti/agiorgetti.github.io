using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel {
	
	/// <summary>
	/// Questa classe permette di fare delle projection sui risultati, una projection � 
	/// solitamente associata ad una query aggregata in sql.
	/// </summary>
	public class Projection {

		#region Properties

		/// <summary>
		/// Una projection solitamente viene fatta su una particolare propriet� dell'oggetto come
		/// ad esempio una AVG() o una SUM().
		/// </summary>
		public String PropertyName {
			get { return mPropertyName; }
			set { mPropertyName = value; }
		}
		private String mPropertyName;

		/// <summary>
		/// Il tipo indica la proiezione che si vuole fare
		/// </summary>
		public ProjectionTypes Type {
			get { return mType; }
			set { mType = value; }
		}
		private ProjectionTypes mType;

		#endregion

		#region Factory methods

		public static Projection CreateProjection(
			ProjectionTypes type,
			String			 propertyName) {
			
			Projection p = new Projection();
			p.Type = type;
			p.PropertyName = propertyName;
			return p;
		}

		public static Projection RowCount() {
			return CreateProjection(ProjectionTypes.RowCount, null); 
		}

		public static Projection Property(String propertyName) {
			return CreateProjection(ProjectionTypes.Property, propertyName);
		}

		public static Projection Distinct()
		{
			return CreateProjection(ProjectionTypes.Distinct, null);
		}

		#endregion
	}
}
