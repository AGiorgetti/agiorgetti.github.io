using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel {
	
	public class Criterion {

		private string mPropertyName;
		private object mValue;
		private object mParameters; //Some criterion needs parameters to work correctly.

		private CriteriaOperator @operator;

		#region Factory Methods

		public static Criterion CreateCriterion(
			String propertyName,
			object value,
			CriteriaOperator @operator) {

			Criterion c = new Criterion();
			c.Operator = @operator;
			c.mPropertyName = propertyName;
			c.mValue = value;
			return c;
		}

		public static Criterion Sql(
			String sqlClause) {

			Criterion c = new Criterion();
			c.Operator = CriteriaOperator.Sql;
			c.mPropertyName = sqlClause;
			return c;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="propertyName"></param>
		/// <param name="valueToCheck"></param>
		/// <returns></returns>
		public static Criterion Eq(
			String propertyName,
			object valueToCheck) {

			Criterion C = new Criterion();
			C.Operator = CriteriaOperator.Equal;
			C.PropertyName = propertyName;
			C.Value = valueToCheck;
			return C;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="propertyName"></param>
		/// <param name="valueToCheck"></param>
		/// <returns></returns>
		public static Criterion Like(
			String propertyName,
			object valueToCheck)
		{

			Criterion C = new Criterion();
			C.Operator = CriteriaOperator.Like;
			C.PropertyName = propertyName;
			C.Value = valueToCheck;
			return C;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="propertyName"></param>
		/// <param name="valueToCheck"></param>
		/// <returns></returns>
		public static Criterion Lt(
			String propertyName,
			object valueToCheck) {

			Criterion C = new Criterion();
			C.Operator = CriteriaOperator.LesserThan;
			C.PropertyName = propertyName;
			C.Value = valueToCheck;
			return C;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="propertyName"></param>
		/// <param name="valueToCheck"></param>
		/// <returns></returns>
		public static Criterion Lte(
			String propertyName,
			object valueToCheck) {

			Criterion C = new Criterion();
			C.Operator = CriteriaOperator.LesserThanOrEqual;
			C.PropertyName = propertyName;
			C.Value = valueToCheck;
			return C;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="propertyName"></param>
		/// <param name="valueToCheck"></param>
		/// <returns></returns>
		public static Criterion Gt(
			String propertyName,
			object valueToCheck) {

			Criterion C = new Criterion();
			C.Operator = CriteriaOperator.GreaterThan;
			C.PropertyName = propertyName;
			C.Value = valueToCheck;
			return C;
		}

		public static Criterion NotNull(String propertyName) {
			Criterion C = new Criterion();
			C.Operator = CriteriaOperator.IsNotNull ;
			C.PropertyName = propertyName;
			return C;
		}

		public static Criterion Null(String propertyName)
		{
			Criterion C = new Criterion();
			C.Operator = CriteriaOperator.IsNull;
			C.PropertyName = propertyName;
			return C;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="propertyName"></param>
		/// <param name="valueToCheck"></param>
		/// <returns></returns>
		public static Criterion Gte(
			String propertyName,
			object valueToCheck) {

			Criterion C = new Criterion();
			C.Operator = CriteriaOperator.GreaterThanOrEqual;
			C.PropertyName = propertyName;
			C.Value = valueToCheck;
			return C;
		}

		/// <summary
		/// </summary>
		/// <param name="customCriteria"></param>
		/// <returns></returns>
		public static Criterion Custom(
			String propertyName,
			object customCriteria) {

			Criterion C = new Criterion();
			C.PropertyName = propertyName;
			C.Operator = CriteriaOperator.CustomCriteria;
			C.Value = customCriteria;
			return C;
		}

		public static Criterion FlagsCheck(
			String propertyName,
			Int32 valueToCheck) {

			return FlagsCheck(propertyName, valueToCheck, FlagCheckOptions.Standard);
		}

		public static Criterion FlagsCheck(
			String propertyName,
			Int32 valueToCheck,
			FlagCheckOptions options) {

			Criterion c = new Criterion();
			c.Operator = CriteriaOperator.FlagsCheck;
			c.mPropertyName = propertyName;
			c.Parameters = options;
			c.mValue = valueToCheck;
			return c;
		}


		#endregion

		#region Properties

		public string PropertyName {
			get { return mPropertyName; }
			set { mPropertyName = value; }
		}

		public object Value {
			get { return mValue; }
			set { this.mValue = value; }
		}

		public object Parameters {
			get { return mParameters; }
			set { this.mParameters = value; }
		}

		public CriteriaOperator Operator {
			get { return @operator; }
			set { @operator = value; }
		}

		#endregion


	}
}
