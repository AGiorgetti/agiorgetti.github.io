﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace SID.BaseServices
{
	public static class Clr
	{
		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public static Boolean IsInException()
		{
			return Marshal.GetExceptionPointers() != IntPtr.Zero ||
					 Marshal.GetExceptionCode() != 0;
		}
	}
}
