using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using NHibernate;
using NHibernate.SqlTypes;
using NHibernate.UserTypes;

namespace SID.BaseServices.Data.Helpers
{
	class StringListUserType : IUserType
	{
		private const char cStringSeparator = '#';

		#region Equals member

		bool IUserType.Equals(object x, object y)
		{
			if (x == null) return false;
			return x.Equals(y);
		}

		#endregion

		#region IUserType Members

		public object Assemble(object cached, object owner)
		{
			return cached;
		}

		public object DeepCopy(object value)
		{
			return value;
		}

		public object Disassemble(object value)
		{
			return value;
		}

		public int GetHashCode(object x)
		{
			return x.GetHashCode();
		}

		public bool IsMutable
		{
			get { return false; }
		}

		public object NullSafeGet(System.Data.IDataReader rs, string[] names, object owner)
		{
			List<String> result = new List<String>();
			Int32 index = rs.GetOrdinal(names[0]);
			if (rs.IsDBNull(index) || String.IsNullOrEmpty((String) rs[index]))
				return result;
			foreach (String s in ((String)rs[index]).Split(cStringSeparator))
				result.Add(s);
			return result;
		}

		public void NullSafeSet(System.Data.IDbCommand cmd, object value, int index)
		{
			if (value == null || value == DBNull.Value)
			{
				NHibernateUtil.String.NullSafeSet(cmd, null, index);
			}
			IEnumerable<String> stringList = (IEnumerable<String>) value;
			StringBuilder sb = new StringBuilder();
			foreach(String s in stringList) {
				sb.Append(s);
				sb.Append(cStringSeparator);
			}
			if (sb.Length > 0) sb.Length--;
			NHibernateUtil.String.Set(cmd, sb.ToString(), index);
		}

		public object Replace(object original, object target, object owner)
		{
			return original;
		}

		public Type ReturnedType
		{
			get { return typeof(IList<String>); }
		}

		public NHibernate.SqlTypes.SqlType[] SqlTypes
		{
			get { return new SqlType[] { NHibernateUtil.String.SqlType }; }
		}

		#endregion
	}
}