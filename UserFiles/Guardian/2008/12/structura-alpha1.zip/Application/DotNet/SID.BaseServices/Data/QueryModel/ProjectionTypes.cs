using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel {
	
	public enum ProjectionTypes {
		Unknown			= 0,
		RowCount			= 1,
		PropertyCount	= 2,
		Property			= 3,
		Distinct			= 4,
	}
}
