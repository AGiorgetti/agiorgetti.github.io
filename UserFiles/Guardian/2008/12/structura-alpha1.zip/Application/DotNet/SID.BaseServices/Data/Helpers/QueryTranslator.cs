using System;
using System.Collections.Generic;
using System.Text;
using SID.BaseServices.Data.QueryModel;
using NHibernate;
using NHibernate.Criterion;
using System.Linq;

namespace SID.BaseServices.Data.Helpers
{
	internal class QueryTranslator
	{
		private readonly ICriteria _criteria;
		private readonly ISession _session;
		private readonly Query _query;
		private Type _rootType;

		public QueryTranslator(ISession session, ICriteria criteria, Query query, Type rootType)
		{
			_session = session;
			_criteria = criteria;
			_rootType = rootType;
			_criteria.SetResultTransformer(new NHibernate.Transform.DistinctRootEntityResultTransformer());
			_query = query;
		}



		public void Execute()
		{
			Query myQuery = this._query;

			TranslateOrderClause(myQuery);
			TranslateQuery(myQuery);
			TranslateProjections(myQuery);
			TranslateFetchModes(myQuery);
		}

		/// <summary>
		/// Questo metodo trasla le proiezioni
		/// </summary>
		/// <param name="myQuery"></param>
		private void TranslateProjections(Query myQuery)
		{
			if (myQuery.Projections.Count > 0)
			{
				ProjectionList projs = Projections.ProjectionList();
				foreach (Projection myProjection in myQuery.Projections)
				{
					IProjection projection = CreateProjection(myProjection);
					projs.Add(projection);
				}
				if (myQuery.DistinctProjection)
					_criteria.SetProjection(Projections.Distinct(projs));
				else
					_criteria.SetProjection(projs);
			}
		}

		private void TranslateQuery(Query myQuery)
		{
			//Ora bisogna gestire correttamente il tipo di unione delle query, per questo primo tipo
			//di modello si utilizza solamente una possibilit� di tutti or o tutti and (default)
			//la prima soluzione � creare un dizionario di criteri che permetta ad ogni oggetto
			//Criteria di utilizzare nel caso di or la conjunction.
			System.Collections.IDictionary c = new System.Collections.SortedList();
			foreach (var e in _session.SessionFactory.GetAllClassMetadata())
				c.Add(e.Key, e.Value);
			CriteriaAliasTranslator cat = new CriteriaAliasTranslator(c, _rootType);
			Dictionary<ICriteria, Disjunction> criterialist = new Dictionary<ICriteria, Disjunction>();
			foreach (Criterion myCriterion in myQuery.Criteria)
			{

				String currentPropertyName = cat.Translate(myCriterion.PropertyName);
				//CreateAndHandleAlias(myCriterion, ref currentCriteria, ref currentPropertyName);

				ICriterion criterion = null;
				criterion = CreateCriterion(myCriterion, currentPropertyName, criterion);
				if (_query.Operator == QueryOperator.And)
					_criteria.Add(criterion);
				else if (_query.Operator == QueryOperator.Or)
					ComposeWithConjunction(_criteria, criterialist, criterion);
			}
			cat.CreateAlias(_criteria);
		}

		private void TranslateOrderClause(Query myQuery)
		{
			foreach (OrderClause clause in myQuery.OrderClauses)
			{
				_criteria.AddOrder(new NHibernate.Criterion.Order(clause.PropertyName, clause.Criteria == OrderClauseCriteria.Ascending ? true : false));
			}
		}

		private void TranslateFetchModes(Query myQuery)
		{
			foreach (KeyValuePair<String, FetchModes> kvp in myQuery.FetchModes())
			{
				NHibernate.FetchMode mode = TranslateToNhibernateFetchMode(kvp.Value);
				_criteria.SetFetchMode(kvp.Key, mode);
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="mode"></param>
		private NHibernate.FetchMode TranslateToNhibernateFetchMode(FetchModes mode)
		{
			switch (mode)
			{
				case FetchModes.Default:
					return NHibernate.FetchMode.Default;
				case FetchModes.Eager:
					return NHibernate.FetchMode.Eager;
				case FetchModes.Join:
					return NHibernate.FetchMode.Join;
				case FetchModes.Lazy:
					return NHibernate.FetchMode.Lazy;
				case FetchModes.Select:
					return NHibernate.FetchMode.Select;
			}
			throw new ArgumentException(String.Format("Nhibernate does not support {0} fetch mode", mode.ToString()));
		}

		private void ComposeWithConjunction(
			ICriteria criteria,
			IDictionary<ICriteria, Disjunction> criterionmap,
			ICriterion criterion)
		{

			//First of all check if this criteria was already examined
			if (!criterionmap.ContainsKey(criteria))
			{
				criterionmap.Add(criteria, Expression.Disjunction());
				criteria.Add(criterionmap[criteria]);
			}
			criterionmap[criteria].Add(criterion);
		}

		private static ICriterion CreateCriterion(Criterion myCriterion, String currentPropertyName, ICriterion criterion)
		{
			if (myCriterion.Operator == CriteriaOperator.Equal)
				criterion = Expression.Eq(currentPropertyName, myCriterion.Value);
			else if (myCriterion.Operator == CriteriaOperator.GreaterThan)
				criterion = Expression.Gt(currentPropertyName, myCriterion.Value);
			else if (myCriterion.Operator == CriteriaOperator.GreaterThanOrEqual)
				criterion = Expression.Ge(currentPropertyName, myCriterion.Value);
			else if (myCriterion.Operator == CriteriaOperator.LesserThan)
				criterion = Expression.Lt(currentPropertyName, myCriterion.Value);
			else if (myCriterion.Operator == CriteriaOperator.LesserThanOrEqual)
				criterion = Expression.Le(currentPropertyName, myCriterion.Value);
			else if (myCriterion.Operator == CriteriaOperator.Like)
				criterion = Expression.Like(currentPropertyName, myCriterion.Value);
			else if (myCriterion.Operator == CriteriaOperator.NotEqual)
				criterion = Expression.Not(Expression.Like(currentPropertyName, myCriterion.Value));
			else if (myCriterion.Operator == CriteriaOperator.Sql)
				criterion = Expression.Sql(currentPropertyName);
			else if (myCriterion.Operator == CriteriaOperator.IsNotNull)
				criterion = Expression.IsNotNull(currentPropertyName);
			else if (myCriterion.Operator == CriteriaOperator.IsNull)
				criterion = Expression.IsNull(currentPropertyName);
			else if (myCriterion.Operator == CriteriaOperator.In)
				criterion = Expression.In(currentPropertyName, (System.Collections.ICollection)myCriterion.Value);
			else if (myCriterion.Operator == CriteriaOperator.FlagsCheck)
				criterion = new FlagCheckCriterion(
					currentPropertyName,
					(Int32)myCriterion.Value, (FlagCheckOptions)myCriterion.Parameters);
			else if (myCriterion.Operator == CriteriaOperator.CustomCriteria)
				//A custom criteria is a fully configured object.
				criterion = (ICriterion)myCriterion.Value;
			else
				throw new ArgumentException("operator", "CriteriaOperator not supported in NHibernate Provider");
			return criterion;

		}

		private static IProjection CreateProjection(Projection myProjection)
		{
			switch (myProjection.Type)
			{
				case ProjectionTypes.RowCount:
					return Projections.RowCount();
				case ProjectionTypes.Property:
					return Projections.Property(myProjection.PropertyName);
				default:
					throw new ArgumentException("Unknown projection type = " + myProjection.Type.ToString());
			}
		}

		//todo change this to use criteria alias translatore
		private Dictionary<string, string> aliases = new Dictionary<string, string>();
		private Dictionary<string, ICriteria> aliasesc = new Dictionary<string, ICriteria>();

		//private void CreateAndHandleAlias(
		//   Criterion myCriterion, 
		//   ref ICriteria currentCriteria, 
		//   ref String currentPropertyName) {
		//   if (myCriterion.PropertyName.Contains(".")) {
		//      String[] Alias = myCriterion.PropertyName.Split('.');
		//      if (Alias.Length == 2) {
		//         if (aliases.ContainsKey(Alias[0])) {
		//            //do nothing because alias is already done.
		//         }
		//         else { 
		//            _criteria.CreateAlias(Alias[0], Alias[0]);
		//            aliases.Add(Alias[0], Alias[0]);
		//         }

		//      }
		//      else {
		//         for (Int32 I = 0; I < Alias.Length - 1; ++I) {
		//            if (aliasesc.ContainsKey(Alias[I])) {
		//               currentCriteria = aliasesc[Alias[I]];
		//            }
		//            else { 
		//               currentCriteria = currentCriteria.CreateCriteria(Alias[I]);
		//               currentCriteria.SetResultTransformer(NHibernate.CriteriaUtil.DistinctRootEntity);
		//               aliasesc.Add(Alias[I], currentCriteria);
		//            }
		//         }
		//         currentPropertyName = Alias[Alias.Length - 1];
		//      }
		//   }
		//}
	}
}
