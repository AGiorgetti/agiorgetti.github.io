using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using NHibernate;
using NHibernate.SqlTypes;
using NHibernate.UserTypes;

namespace SID.BaseServices.Data.Helpers
{
	public class UriUserType : IUserType
	{
		#region Equals member

		bool IUserType.Equals(object x, object y)
		{
			if (x == null) return false;
			return x.Equals(y);
		}

		#endregion

		#region IUserType Members

		public object Assemble(object cached, object owner)
		{
			return cached;
		}

		public object DeepCopy(object value)
		{
			if (value == null) return null;
			return new Uri(((Uri)value).AbsoluteUri);
		}

		public object Disassemble(object value)
		{
			return value;
		}

		public int GetHashCode(object x)
		{
			return x.GetHashCode();
		}

		public bool IsMutable
		{
			get { return false; }
		}

		public object NullSafeGet(System.Data.IDataReader rs, string[] names, object owner)
		{
			Int32 index = rs.GetOrdinal(names[0]);
			if (rs.IsDBNull(index))
			{
				return null;
			}
			try
			{
				return new Uri(rs[index].ToString());
			}
			catch (FormatException)
			{
				//The uri is malformed, maybe it is worth to doing something else.
				return null;
			}
		}

		public void NullSafeSet(System.Data.IDbCommand cmd, object value, int index)
		{
			if (value == null || value == DBNull.Value)
			{
				NHibernateUtil.String.NullSafeSet(cmd, null, index);
			}
			Uri uri = (Uri)value;
			NHibernateUtil.String.Set(cmd, uri.AbsoluteUri, index);
		}

		public object Replace(object original, object target, object owner)
		{
			return original;
		}

		public Type ReturnedType
		{
			get { return typeof(Uri); }
		}

		public NHibernate.SqlTypes.SqlType[] SqlTypes
		{
			get { return new SqlType[] { NHibernateUtil.String.SqlType }; }
		}

		#endregion
	}
}