using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices {

	public delegate void VoidFunc();

	public delegate void Proc();

	public delegate void Proc<T1>(T1 P1);

	public delegate void Proc<T1, T2>(T1 P1, T2 P2);

	public delegate void Proc<T1, T2, T3>(T1 P1, T2 P2, T3 P3);


	public struct DisposableAction : IDisposable {

		private VoidFunc mGuardFunction;

		public DisposableAction(VoidFunc guardFunction) {
			this.mGuardFunction = guardFunction;
		}

		/// <summary>
		/// This function remove the guard callback, is to be used with great attenction
		/// by the caller, but is a way to avoid disposable action to be called at the 
		/// end of the scope. Remember that inside a using block there is no good way
		/// to avoid Dispose to be called.
		/// </summary>
		public void Dismiss() {
			mGuardFunction = null;
		}

		#region IDisposable Members

		void IDisposable.Dispose() {
			if (mGuardFunction != null)
				mGuardFunction();
		}

		#endregion


	}

}
