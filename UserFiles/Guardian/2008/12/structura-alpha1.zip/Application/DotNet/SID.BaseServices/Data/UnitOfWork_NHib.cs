using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using SID.BaseServices.Data.QueryModel;
using NHibernate;
using NHibernate.Criterion;
using SID.NHibernateUtils.MultipleSessions;
using SID.BaseServices.Data.Helpers;
using SID.Interfaces.CommonInterfaces;

namespace SID.BaseServices.Data
{
	/// <summary>
	/// Classe che implementa la base di un repository generico 
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public abstract class UnitOfWork_NHib : IUnitOfWork
	{
		/// <summary>
		/// nhibernate members
		/// </summary>
		protected RuntimeConfigData nhibconf;

		protected abstract RuntimeConfigData Initialize();

		public RuntimeConfigData Nhibconf
		{
			get { return nhibconf ?? (nhibconf = Initialize()); }
		}

		protected ISession Session
		{
			get { return NHibernateSessionManager.Instance.GetSessionFrom(Nhibconf); }
		}

		//public void Dispose()
		//{
		//   Dispose(true);
		//   GC.SuppressFinalize(this);
		//}

		//protected virtual void Dispose(bool disposing)
		//{
		//   if (mDisposed) return;
		//   mDisposed = true;
		//   if (disposing)
		//   {
		//      if (HttpContext.Current == null)
		//      {
		//         //sono in campo windows forms devo esplicitamente committare e chiudere le sessioni aperte
		//         //prima di distruggere l'oggetto naturalmente solo se qualcuno ha mai acceduto alla propriet�
		//         if (nhibconf != null)
		//         {
		//            NHibernateSessionManager.Instance.FlushSessionOn(nhibconf.Id);
		//            NHibernateSessionManager.Instance.CommitTransactionOn(nhibconf.Id);
		//            NHibernateSessionManager.Instance.CloseSessionOn(nhibconf.Id);
		//         }
		//      }
		//   }
		//}
		//private Boolean mDisposed = false;

		#region IUnitOfWork Members

		public void Flush()
		{
			Session.Flush();
		}
		public T GetByKey<T>(object key)
		{
			return Session.Get<T>(key);
		}

		public T GetReferenceByKey<T>(object key)
		{
			return Session.Load<T>(key);
		}

		/// <summary>
		/// this versione return an instance of an object, nothing if no object is found
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="propertyName"></param>
		/// <param name="value"></param>
		/// <returns></returns>
		public T GetByProperty<T>(string propertyName, object value)
		{
			return Session
				.CreateCriteria(typeof(T))
				.Add(Expression.Eq(propertyName, value))
				.UniqueResult<T>();
		}

		public void Delete<T>(T item)
		{
			Session.Delete(item);
		}

		public void Delete<T>(IList<T> items)
		{
			for (Int32 I = 0; I < items.Count; ++I)
			{
				Delete(items[I]);
			}
		}

		public void Update<T>(T item)
		{
			Session.Update(item);
		}

		public void Update<T>(IList<T> items)
		{
			for (Int32 I = 0; I < items.Count; ++I)
			{
				Update(items[I]);
			}
		}

		public void SaveOrUpdate<T>(T item)
		{
			Session.SaveOrUpdate(item);
		}

		public void SaveOrUpdate<T>(IList<T> items)
		{
			for (Int32 I = 0; I < items.Count; ++I)
			{
				SaveOrUpdate(items[I]);
			}
		}

		public void Detach<T>(T item)
		{
			Session.Evict(item);
		}

		public void ReAttach<T>(T item)
		{
			if (!Session.Contains(item))
			{
				Session.Lock(item, NHibernate.LockMode.None);
			}

		}

		public void Save<T>(T item)
		{
			Session.Save(item);
		}

		public void Save<T>(IList<T> items)
		{
			for (Int32 I = 0; I < items.Count; ++I)
			{
				Save(items[I]);
			}
		}

		public IList<T> GetAll<T>()
		{
			return GetAll<T>(0, 0);
		}

		public IList<T> GetAll<T>(int pageIndex, int pageSize)
		{
			ICriteria criteria = Session.CreateCriteria(typeof(T));
			criteria.SetFirstResult(pageIndex * pageSize);
			if (pageSize > 0)
			{
				criteria.SetMaxResults(pageSize);
			}
			return criteria.List<T>();
		}

		public IList<T> GetByCriteria<T>(Query query)
		{
			return GetByCriteria<T>(query, 0, 0);
		}

		public IList<T> GetByCriteria<T>(Query query, int pageIndex, int pageSize)
		{
			ICriteria criteria = Session.CreateCriteria(typeof(T));
			QueryTranslator queryTranslator = new QueryTranslator(Session, criteria, query, typeof(T));
			queryTranslator.Execute();
			criteria.SetFirstResult(pageIndex * pageSize);
			if (pageSize > 0)
			{
				criteria.SetMaxResults(pageSize);
			}
			return criteria.List<T>();
		}

		public System.Collections.IList GetProjection<T>(Query query)
		{
			ICriteria criteria = Session.CreateCriteria(typeof(T));
			QueryTranslator queryTranslator = new QueryTranslator(Session, criteria, query, typeof(T));
			queryTranslator.Execute();
			return criteria.List();
		}

		public System.Collections.IList GetProjection(String objectQuery, params Object[] parameters)
		{
			IQuery q = Session.CreateQuery(objectQuery);
			Int32 paramIndex = 0;
			while (paramIndex < parameters.Length)
			{
				q.SetParameter((String)parameters[paramIndex], parameters[paramIndex + 1]);
				paramIndex += 2;
			}
			return q.List();
		}
		#endregion
	}

	/// <summary>
	/// Classe che implementa la base di un repository generico 
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public abstract class UnitOfWork_NHib<T> : IUnitOfWork<T>
	{
		/// <summary>
		/// nhibernate members
		/// </summary>
		protected RuntimeConfigData nhibconf;

		protected abstract RuntimeConfigData Initialize();

		public RuntimeConfigData Nhibconf
		{
			get { return nhibconf ?? (nhibconf = Initialize()); }
		}

		protected ISession Session
		{
			get { return NHibernateSessionManager.Instance.GetSessionFrom(Nhibconf); }
		}

		//public void Dispose()
		//{
		//   Dispose(true);
		//   GC.SuppressFinalize(this);
		//}

		//protected virtual void Dispose(bool disposing)
		//{
		//   if (mDisposed) return;
		//   mDisposed = true;
		//   if (disposing)
		//   {
		//      if (HttpContext.Current == null)
		//      {
		//         //sono in campo windows forms devo esplicitamente committare e chiudere le sessioni aperte
		//         //prima di distruggere l'oggetto naturalmente solo se qualcuno ha mai acceduto alla propriet�
		//         if (nhibconf != null)
		//         {
		//            NHibernateSessionManager.Instance.FlushSessionOn(nhibconf.Id);
		//            NHibernateSessionManager.Instance.CommitTransactionOn(nhibconf.Id);
		//            NHibernateSessionManager.Instance.CloseSessionOn(nhibconf.Id);
		//         }
		//      }
		//   }
		//}
		//private Boolean mDisposed = false;

		#region IUnitOfWork Members

		public void Flush()
		{
			Session.Flush();
		}
		public T GetByKey(object key)
		{
			return Session.Get<T>(key);
		}

		public T GetReferenceByKey(object key)
		{
			return Session.Load<T>(key);
		}

		/// <summary>
		/// this versione return an instance of an object, nothing if no object is found
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="propertyName"></param>
		/// <param name="value"></param>
		/// <returns></returns>
		public T GetByProperty(string propertyName, object value)
		{
			return Session
				.CreateCriteria(typeof(T))
				.Add(Expression.Eq(propertyName, value))
				.UniqueResult<T>();
		}

		public void Delete(T item)
		{
			Session.Delete(item);
		}

		public void Delete(IList<T> items)
		{
			for (Int32 I = 0; I < items.Count; ++I)
			{
				Delete(items[I]);
			}
		}

		public void Update(T item)
		{
			Session.Update(item);
		}

		public void Update(IList<T> items)
		{
			for (Int32 I = 0; I < items.Count; ++I)
			{
				Update(items[I]);
			}
		}

		public void SaveOrUpdate(T item)
		{
			Session.SaveOrUpdate(item);
		}

		public void SaveOrUpdate(IList<T> items)
		{
			for (Int32 I = 0; I < items.Count; ++I)
			{
				SaveOrUpdate(items[I]);
			}
		}

		public void Detach(T item)
		{
			Session.Evict(item);
		}

		public void ReAttach(T item)
		{
			if (!Session.Contains(item))
			{
				Session.Lock(item, NHibernate.LockMode.None);
			}

		}

		public void Save(T item)
		{
			Session.Save(item);
		}

		public void Save(IList<T> items)
		{
			for (Int32 I = 0; I < items.Count; ++I)
			{
				Save(items[I]);
			}
		}

		public IList<T> GetAll()
		{
			return GetAll(0, 0);
		}

		public IList<T> GetAll(int pageIndex, int pageSize)
		{
			ICriteria criteria = Session.CreateCriteria(typeof(T));
			criteria.SetFirstResult(pageIndex * pageSize);
			if (pageSize > 0)
			{
				criteria.SetMaxResults(pageSize);
			}
			return criteria.List<T>();
		}

		public IList<T> GetByCriteria(Query query)
		{
			return GetByCriteria(query, 0, 0);
		}

		public IList<T> GetByCriteria(Query query, int pageIndex, int pageSize)
		{
			ICriteria criteria = Session.CreateCriteria(typeof(T));
			QueryTranslator queryTranslator = new QueryTranslator(Session, criteria, query, typeof(T));
			queryTranslator.Execute();
			criteria.SetFirstResult(pageIndex * pageSize);
			if (pageSize > 0)
			{
				criteria.SetMaxResults(pageSize);
			}
			return criteria.List<T>();
		}

		public System.Collections.IList GetProjection(Query query)
		{
			ICriteria criteria = Session.CreateCriteria(typeof(T));
			QueryTranslator queryTranslator = new QueryTranslator(Session, criteria, query, typeof(T));
			queryTranslator.Execute();
			return criteria.List();
		}

		public System.Collections.IList GetProjection(String objectQuery, params Object[] parameters)
		{
			IQuery q = Session.CreateQuery(objectQuery);
			Int32 paramIndex = 0;
			while (paramIndex < parameters.Length)
			{
				q.SetParameter((String)parameters[paramIndex], parameters[paramIndex + 1]);
				paramIndex += 2;
			}
			return q.List();
		}
		#endregion
	}
}
