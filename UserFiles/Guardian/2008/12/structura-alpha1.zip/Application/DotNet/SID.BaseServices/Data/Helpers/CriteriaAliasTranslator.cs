using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using NHibernate;
using NHibernate.Mapping;
using NHibernate.Persister.Entity;
using NHibernate.Type;

namespace SID.BaseServices.Data.Helpers
{
	internal class CriteriaAliasTranslator
	{
		private IDictionary mappingMetadata;
		private readonly Type baseType;

		public CriteriaAliasTranslator(IDictionary mappingMetadata, Type baseType)
		{
			this.mappingMetadata = mappingMetadata;
			this.baseType = baseType;
		}

		private Dictionary<String, String> mAliases = new Dictionary<String, String>();
		public Dictionary<String, String> Aliases
		{
			get { return mAliases; }
		}

		/// <summary>
		/// This function create needed alias for the array of property specified
		/// as first argument. All alias are created with the substitution of the 
		/// . characther with the _ charachter
		/// </summary>
		/// <param name="fullpath"></param>
		/// <returns>The current alias for the property</returns>
public String AddAlias(String fullpath)
{
	String[] path = fullpath.Split('.');
	String CurrentAliasPath = path[0];
	String ReturnValue = path[0];
	Type currentType = baseType;

	for (Int32 I = 0; I < path.Length - 1; ++I)
	{
		//Need to understand if the association is a component
		IEntityPersister mapping = (IEntityPersister) mappingMetadata[currentType];
		if (mapping.GetPropertyType(path[I]) is ComponentType)
		{
			//ok posso completare il mapping direttamente qui.
			for (Int32 innerI = I+1; innerI < path.Length; ++innerI)
				ReturnValue += "." + path[innerI];
			return ReturnValue;
		}
		//First of all begin to insert data into the aliases if needed.
		if (!mAliases.ContainsKey(ReturnValue))
		{
			mAliases.Add(ReturnValue, CurrentAliasPath);
		}
		currentType = mapping.GetPropertyType(path[I]).ReturnedClass;
		ReturnValue = CurrentAliasPath + "." + path[I + 1];
		CurrentAliasPath += '_';
		CurrentAliasPath += path[I + 1];
	}
	return ReturnValue;
}

		public String Translate(String path)
		{
			return AddAlias(path);
		}

		internal void CreateAlias(ICriteria _criteria)
		{
			foreach (KeyValuePair<String, String> kvp in mAliases)
			{
				_criteria.CreateAlias(kvp.Key, kvp.Value);
			}
		}
	}
}
