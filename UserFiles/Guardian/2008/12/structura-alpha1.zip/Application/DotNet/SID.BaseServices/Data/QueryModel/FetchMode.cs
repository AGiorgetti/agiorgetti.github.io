using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel {

	public enum FetchModes {
		Default,
		Eager,
		Join,
		Lazy,
		Select,
	}
}
