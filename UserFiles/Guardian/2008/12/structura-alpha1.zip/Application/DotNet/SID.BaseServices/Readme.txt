﻿Progetto contenete classi di supporto generice (esempio per accesso dati o simili) e servizi vari,
DLL generica che puo' essere utilizzata in diversi progetti.