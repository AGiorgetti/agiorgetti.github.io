﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SID.NHibernateUtils.MultipleSessions;
using System.Web;
using System.Data;
using SID.Interfaces.CommonInterfaces;

namespace SID.BaseServices.Data
{
	/// <summary>
	/// Rappresenta uno scope di azioni, tutti gli accessi fatti con le UnitOfWork sono 
	/// fatti tramite nhibernate, per cui il chiamante deve decidere quando 
	/// chiudere la sessione. 
	/// 
	/// Questo schema è complicato dal fatto che nel web la UnitOfWork vive per tutto il 
	/// ciclo di vita di una request, mentre in un servizio è necessario che il chiamante
	/// esplicitamente dica dove chiudere uno scope.
	/// 
	/// Questa classe permette di gestire questa situazione, se siamo in web non fa nulla
	/// mentre se siamo in thread chiude gli scope
	/// </summary>
	public class UnitOfWorkScope_Nhib : IDisposable
	{
		/// <summary>
		/// indica se lo scope deve essere committato o rollbackato, di default lo scope
		/// è dirty ovvero da rolbackare.
		/// </summary>
		private Boolean shouldRollBack = false;

		/// <summary>
		/// Inizia uno scope non transazionale, la sessione non è gestita in transazione, a meno che il 
		/// chiamante non crei lui esplicitamente la transazione
		/// </summary>
		public UnitOfWorkScope_Nhib(params IUnitOfWorkConfigurator[] list) :
			this(false, list)
		{
		}

		/// <summary>
		/// Inizia uno scope transazionale, tutta la vita della sessione è eseguita transazionalmente.
		/// </summary>
		/// <param name="isolationLevel"></param>
		public UnitOfWorkScope_Nhib(bool transactional, params IUnitOfWorkConfigurator[] list)
		{
			foreach (var e in list)
			{
				RuntimeConfigData cd = e.GetConfiguration();
				if (!_configdataList.Contains(cd))
					_configdataList.Add(cd);
			}
			if (transactional)
			{
				foreach (var rcd in _configdataList)
				{
					NHibernateSessionManager.Instance.BeginTransactionOn(rcd);
				}
			}
			//NHibernateSessionManager.Instance.BeginTransactionOnAll(isolationLevel);
		}

		private List<RuntimeConfigData> _configdataList = new List<RuntimeConfigData>();

		/// <summary>
		/// Marca lo scope come sporco, per cui al suo dispose viene rollbackato
		/// </summary>
		public void MarkForRollBack()
		{
			shouldRollBack = true;
		}

		/// <summary>
		/// Chiude uno scope.
		/// </summary>
		private void innerClose(Boolean commit)
		{
			//TODO: Incapsulare da un altra parte il controllo se siamo in un contesto web.
			//questo perchè nel contesto web la chiusura è automatica.
			if (HttpContext.Current == null)
			{
				if (commit)
				{
					foreach (var rcd in _configdataList)
					{
						NHibernateSessionManager.Instance.FlushSessionOn(rcd);
						NHibernateSessionManager.Instance.CommitTransactionOn(rcd);
						NHibernateSessionManager.Instance.CloseSessionOn(rcd);
					}

					//NHibernateSessionManager.Instance.FlushAllSessions();
					//NHibernateSessionManager.Instance.CommitAllTransactions();
					//NHibernateSessionManager.Instance.CloseAllSessions();
				}
				else
				{
					foreach (var rcd in _configdataList)
					{
						NHibernateSessionManager.Instance.RollbackTransactionOn(rcd);
						NHibernateSessionManager.Instance.CloseSessionOn(rcd);
					}

					//NHibernateSessionManager.Instance.RollbackAllTransactions();
					//NHibernateSessionManager.Instance.CloseAllSessions();
				}

			}
		}

		#region IDisposable Members

		public void Dispose()
		{
			//Controlliamo perchè se stiamo disposando a causa di una eccezione allora è necessario
			//Che il tutto sia per default rollbackato.
			if (Clr.IsInException())
			{
				//se io ho una eccezione non gestita, allora è necessario obbligatoriamente che la transazione
				//sia rollbackata.
				innerClose(false);
			}
			else
			{
				//SE non ho eccezzioni allora committo se nessuno ha marcato esplicitamente lo scope come sporco
				innerClose(!shouldRollBack);
			}
		}

		#endregion
	}

}
