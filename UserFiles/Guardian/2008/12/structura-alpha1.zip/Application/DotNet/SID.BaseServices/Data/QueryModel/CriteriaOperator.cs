using System;
using System.Collections.Generic;
using System.Text;

namespace SID.BaseServices.Data.QueryModel {

	/// <summary>
	/// 
	/// </summary>
	public enum CriteriaOperator {
		Equal,
		NotEqual,
		FlagsCheck, //used with bitfield to see if a particular flags or combination of flag is setted
		GreaterThan,
		GreaterThanOrEqual,
		In,
		LesserThan,
		LesserThanOrEqual,
		Like,
		NotLike,
		Sql, //Criteria used to specify a standard sql clause in the query.
		IsNull,
      IsNotNull,
		/// <summary>
		/// This is a particular form of criteria, it is used to inject into the querymodel
		/// a custom criteria for a custom orm. It happens for some project such as modular data
		/// that a particular type of search cannot be performed with standard operator so we need 
		/// a custom Criteria to do all the stuff.
		/// To configure a Custom criteria the caller must give the typename of the object that 
		/// implement a valid criteria for the orm used, for example a ICRiterion for nhibernate, 
		/// and also we need to pass a series of parameters used to configure this criterion.
		/// 
		/// This type of criteria tied the model to a specific orm, or at best forces the domain
		/// model to implement a custom criteria for each orm used. 
		/// </summary>
		CustomCriteria, 
	}
}


