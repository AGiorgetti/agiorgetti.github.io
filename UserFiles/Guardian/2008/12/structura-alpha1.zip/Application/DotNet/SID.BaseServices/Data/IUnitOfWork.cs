﻿using System;
using System.Collections.Generic;
using System.Text;
using SID.BaseServices.Data.QueryModel;
using SID.NHibernateUtils.MultipleSessions;

namespace SID.Interfaces.CommonInterfaces
{
	public interface IUnitOfWorkConfigurator
	{
		RuntimeConfigData GetConfiguration();
	}

	public interface IUnitOfWork
	{
		/// <summary>
		/// forza l'aggiornamento del db con i valori degli oggetti
		/// è necessario per evitare problemi con id non generati.
		/// </summary>
		void Flush();

		//Getters method, used to retrieve business object.
		IList<T> GetAll<T>();
		IList<T> GetAll<T>(int pageIndex, int pageSize);
		IList<T> GetByCriteria<T>(Query query);
		IList<T> GetByCriteria<T>(Query query, int pageIndex, int pageSize);
		/// <summary>
		/// La proiezione torna una ilist normale
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="query"></param>
		/// <returns></returns>
		System.Collections.IList GetProjection<T>(Query query);

		/// <summary>
		/// In rep ci sono alcune query fatte in HQL con classi polimorfe e adattare
		/// il query model richiederebbe per ora troppo tempo, si espone cosi
		/// una versione della proiezione che accetta una Object Query che nel nostro
		/// caso altro non è che una query HQL
		/// </summary>
		/// <param name="objectQuery">La query in HQL che deve essere eseguita</param>
		/// <param name="parameters">i parametri espressi come lista di coppie String/Object
		/// che vengono poi passati cosi come sono alla query.</param>
		/// <returns></returns>
		System.Collections.IList GetProjection(String objectQuery, params Object[] parameters);

		/// <summary>
		/// this versione return an instance of an object, nothing if no object is found
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="key"></param>
		/// <returns></returns>
		T GetByKey<T>(object key);

		/// <summary>
		/// This version get an object by key and return a proxy, useful to create association to save object
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="key"></param>
		/// <returns></returns>
		T GetReferenceByKey<T>(object key);

		/// <summary>
		/// this versione return an instance of an object, nothing if no object is found
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="propertyName"></param>
		/// <param name="value"></param>
		/// <returns></returns>
		T GetByProperty<T>(string propertyName, object value);

		//Setters methods, used to persist object.
		void Delete<T>(T item);
		void Delete<T>(IList<T> items);
		void Update<T>(T item);
		void Update<T>(IList<T> items);
		void Save<T>(T item);
		void Save<T>(IList<T> items);
		void SaveOrUpdate<T>(T item);
		void SaveOrUpdate<T>(IList<T> items);
		void Detach<T>(T item);
		void ReAttach<T>(T item);
	}
	
	public interface IUnitOfWork<T>
	{
		/// <summary>
		/// forza l'aggiornamento del db con i valori degli oggetti
		/// è necessario per evitare problemi con id non generati.
		/// </summary>
		void Flush();

		//Getters method, used to retrieve business object.
		IList<T> GetAll();
		IList<T> GetAll(int pageIndex, int pageSize);
		IList<T> GetByCriteria(Query query);
		IList<T> GetByCriteria(Query query, int pageIndex, int pageSize);
		/// <summary>
		/// La proiezione torna una ilist normale
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="query"></param>
		/// <returns></returns>
		System.Collections.IList GetProjection(Query query);

		/// <summary>
		/// In rep ci sono alcune query fatte in HQL con classi polimorfe e adattare
		/// il query model richiederebbe per ora troppo tempo, si espone cosi
		/// una versione della proiezione che accetta una Object Query che nel nostro
		/// caso altro non è che una query HQL
		/// </summary>
		/// <param name="objectQuery">La query in HQL che deve essere eseguita</param>
		/// <param name="parameters">i parametri espressi come lista di coppie String/Object
		/// che vengono poi passati cosi come sono alla query.</param>
		/// <returns></returns>
		System.Collections.IList GetProjection(String objectQuery, params Object[] parameters);

		/// <summary>
		/// this versione return an instance of an object, nothing if no object is found
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="key"></param>
		/// <returns></returns>
		T GetByKey(object key);

		/// <summary>
		/// This version get an object by key and return a proxy, useful to create association to save object
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="key"></param>
		/// <returns></returns>
		T GetReferenceByKey(object key);

		/// <summary>
		/// this versione return an instance of an object, nothing if no object is found
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="propertyName"></param>
		/// <param name="value"></param>
		/// <returns></returns>
		T GetByProperty(string propertyName, object value);

		//Setters methods, used to persist object.
		void Delete(T item);
		void Delete(IList<T> items);
		void Update(T item);
		void Update(IList<T> items);
		void Save(T item);
		void Save(IList<T> items);
		void SaveOrUpdate(T item);
		void SaveOrUpdate(IList<T> items);
		void Detach(T item);
		void ReAttach(T item);
	}
}