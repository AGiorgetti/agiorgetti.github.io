﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace TestApp.Extensions.Controls
{
   /// <summary>
   /// Interaction logic for RoundWaiting.xaml
   /// </summary>
   public partial class RoundWaiting : UserControl
   {
      public RoundWaiting()
      {
         InitializeComponent();
         this.Visibility = Visibility.Collapsed;
         Rotate = Resources["Rotate"] as Storyboard;
      }

      private Storyboard Rotate;

      /// <summary>
      /// stoppa l'animazione e nasconde il controllo
      /// </summary>
      public void Stop()
      {
         Rotate.Stop();
         //BoundControl.Visibility = Visibility.Visible;
         this.Visibility = Visibility.Collapsed;
      }

      /// <summary>
      /// visualizza il controllo e fa partire l'animazione
      /// </summary>
      public void Start()
      {
         this.Visibility = Visibility.Visible;
         //BoundControl.Visibility = Visibility.Collapsed;
         Rotate.Begin();
      }
   }
}
