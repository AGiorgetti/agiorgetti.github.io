﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using TestApp.Entities;
using Structura.Utils;

namespace TestApp.UnitTest
{
	[TestFixture]
	public class TestEntities
	{
		[Test]
		public void TestEntityDeepClone()
		{
			TestEntity e = new TestEntity("1", "2", "3");
			TestEntity eCloned = e.DeepClone();
			Assert.AreEqual(e.PublicField, eCloned.PublicField);
			Assert.AreEqual(e.ProtectedField, eCloned.ProtectedField);
			Assert.AreEqual(e.PrivateField, eCloned.PrivateField);
		}

		[Test]
		public void TestEntityNoAttributeDeepClone()
		{
			TestEntityNoAttributes e = new TestEntityNoAttributes("1");
			TestEntityNoAttributes eCloned = e.DeepClone();
			Assert.AreEqual(e.PublicField, eCloned.PublicField);
		}
		
		[Test]
		public void TestEntityAttributeDeepClone()
		{
			TestEntityAttributes e = new TestEntityAttributes("1", "2", "3");
			TestEntityAttributes eCloned = e.DeepClone();
			Assert.AreEqual(e.PublicField, eCloned.PublicField);
			Assert.AreEqual(e.ProtectedField, eCloned.ProtectedField);
			Assert.AreEqual(e.PrivateField, eCloned.PrivateField);
		}
	}
}
