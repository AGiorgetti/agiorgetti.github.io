﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using TestApp.DataAccessLayer;
using TestApp.Entities;

namespace TestApp.DataAccessLayer.UnitTest
{
	[TestFixture]
	public class T01_DatabaseCreation
	{
		[Test]
		public void T01_CreateDatabase()
		{
			TestAppNHib.BuildDatabase();
		}
	}
}
