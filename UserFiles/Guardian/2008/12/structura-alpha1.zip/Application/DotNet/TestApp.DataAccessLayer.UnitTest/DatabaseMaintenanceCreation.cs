﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Maintenance.DataAccessLayer;
using Maintenance.Entities;

namespace Maintenance.DataAccessLayer.UnitTest
{
	[TestFixture]
	public class DatabaseMaintenanceCreation
	{
		[Test]
		public void CreateDatabase()
		{
			MaintenanceNHib<AssetDefinition>.BuildDatabase();
		}
		
		
	}
}
