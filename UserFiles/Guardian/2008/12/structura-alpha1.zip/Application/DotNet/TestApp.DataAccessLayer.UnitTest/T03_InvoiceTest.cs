﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using TestApp.Entities;
using TestApp.DataAccessLayer;
using SID.BaseServices.Data;
using SID.Utils;

namespace TestApp.DataAccessLayer.UnitTest
{
	[TestFixture]
	public class T03_InvoiceTest
	{
		[TestFixtureSetUp]
		public void CreateDatabase()
		{
			//MaintenanceNHib<AssetDefinition>.BuildDatabase();
		}

		private Guid _CustomerID = new Guid("BC0229DB-F8F4-4355-A143-08F6B9B238D6");

		[Test]
		public void T01_CreateUpdateDeleteClient()
		{
			//create
			Client c = new Client();
			c.CustomerId = _CustomerID;
			c.Address = "T addr";
			c.Cap = "12345";
			c.City = "T City";
			c.ClientId = Guid.NewGuid();
			c.EMail = "T Email";
			c.Name = "T Name";
			c.Phone = "T Phone";
			c.Province = "T Province";
			c.Surname = "T Surname";

			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//save
				TestAppNHib<Client>.SaveOrUpdate(c);
			}

			//create
			Invoice inv = new Invoice();
			inv.Client = c;
			inv.CustomerId = _CustomerID;
			inv.Date = SID.Utils.DateUtils.Now;
			inv.Number = 1;
			inv.Items.Add(new InvoiceItem() { Code = "1", Name = "Elem 1", Price = 10, Quantity = 1 });
			inv.Items.Add(new InvoiceItem() { Code = "2", Name = "Elem 2", Price = 20, Quantity = 2 });
			inv.Items.Add(new InvoiceItem() { Code = "3", Name = "Elem 3", Price = 30, Quantity = 3 });

			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//save
				TestAppNHib<Invoice>.SaveOrUpdate(inv);
			}

			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//read and check
				Invoice i_dbg = TestAppNHib<Invoice>.GetByKey(inv.Id);

				AssertEquality(inv, i_dbg);
			}

			//modify and save
			inv.Number = 2;
			inv.Items.RemoveAt(2);
			inv.Items[0].Code = "Mod";
			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//save
				TestAppNHib<Invoice>.SaveOrUpdate(inv);
			}

			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//read and check
				Invoice i_dbg = TestAppNHib<Invoice>.GetByKey(inv.Id);

				AssertEquality(inv, i_dbg);
				Assert.IsTrue(i_dbg.Items.Count == 2);
				Assert.IsTrue(i_dbg.Items[0].Code == "Mod");
			}

			//delete
			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//save
				TestAppNHib<Invoice>.Delete(inv);
				TestAppNHib<Client>.Delete(c);
			}

			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//read and check
				Invoice i_dbg = TestAppNHib<Invoice>.GetByKey(inv.Id);
				Client c_dbg = TestAppNHib<Client>.GetByKey(c.Id);
								
				Assert.IsNull(i_dbg);
				Assert.IsNull(c_dbg);
			}

		}

		private void AssertEquality(Invoice i, Invoice i_dbg)
		{
			Assert.IsTrue(Equality.GenericEquals(i.Client, i_dbg.Client));
			Assert.AreEqual(i.CustomerId, i_dbg.CustomerId);
			Assert.AreEqual(i.Date, i_dbg.Date);
			Assert.AreEqual(i.Id, i_dbg.Id);
			Assert.AreEqual(i.Number, i_dbg.Number);
			Assert.AreEqual(i.Items.Count, i_dbg.Items.Count);
		}
	}
}
