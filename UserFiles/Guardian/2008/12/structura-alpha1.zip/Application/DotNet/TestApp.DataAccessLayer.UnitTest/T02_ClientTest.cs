﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;
using TestApp.DataAccessLayer;
using TestApp.Entities;
using SID.BaseServices.Data;

namespace TestApp.DataAccessLayer.UnitTest
{
	[TestFixture]
	public class T02_ClientTest
	{
		[TestFixtureSetUp]
		public void CreateDatabase()
		{
			//MaintenanceNHib<AssetDefinition>.BuildDatabase();
		}

		private Guid _CustomerID = new Guid("BC0229DB-F8F4-4355-A143-08F6B9B238D6");

		[Test]
		public void T01_CreateUpdateDeleteClient()
		{
			//create
			Client c = new Client();
			c.CustomerId = _CustomerID;
			c.Address = "T addr";
			c.Cap = "12345";
			c.City = "T City";
			c.ClientId = Guid.NewGuid();
			c.EMail = "T Email";
			c.Name = "T Name";
			c.Phone = "T Phone";
			c.Province = "T Province";
			c.Surname = "T Surname";
			
			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//save
				TestAppNHib<Client>.SaveOrUpdate(c);
			}

			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//read and check
				Client c_dbg = TestAppNHib<Client>.GetByKey(c.Id);

				AssertEquality(c, c_dbg);
			}

			//modify and save
			c.Name = "T Name2";
			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//save
				TestAppNHib<Client>.SaveOrUpdate(c);
			}

			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//read and check
				Client c_dbg = TestAppNHib<Client>.GetByKey(c.Id);

				AssertEquality(c, c_dbg);
			}

			//delete
			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//save
				TestAppNHib<Client>.Delete(c);
			}

			using (new UnitOfWorkScope_Nhib(true, new TestAppNhibConfigurator()))
			{
				//read and check
				Client c_dbg = TestAppNHib<Client>.GetByKey(c.Id);

				Assert.IsNull(c_dbg);
			}

		}

		private void AssertEquality(Client c, Client c_dbg)
		{
			Assert.IsTrue(Structura.Utils.Equality.GenericEquals(c, c_dbg));
		}
	}
}
