﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;
using TestApp.Entities;
using TestApp.DataAccessLayer;
using SID.BaseServices.Data;
using SID.BaseServices.Data.QueryModel;
using System.Collections.ObjectModel;
using Structura.Infrastructure.ViewModel;

namespace DataService
{
	// NOTE: If you change the class name "Service1" here, you must also update the reference to "Service1" in Web.config and in the associated .svc file.
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	public class DataService : IDataService
	{
		public List<Client> GetAllClients(Guid customerId)
		{
			IList<Client> list;

			list = TestAppNHib.GetByCriteria<Client>(Query.CreateEq("CustomerId", customerId));

			return list.ToList();
		}

		public Client GetClient(Guid id)
		{
			return TestAppNHib<Client>.GetByKey(id);
		}

		public List<Invoice> GetAllInvoices(Guid customerId)
		{
			IList<Invoice> list;

			list = TestAppNHib<Invoice>.GetByCriteria(Query.CreateEq("CustomerId", customerId));

			return list.ToList();
		}

		public Invoice GetInvoice(Guid id)
		{
			return TestAppNHib<Invoice>.GetByKey(id);
		}

		public EntityBase Save(EntityBase o)
		{
			//devo convertire le collection dell'oggetto..non devo permettere che passino degli array piani senza contratto
			Helpers.AdjustEntityBase(o);
			TestAppNHib<EntityBase>.SaveOrUpdate(o);
			return o;
		}

		public void Delete(EntityBase o)
		{
			TestAppNHib<EntityBase>.Delete(o);
		}
	}
}