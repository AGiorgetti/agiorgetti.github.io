﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;

namespace DataService
{
	public class PreserveReferencesAttribute : Attribute, IOperationBehavior
	{
		public PreserveReferencesAttribute()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region IOperationBehavior Members

		public void AddBindingParameters(OperationDescription description,
				BindingParameterCollection parameters) { }

		public void ApplyClientBehavior(OperationDescription description,
		  ClientOperation proxy)
		{
			IOperationBehavior innerBehavior =
			  new PreserveReferencesOperationBehavior(description);
			innerBehavior.ApplyClientBehavior(description, proxy);
		}

		public void ApplyDispatchBehavior(OperationDescription description,
		  DispatchOperation dispatch)
		{
			IOperationBehavior innerBehavior =
			  new PreserveReferencesOperationBehavior(description);
			innerBehavior.ApplyDispatchBehavior(description, dispatch);
		}

		public void Validate(OperationDescription description) { }

		#endregion
	}
}
