﻿CODICE SERVER SIDE
Fornitore dati per l'applicazione medinte webservice, tutte le interfacce silverlight e/o WPF idealmente prelevano dati da questo servizio e 
sfruttano i metodi esposti dal servizio per eseguire update o elaborazioni complesse server side.