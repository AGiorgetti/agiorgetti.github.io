﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using TestApp.Entities;
using System.Collections.ObjectModel;
using Structura.Infrastructure.ViewModel;

namespace DataService
{
	// NOTE: If you change the interface name "IService1" here, you must also update the reference to "IService1" in Web.config.

	/// <summary>
	/// sembra che nonostante tutt gli accorgimenti se una classe espone delle IList<typeparamref name="T"/> il DataContractSerializer 
	/// riesce a sostituirle internamnete con degli array (classe + semplice) ma riutilizzare poi un oggetto in cui siano stati iniettati degli array
	/// in questo modo porta a dei executionexception..
	/// le IList<typeparamref name="T"/> sono necessarie per serializzare e deserializzare gli oggetti con nHibernate per cui
	/// una soluzione è eseguire una conversione di tipo nelle proprietà che consentono di accedere alle collection nelle singole classi
	/// (vedi assetdefinition) oppure effettuare il wrapping delle IList con una collection ben definita.
	/// 
	/// con la prima soluzione si incorre in performance hit dovuti alla copia della collection (es: dal wrapper di nhibernate alla List<typeparamref name="T"/>).
	/// </summary>
	[ServiceContract] //XmlSerializerFormat
	[ServiceKnownType("GetKnownTypes", typeof(KnownTypesProvider))]
	public interface IDataService
	{
		[OperationContract]
		//[PreserveReferences]
		[FaultContract(typeof(ExceptionDetail))]
		List<Client> GetAllClients(Guid customerId);

		[OperationContract]
		//[PreserveReferences]
		[FaultContract(typeof(ExceptionDetail))]
		Client GetClient(Guid id);

		[OperationContract]
		//[PreserveReferences]
		[FaultContract(typeof(ExceptionDetail))]
		List<Invoice> GetAllInvoices(Guid customerId);

		[OperationContract]
		//[PreserveReferences]
		[FaultContract(typeof(ExceptionDetail))]
		Invoice GetInvoice(Guid id);

		[OperationContract]
		//[PreserveReferences]
		[FaultContract(typeof(ExceptionDetail))]
		EntityBase Save(EntityBase o);

		[OperationContract]
		//[PreserveReferences]
		[FaultContract(typeof(ExceptionDetail))]
		void Delete(EntityBase o);

	}
}
