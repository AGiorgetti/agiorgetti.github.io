﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TestApp.Entities;
using System.Reflection;
using System.Runtime.Serialization;
using System.Collections.ObjectModel;
using Structura.Infrastructure.ViewModel;

namespace DataService
{
	internal static class KnownTypesProvider
	{
		private static Type[] GetKnownTypes(ICustomAttributeProvider attributeTarget)
		{
			//Type dataContractType = typeof(DataContractAttribute);
			//Type serviceContractType = (Type)attributeTarget;
			//Type[] exportedTypes = serviceContractType.Assembly.GetExportedTypes();
			//List<Type> knownTypes = new List<Type>();
			//foreach (Type type in exportedTypes)
			//{
			//   if (Attribute.IsDefined(type, dataContractType, false))
			//   {
			//      knownTypes.Add(type);
			//   }
			//}
			//return knownTypes.ToArray();
			List<Type> list = new List<Type>();
			list.Add(typeof(Model));
			list.Add(typeof(EntityBase));
			list.Add(typeof(EditableEntityBase));
			list.Add(typeof(Client));
			list.Add(typeof(Invoice));
			list.Add(typeof(InvoiceItem));
			return list.ToArray();
		}
	}
}
