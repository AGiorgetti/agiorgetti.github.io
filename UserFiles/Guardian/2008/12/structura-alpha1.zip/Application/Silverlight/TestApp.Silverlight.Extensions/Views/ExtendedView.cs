﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Structura.Infrastructure.ViewModel;
using Structura.Infrastructure.IOC;
using Structura.Silverlight.Controls.Windows;
using TestApp.Silverlight.Extensions.Controls.Waiting;

namespace TestApp.Silverlight.Extensions.Views
{
	public class ExtendedView : ViewExt
	{
		public ExtendedView()
			: base()
		{ }

		public ExtendedView(IIoC ioc)
			: base(ioc)
		{
		}

		public ExtendedView(IIoC ioc, ControllerExt controller)
			: base(ioc, controller)
		{
		}

		protected IWindowsManager WindowsManager { get { return IOC.Resolve<IWindowsManager>(null); } }

		protected void ShowDialog(Control content, string caption, EventHandler onClosed)
		{
			var w = new Window(content);
			w.Caption = caption;
			w.Closed += onClosed;
			WindowsManager.ShowDialog(w);
		}

		///// <summary>
		///// Represents the View attached property.
		///// </summary>
		//public static readonly DependencyProperty WaitingControlProperty =
		//    DependencyProperty.RegisterAttached("WaitingControl", typeof(object), typeof(MaintenanceView), null);

		///// <summary>
		///// Gets or sets the model associated with the view.
		///// 
		///// It must be of type object to have designer support
		///// </summary>
		//public RoundWaiting WaitingControl
		//{
		//   get
		//   {
		//      return GetValue(WaitingControlProperty) as RoundWaiting;
		//   }
		//   set
		//   {
		//      SetValue(WaitingControlProperty, value);
		//   }
		//}

		///// <summary>
		///// Gets the model associated with the specified framework element.
		///// </summary>
		///// <param name="element">The element to lookup.</param>
		///// <returns>The associated model object if any.</returns>
		//public static object GetWaitingControl(FrameworkElement element)
		//{
		//   object model = element.GetValue(ModelProperty);

		//   return model as RoundWaiting;
		//}

		///// <summary>
		///// Sets the controller associated with the specified framework element.
		///// The model is also made available for binding by using it to set the
		///// DataContext of the element.
		///// </summary>
		///// <param name="element">The element to associate with the model.</param>
		///// <param name="value">The controller to use.</param>
		//public static void SetWaitingControl(FrameworkElement element, object value)
		//{
		//   ((MaintenanceView)element).WaitingControl = value as RoundWaiting;
		//}

		#region IView Members

		public override void Close()
		{
			(Parent as IWindow).Close();
		}

		//public override void UpdateInterface()
		//{
		//   var w = WaitingControl;
		//   if (w != null)
		//      w.Stop();
		//}

		#endregion
	}
}
