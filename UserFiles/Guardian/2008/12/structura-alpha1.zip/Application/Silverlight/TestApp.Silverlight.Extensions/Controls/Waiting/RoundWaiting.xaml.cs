﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TestApp.Silverlight.Extensions.Controls.Waiting
{
	public partial class RoundWaiting : UserControl
	{
		public RoundWaiting()
		{
			InitializeComponent();
			this.Visibility = Visibility.Collapsed;
		}

		public UIElement BoundControl
		{
			get { return (UIElement)GetValue(BoundControlProperty); }
			set { SetValue(BoundControlProperty, value); }
		}

		// Using a DependencyProperty as the backing store for BoundControl.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty BoundControlProperty =
			 DependencyProperty.Register("BoundControl", typeof(UIElement), typeof(RoundWaiting), new PropertyMetadata(null));

		/// <summary>
		/// stoppa l'animazione e nasconde il controllo
		/// </summary>
		public void Stop()
		{
			Rotate.Stop();
			//BoundControl.Visibility = Visibility.Visible;
			this.Visibility = Visibility.Collapsed;
		}

		/// <summary>
		/// visualizza il controllo e fa partire l'animazione
		/// </summary>
		public void Start()
		{
			this.Visibility = Visibility.Visible;
			//BoundControl.Visibility = Visibility.Collapsed;
			Rotate.Begin();
		}
	}
}
