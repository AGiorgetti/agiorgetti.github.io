﻿using TestApp.Entities;
using System.Collections.Generic;
using System.Linq;
using Structura.Infrastructure.ViewModel;

namespace TestApp.Entities
{
	/// <summary>
	/// helper class per sostituire gli ARRAY con delle LIST<typeparamref name="T"/> per evitare i bug del WCF quando si cercano di
	/// serializzare oggetti i cui datamember siano associati a delle ILIST<typeparamref name="T"/>.
	/// 
	/// tutto l'ambaradan e la relativa definizione di proprietà è stato realizzato epr evitare di costruire dei DTO per le classi.
	/// </summary>
	public static partial class Helpers
	{
		/// <summary>
		/// due to a SL bug in sending arrays through a WCF service we need to COnvert any ARRAY to a LIST<typeparamref name="T"/>
		/// </summary>
		/// <param name="ad"></param>
		public static Invoice AdjustInvoice(Invoice inv)
		{
			if (inv.Items.GetType() != typeof(List<InvoiceItem>))
				inv.Items = inv.Items.ToList();
			return inv;
		}

		public static IList<Invoice> AdjustInvoiceList(IList<Invoice> list)
		{
			foreach (var e in list)
				AdjustInvoice(e);
			return list;
		}

		public static EntityBase AdjustEntityBase(EntityBase e)
		{
			if (e.GetType() == typeof(Invoice))
				AdjustInvoice(e as Invoice);

			return e;
		}
		
	}
}
