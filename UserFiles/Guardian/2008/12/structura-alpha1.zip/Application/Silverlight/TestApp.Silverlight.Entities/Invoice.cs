﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Structura.Infrastructure.ViewModel;
using System.Runtime.Serialization;
using Structura.Utils;
using System.Collections.Generic;
using System.Linq;

namespace TestApp.Entities
{
	[DataContract, Serializable]
	public class Invoice : EntityBase
	{
		private Guid _Id;
		[DataMember]
		public Guid Id
		{
			get { return _Id; }
			set { innerSet<Guid>(ref _Id, value, "Id"); }
		}

		private Guid _CustomerId;
		[DataMember]
		public Guid CustomerId
		{
			get { return _CustomerId; }
			set { innerSet<Guid>(ref _CustomerId, value, "CustomerId"); }
		}

		private int _Number;
		[DataMember]
		public int Number
		{
			get { return _Number; }
			set { innerSet<int>(ref _Number, value, "Number"); }
		}

		private DateTime _Date;
		[DataMember]
		public DateTime Date
		{
			get { return _Date; }
			set { innerSet<DateTime>(ref _Date, value, "Date"); }
		}

		private Client _Client;
		[DataMember]
		public Client Client
		{		
			get { return _Client; }
			set { innerSet<Client>(ref _Client, value, "Client"); }
		}

      private IList<InvoiceItem> _Items = new List<InvoiceItem>();
		[DataMember]
		public IList<InvoiceItem> Items
		{
			get { return _Items; }
			set { innerSet<IList<InvoiceItem>>(ref _Items, value, "Items"); }
		}

		/// <summary>
		/// collection used for binding
		/// </summary>
		public NotifyCollectionWrapper<InvoiceItem> ItemsBindingCollection
		{
			get
			{
				if (Items is Array)
					Items = Items.ToList();
				if (_ItemsBindingCollection == null) //added the check on count to allow the recreation of this wrapped collection due to deserialization through webservice
					_ItemsBindingCollection = new NotifyCollectionWrapper<InvoiceItem>();
				return _ItemsBindingCollection.Reset(Items);
			}
		}
		private NotifyCollectionWrapper<InvoiceItem> _ItemsBindingCollection;

      public override object DeepClone()
		{
         return this.DeepClone<Invoice>();
		}
	}
}
