﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Runtime.CompilerServices;
using Structura.Utils;

namespace TestApp.Entities
{

	[Serializable]
	public class TestEntityForEquality
	{
		public string PublicField;

		protected string _ProtectedField;
		public string ProtectedField
		{
			get { return _ProtectedField; }
		}
		protected string ProtectedFieldProperty
		{
			get { return _ProtectedField; }
		}

		private string _PrivateField;
		public string PrivateField
		{
			get { return _PrivateField; }
		}
		
		private string PrivateFieldProerty
		{
			get { return _PrivateField; }
		}

		public TestEntityForEquality(string pub, string pro, string pri)
		{
			PublicField = pub;
			_ProtectedField = pro;
			_PrivateField = pri;
		}
	}
	
	[Serializable]
	public class TestEntity
	{
		public string PublicField;

		protected string _ProtectedField;
		public string ProtectedField
		{
			get { return _ProtectedField; }
		}

		private string _PrivateField;
		public string PrivateField
		{
			get { return _PrivateField; }
		}

		public TestEntity(string pub, string pro, string pri)
		{
			PublicField = pub;
			_ProtectedField = pro;
			_PrivateField = pri;
		}
	}

	/// <summary>
	/// to have serialization working without attributes you need to have a public default constructor 
	/// with no arguments and all public fields and properties
	/// in silverlight only public fields
	/// </summary>
	[Serializable]
	public class TestEntityNoAttributes
	{
		public string PublicField;

		public TestEntityNoAttributes()
		{
		}

		public TestEntityNoAttributes(string pub)
		{
			PublicField = pub;
		}
	}

	[DataContract]
	[Serializable]
	public class TestEntityAttributes
	{
		[DataMember]
		public string PublicField;

		/// <summary>
		/// changed from protected to internal
		/// it has to be internal to allow serialization and be used with InternalsVisibleTo assembly attribute
		/// </summary>
		[DataMember]
		internal string _ProtectedField;
		public string ProtectedField
		{
			get { return _ProtectedField; }
		}

		/// <summary>
		/// changed from private to internal
		/// it has to be internal to allow serialization and be used with InternalsVisibleTo assembly attribute
		/// </summary>
		[DataMember]
		internal string _PrivateField;
		public string PrivateField
		{
			get { return _PrivateField; }
		}

		public TestEntityAttributes(string pub, string pro, string pri)
		{
			PublicField = pub;
			_ProtectedField = pro;
			_PrivateField = pri;
		}
	}
}
