﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Structura.Infrastructure.ViewModel;
using System.Runtime.Serialization;
using Structura.Utils;

namespace TestApp.Entities
{
   [DataContract, Serializable]
   public class Client : EntityBase
   {
      /// <summary>
      /// surrogate Id, used bu the ORM tool to keep saving and update simple
      /// </summary>
      private Guid _Id;
      [DataMember]
      public Guid Id
      {
         get { return _Id; }
         set { innerSet<Guid>(ref _Id, value, "Id"); }
      }

      /// <summary>
      /// this is the real resource Id (and it is assigned from the client)
      /// </summary>
      private Guid _ClientId;
      [DataMember]
      public Guid ClientId
      {
         get { return _ClientId; }
         set { innerSet<Guid>(ref _ClientId, value, "ClientId"); }
      }

      /// <summary>
      /// this is the reference to the currently logged customer
      /// </summary>
      private Guid _CustomerId;
      [DataMember]
      public Guid CustomerId
      {
         get { return _CustomerId; }
         set { innerSet<Guid>(ref _CustomerId, value, "CustomerId"); }
      }

      private string _Name;
      [DataMember]
      public string Name
      {
         get { return _Name; }
         set
         {
            innerSet<string>(ref _Name, value, "Name");
            RaisePropertyChanged("FullName");
         }
      }

      private string _Surname;
      [DataMember]
      public string Surname
      {
         get { return _Surname; }
         set
         {
            innerSet<string>(ref _Surname, value, "Surname");
            RaisePropertyChanged("FullName");
         }
      }

      private string _Address;
      [DataMember]
      public string Address
      {
         get { return _Address; }
         set { innerSet<string>(ref _Address, value, "Address"); }
      }

      private string _Cap;
      [DataMember]
      public string Cap
      {
         get { return _Cap; }
         set { innerSet<string>(ref _Cap, value, "Cap"); }
      }

      private string _City;
      [DataMember]
      public string City
      {
         get { return _City; }
         set { innerSet<string>(ref _City, value, "City"); }
      }

      private string _Province;
      [DataMember]
      public string Province
      {
         get { return _Province; }
         set { innerSet<string>(ref _Province, value, "Province"); }
      }

      private string _Phone;
      [DataMember]
      public string Phone
      {
         get { return _Phone; }
         set { innerSet<string>(ref _Phone, value, "Phone"); }
      }

      private string _EMail;
      [DataMember]
      public string EMail
      {
         get { return _EMail; }
         set
         {
            innerSet<string>(ref _EMail, value, "EMail");
         }
      }

      public override object DeepClone()
      {
         return this.DeepClone<Client>();
         // return this.MemberwiseClone();
      }

      public string FullName
      {
         get { return Surname + " " + Name; }
      }

      public override bool Equals(object obj)
      {
         //GenericEquals...!!!
         if ((obj == null) || (obj.GetType() != typeof(Client)))
            return false;
         return Id == (obj as Client).Id;
      }

      public override int GetHashCode()
      {
         return this.Id.GetHashCode();
      }
   }
}
