﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Runtime.Serialization;
using Structura.Utils;
using Structura.Infrastructure.ViewModel;

namespace TestApp.Entities
{
   [DataContract, Serializable]
   public class InvoiceItem : EditableEntityBase
   {
      private string _Code;
      [DataMember]
      public string Code
      {
         get { return _Code; }
         set { innerSet<string>(ref _Code, value, "Code"); }
      }

      private string _Name;
      [DataMember]
      public string Name
      {
         get { return _Name; }
         set { innerSet<string>(ref _Name, value, "Name"); }
      }

      private double _Quantity;
      [DataMember]
      public double Quantity
      {
         get { return _Quantity; }
         set { innerSet<double>(ref _Quantity, value, "Quantity"); }
      }

      private double _Price;
      [DataMember]
      public double Price
      {
         get { return _Price; }
         set { innerSet<double>(ref _Price, value, "Price"); }
      }

      public override object DeepClone()
      {
         return this.MemberwiseClone();
      }

      protected override void OnCancelEdit(object backup)
      {
         InvoiceItem b = backup as InvoiceItem;
         Code = b.Code;
         Name = b.Name;
         Quantity = b.Quantity;
         Price = b.Price;
      }
   }
}
