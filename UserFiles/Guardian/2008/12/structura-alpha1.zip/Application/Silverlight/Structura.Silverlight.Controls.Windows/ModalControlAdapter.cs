﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Structura.Silverlight.Controls.Windows
{
	/// <summary>
	/// adapts a framework element and shows it as a modal element in a canvas
	/// </summary>
	public class ModalControlAdapter : UserControl
	{
		/// <summary>
		/// the external canvas that will cover the entire application surface and that will eat any user input
		/// </summary>
		Canvas _LayoutCanvas;
		/// <summary>
		/// the control to display as modal
		/// </summary>
		Control _HostedControl;
	
		public Control ChildControl { get { return _HostedControl; } }

		public ModalControlAdapter(Control ctrl)
		{
			_HostedControl = ctrl;

			_LayoutCanvas = new Canvas();
			_LayoutCanvas.Background = new SolidColorBrush(Color.FromArgb(30, 0, 0, 0));
			
			_LayoutCanvas.Children.Add(_HostedControl);

			Content = _LayoutCanvas;

			Application.Current.Host.Content.Resized += new EventHandler(Content_Resized);

			Loaded += new RoutedEventHandler(ModalControlAdapter_Loaded);

			_HostedControl.LayoutUpdated += new EventHandler(_HostedControl_LayoutUpdated);
		}

		void ModalControlAdapter_Loaded(object sender, RoutedEventArgs e)
		{
			_HostedControl.Focus();
			_HostedControl.TabNavigation = KeyboardNavigationMode.Cycle;

			Content_Resized(null, EventArgs.Empty);
			// CentreWindow();
		}

		void Content_Resized(object sender, EventArgs e)
		{
			_LayoutCanvas.Width = Application.Current.Host.Content.ActualWidth;
			_LayoutCanvas.Height = Application.Current.Host.Content.ActualHeight;
			// CentreWindow();
		}

		void _HostedControl_LayoutUpdated(object sender, EventArgs e)
		{
			// _HostedControl.LayoutUpdated -= _HostedControl_LayoutUpdated;
			CentreWindow();
			Canvas.SetZIndex(this, Canvas.GetZIndex(_HostedControl));
		}

		internal void SuspedHostedControlLayoutUpdated()
		{
			_HostedControl.LayoutUpdated -= _HostedControl_LayoutUpdated;
		}

		public void Close()
		{
			Application.Current.Host.Content.Resized -= Content_Resized;
			Loaded -= ModalControlAdapter_Loaded;
			_LayoutCanvas.Children.Clear();
		}

		private void CentreWindow()
		{
			double width = !double.IsNaN(_HostedControl.Width) ? _HostedControl.Width : _HostedControl.ActualWidth;

			if (_HostedControl != null && !double.IsNaN(width) && !double.IsNaN(_LayoutCanvas.Width))
				_HostedControl.SetValue(Canvas.LeftProperty, Math.Max((_LayoutCanvas.Width - width) / 2, 0));

			double height = !double.IsNaN(_HostedControl.Height) ? _HostedControl.Height : _HostedControl.ActualHeight;
			
			if (_HostedControl != null && !double.IsNaN(height) && !double.IsNaN(_LayoutCanvas.Height))
				_HostedControl.SetValue(Canvas.TopProperty, Math.Max((_LayoutCanvas.Height - height) / 2, 0));
		}
	}
}
