﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Structura.Silverlight.Controls.Windows
{
	public interface IWindowsManager
	{
		IWindow Show(UserControl content, string caption, Point location);

		IWindow Show(UserControl content, string caption);

		void Show(IWindow w, Point location);

		void Show(IWindow w);
				
		void ShowDialog(IWindow w);

		/// <summary>
		/// shows a 'modal' input box
		/// </summary>
		/// <param name="message">the message to display</param>
		/// <param name="caption">the caption (can be null)</param>
		/// <param name="width">width (can be null)</param>
		/// <param name="onCloseCallback">callback to execute when the windows closes</param>
		/// <returns>instance of the window</returns>
		IWindow InputBox(string message, string caption, int? width, EventHandler onCloseCallback);
	}
}
