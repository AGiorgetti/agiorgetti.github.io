﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Threading;
using System.Collections.Generic;

namespace Structura.Silverlight.Controls.Windows
{
	/// <summary>
	/// Class that handles the creation and destruction of dynamic windows
	/// </summary>
	public class WindowsManager : IWindowsManager
	{
		private Canvas _canvas = null;

		/// <summary>
		/// creates the manager and stores the canvas to which attach the windows
		/// </summary>
		/// <param name="surface"></param>
		public WindowsManager(Canvas surface)
		{
			_canvas = surface;
		}

		public IWindow Show(UserControl content, string caption, Point location)
		{
			Window w = new Window(content);
			w.Caption = caption;
			w.Show(_canvas, location);
			return w;
		}

		public IWindow Show(UserControl content, string caption)
		{
			Window w = new Window(content);
			w.Caption = caption;
			w.Show(_canvas);
			return w;
		}

		/// <summary>
		/// show a window attaching it to the canvas
		/// </summary>
		/// <param name="w"></param>
		/// <param name="location"></param>
		public void Show(IWindow w, Point location)
		{
			Window wtmp = w as Window;
			w.Show(_canvas, location);
		}

		public void Show(IWindow w)
		{
			Window wtmp = w as Window;
			w.Show(_canvas);
		}

		public void ShowDialog(IWindow w)
		{
			Window wtmp = w as Window;
			w.ShowDialog(_canvas);
		}

		public IWindow InputBox(string message, string caption, int? width, EventHandler onCloseCallback)
		{
			InputBox ib = new InputBox();
			ib.Caption = message;
			ib.Label = caption ?? "Input";
			ib.Width = width ?? 300;
			if (onCloseCallback != null)
				ib.Closed += onCloseCallback;
			ShowDialog(ib);
			return ib;
		}
	}
}
