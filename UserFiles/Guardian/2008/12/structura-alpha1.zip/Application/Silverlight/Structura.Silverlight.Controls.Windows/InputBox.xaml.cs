﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Structura.Silverlight.Controls.Windows
{
	public partial class InputBox : Window
	{
		public InputBox() :
			base()
		{
			InitializeComponent();
			this.Loaded += new RoutedEventHandler(InputBox_Loaded);
		}

		void InputBox_Loaded(object sender, RoutedEventArgs e)
		{
			TextControl.Focus();
		}

		public override void Show(Canvas surface, Point location)
		{
			ShowDialog(surface);
		}

		public override void Show(Canvas surface)
		{
			ShowDialog(surface);
		}

		public override void ShowDialog(Canvas surface)
		{
			base.ShowDialog(surface);
		}

		/// <summary>
		/// the string resulting from the user input
		/// </summary>
		public string Result { get { return this.TextControl.Text; } }

		/// <summary>
		/// label of the inputbox
		/// </summary>
		public string Label
		{
			get { return this.LabelControl.Text; }
			set { this.LabelControl.Text = value; }
		}

		private void Ok_Click(object sender, RoutedEventArgs e)
		{
			DialogResult = true;
			Close();
		}

		private void Cancel_Click(object sender, RoutedEventArgs e)
		{
			DialogResult = false;
			Close();
		}
	}
}
