﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Structura.Silverlight.Controls.Menu.DropDownMenu
{
	public class MainMenuItem : MenuItem
	{
		internal MainMenuItem() :
			base()
		{
			this.DefaultStyleKey = typeof(MainMenuItem);
			MenuDirection = Direction.Bottom;
		}

		internal MainMenuItem(string text) :
			this()
		{
			Text = text;
		}

		protected override void OverrideDefaultStyle()
		{
			ParentMenu.SetMainMenuItemStyle(this);
		}

		public override MenuBar ParentMenu
		{
			get;
			set;
		}

		protected override void RaiseMenuItemClick()
		{
			//do nothing here
			//base.RaiseMenuItemClick();
		}

	}
}
