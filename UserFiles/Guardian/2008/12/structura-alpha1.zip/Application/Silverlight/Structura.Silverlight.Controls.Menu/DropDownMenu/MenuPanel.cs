﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace Structura.Silverlight.Controls.Menu.DropDownMenu
{
	[TemplatePart(Name = MenuPanel.InnerPanelElement, Type = typeof(Panel))]
	public class MenuPanel : ContentControl
	{
		public MenuPanel()
		{
			this.DefaultStyleKey = typeof(MenuPanel);
		}

		private const string InnerPanelElement = "InnerPanel";

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			innerPanel = GetTemplateChild(InnerPanelElement) as Panel;

			foreach (var e in _Children)
				innerPanel.Children.Add(e);
		}

		Panel innerPanel;

		public IList<UIElement> Children
		{
			get
			{
				if (innerPanel != null)
					return innerPanel.Children;
				return _Children;
			}
		}
		private List<UIElement> _Children = new List<UIElement>();

	}
}
