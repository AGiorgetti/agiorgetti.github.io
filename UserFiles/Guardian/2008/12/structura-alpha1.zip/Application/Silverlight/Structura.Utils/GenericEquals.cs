﻿using System;
using System.Reflection;

namespace Structura.Utils
{
	/// <summary>
	/// BEWARE REFLECTION ON PROTECTED AND PRIVATE MEMBERS IN SILVERLIGHT WILL NOT WORK, IT WILL WORK ONLY ON PUBLIC MEMBERS
	/// </summary>
	public sealed class Equality
	{
		private Equality()
		{ }

		/// <summary>
		/// confronta l'istanza, il tipo dei due oggetti e la proprietà specificata,
		/// se le condzioni sono soddisfatte le istanze si ritengono uguali
		/// </summary>
		/// <param name="obj1"></param>
		/// <param name="obj2"></param>
		/// <param name="propName"></param>
		/// <returns></returns>
		public static bool GenericEquals(object value1, object value2, string propName)
		{
			return GenericEquals(value1, value2, propName, false);
		}

		/// confronta l'istanza, il tipo dei due oggetti e la proprietà specificata,
		/// se le condzioni sono soddisfatte le istanze si ritengono uguali
		/// </summary>
		/// <param name="obj1"></param>
		/// <param name="obj2"></param>
		/// <param name="propName"></param>
		/// <returns></returns>
		public static bool GenericEquals(object value1, object value2, string propName, bool includeNonPublicMembers)
		{
			if (value1 == value2)
				return true;
			if (value1.GetType() != value2.GetType())
				return false;
			System.Reflection.BindingFlags flags = BindingFlags.Default | BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly;
			if (includeNonPublicMembers)
				flags = flags | BindingFlags.NonPublic;
			PropertyInfo pi = value1.GetType().GetProperty(propName, flags);
			object val1 = pi.GetValue(value1, null);
			object val2 = pi.GetValue(value2, null);
			if (val1.Equals(val2))
				return true;
			return false;
		}

		/// <summary>
		/// confronta membro a membero tutti i campi di classe (pubblici, protetti e privati)
		/// </summary>
		/// <param name="obj1"></param>
		/// <param name="obj2"></param>
		/// <returns></returns>
		public static bool GenericEquals(object value1, object value2)
		{
			return GenericEquals(value1, value2, false);
		}

		/// <summary>
		/// confronta membero a membro 
		/// </summary>
		/// <param name="obj1"></param>
		/// <param name="obj2"></param>
		/// <returns></returns>
		public static bool GenericEquals(object value1, object value2, bool includeNonPublicMembers)
		{
			if (value1 == value2)
				return true;

			if ((value1 == null) || (value2 == null))
				return false;

			if (value1.GetType().Equals(value2.GetType()) == false)
				return false;

			/*
			if ((obj1 == null) && (obj2 == null))
				return true;

			if (((obj1 == null) && (obj2 != null)) || ((obj1 != null) && (obj2 == null)))
				return false;

			if (obj1.GetType().Equals(obj2.GetType()) == false)
				return false;

			if (obj1 == obj2)
				return true;
			*/

			//parto dal tipo più esterno fino ad ottenere FALSE oppure System.Object
			Type t = value1.GetType();
			bool res = false;

			while (t != typeof(object))
			{
				res = CheckProperties(value1, value2, t, includeNonPublicMembers);
				if (res == false) return false;
				res = CheckFields(value1, value2, t, includeNonPublicMembers);
				if (res == false) return false;
				t = t.BaseType;
			}

			return res;

			//		  Type ty = obj1.GetType();
			//		  FieldInfo[] fi = ty.GetFields(BindingFlags.Default | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public );
			//		  for (Int32 I = 0; I < fi.Length; ++I)
			//		  {
			//			  object value1 = fi[I].GetValue(obj1);
			//			  object value2 = fi[I].GetValue(obj2);
			//			  // verifico se si tratta di una list
			//			  if (fi[I].FieldType != typeof(System.Collections.IList))
			//			  {
			//
			//				  //I campi fissi nel database tipo char(11) purtroppo debbono essere gestiti in quseto modo
			//				  //perchè automaticamenten vengono paddati con spazi.
			//				  if (fi[I].FieldType == typeof(string))
			//				  {
			//					  if (!(value1 == null || value2 == null))
			//					  {
			//						  value1 = ((string)value1).TrimEnd();
			//						  value2 = ((string)value2).TrimEnd();
			//					  }
			//				  }
			//				  if (!object.Equals(value1, value2))
			//				  {
			//					  Console.Error.WriteLine("{0} is different expected {1} but was {2}",
			//						  fi[I].Name, value1, value2);
			//					  return false;
			//				  }
			//			  }
			//			  else
			//			  {
			//				  System.Collections.IList l1 = (System.Collections.IList)value1;
			//				  System.Collections.IList l2 = (System.Collections.IList)value2;
			//				  if (l1.Count != l2.Count)
			//					  return false;
			//				  //non posso verificare i singoli elementi perchè nessuno mi garantisce sull'ordine
			//				  //degli stessi
			//				  //          for (int i = 0; i < l1.Count; i++)
			//				  //          {
			//				  //            if (false == GenericEquals(l1[i], l2[i]))
			//				  //              return false;
			//				  //          }
			//			  }
			//		  }
			//		  return true;
		}

		private static bool CheckFields(object o1, object o2, Type t, bool includeNonPublicMembers)
		{
			System.Reflection.BindingFlags flags = BindingFlags.Default | BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly;
			if (includeNonPublicMembers)
				flags = flags | BindingFlags.NonPublic;
			FieldInfo[] fi = t.GetFields(flags);
			for (Int32 I = 0; I < fi.Length; ++I)
			{
				object value1 = fi[I].GetValue(o1);
				object value2 = fi[I].GetValue(o2);
				if (value1 == value2)
					continue;
				if ((value1 == null) || (value2 == null))
					return false;

				// verifico se si tratta di una list
				if ((fi[I].FieldType == typeof(System.Collections.IList))
					|| (typeof(System.Collections.IList).IsAssignableFrom(fi[I].FieldType)))
				{
					System.Collections.IList l1 = (System.Collections.IList)value1;
					System.Collections.IList l2 = (System.Collections.IList)value2;
					if (l1.Count != l2.Count)
						return false;

					//non posso verificare i singoli elementi perchè nessuno mi garantisce sull'ordine
					//degli stessi
					//          for (int i = 0; i < l1.Count; i++)
					//          {
					//            if (false == GenericEquals(l1[i], l2[i]))
					//              return false;
					//          }
				}
				else if ((fi[I].FieldType == typeof(System.Array)) ||
					fi[I].FieldType.IsSubclassOf(typeof(System.Array)))
				{
					System.Array l1 = (System.Array)value1;
					System.Array l2 = (System.Array)value2;
					if (l1.Length != l2.Length)
						return false;

					//non posso verificare i singoli elementi perchè nessuno mi garantisce sull'ordine
					//degli stessi
					//          for (int i = 0; i < l1.Count; i++)
					//          {
					//            if (false == GenericEquals(l1[i], l2[i]))
					//              return false;
					//          }
				}
				else
				{
					//I campi fissi nel database tipo char(11) purtroppo debbono essere gestiti in quseto modo
					//perchè automaticamenten vengono paddati con spazi.
					if (fi[I].FieldType == typeof(string))
					{
						if (!(value1 == null || value2 == null))
						{
							//value1 = ((string)value1).TrimEnd();
							//value2 = ((string)value2).TrimEnd();
							if (!((string)value1).TrimEnd().Equals(((string)value2).TrimEnd()))
								return false;
						}
					}

					/*
					else if (fi[I].FieldType.IsPrimitive)
					{
					*/
					if (!object.Equals(value1, value2))
					{
						Console.Error.WriteLine("{0} is different expected {1} but was {2}",
							fi[I].Name, value1, value2);
						return false;
					}

					/*
					}
					else
						return GenericEquals(value1, value2, includeNonPublicMembers);
					*/
				}
			}

			return true;
		}

		private static bool CheckProperties(object o1, object o2, Type t, bool includeNonPublicMembers)
		{
			System.Reflection.BindingFlags flags = BindingFlags.Default | BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly;
			if (includeNonPublicMembers)
				flags = flags | BindingFlags.NonPublic;
			PropertyInfo[] fi = t.GetProperties(flags);
			for (Int32 I = 0; I < fi.Length; ++I)
			{
				if (fi[I].CanRead == false)
					continue;
				object value1 = fi[I].GetValue(o1, null);
				object value2 = fi[I].GetValue(o2, null);

				//if ((value1 == null) && (value2 == null))
				//	return true;
				if (value1 == value2)
					continue;
				if ((value1 == null) || (value2 == null))
					return false;

				// verifico se si tratta di una list
				//				if ((fi[I].PropertyType == typeof(System.Collections.IList))
				//					|| (fi[I].PropertyType.IsAssignableFrom(typeof(System.Collections.IList))))
				if ((fi[I].PropertyType == typeof(System.Collections.IList))
					|| (typeof(System.Collections.IList).IsAssignableFrom(fi[I].PropertyType)))
				{
					System.Collections.IList l1 = (System.Collections.IList)value1;
					System.Collections.IList l2 = (System.Collections.IList)value2;
					if (l1.Count != l2.Count)
						return false;
				}
				else if ((fi[I].PropertyType == typeof(System.Array)) ||
					fi[I].PropertyType.IsSubclassOf(typeof(System.Array)))
				{
					System.Array l1 = (System.Array)value1;
					System.Array l2 = (System.Array)value2;
					if (l1.Length != l2.Length)
						return false;
				}
				else
				{
					//I campi fissi nel database tipo char(11) purtroppo debbono essere gestiti in quseto modo
					//perchè automaticamenten vengono paddati con spazi.
					if (fi[I].PropertyType == typeof(string))
					{
						if (!(value1 == null || value2 == null))
						{
							//value1 = ((string)value1).TrimEnd();
							//value2 = ((string)value2).TrimEnd();
							if (!((string)value1).TrimEnd().Equals(((string)value2).TrimEnd()))
								return false;
						}
					}
					/*
					else if (fi[I].PropertyType.IsPrimitive)
					{
					*/
					if (!object.Equals(value1, value2))
					{
						Console.Error.WriteLine("{0} is different expected {1} but was {2}",
							fi[I].Name, value1, value2);
						return false;
					}
					/*
					}
					else
						return GenericEquals(value1, value2, includeNonPublicMembers);
					*/
				}
			}
			return true;
		}
	}
}
