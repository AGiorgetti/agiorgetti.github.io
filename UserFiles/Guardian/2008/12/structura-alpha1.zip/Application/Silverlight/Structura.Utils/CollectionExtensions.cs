﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Runtime.Serialization;

namespace Structura.Utils
{
	/// <summary>
	/// extension methods for collections
	/// </summary>
	public static class CollectionExtensions
	{
		/// <summary>
		/// converts the collection to an observable collection
		/// </summary>
		/// <typeparam name="T">Type of elements holded by the collection</typeparam>
		/// <param name="coll">Collection to extend</param>
		/// <returns>a new observable collection</returns>
		public static ObservableCollection<T> ToObservableCollection<T>(this IEnumerable<T> coll)
		{
			var c = new ObservableCollection<T>();
			foreach (var e in coll)
				c.Add(e);
			return c;
		}

		/// <summary>
		///  converts the IList to a plain array
		/// </summary>
		/// <typeparam name="T">Type of elements holded by the collection</typeparam>
		/// <param name="coll">IList to extend</param>
		/// <returns>a new plain array of the specified type</returns>
		public static T[] ToPlainArray<T>(this IList<T> coll)
		{
			T[] arr = null;
			if (coll.Count > 0)
			{
				arr = new T[coll.Count];
				for (int i = 0; i < coll.Count; i++)
					arr[i] = coll[i];
			}

			return arr;
		}
	}

   [Serializable]
   [CollectionDataContract(IsReference = true)]
	public class NotifyCollectionWrapper<T> : IList<T>, IList, INotifyCollectionChanged
	{
		public NotifyCollectionWrapper()
		{
		}

		public NotifyCollectionWrapper(IList<T> innerlist)
		{
			Reset(innerlist);
		}

		public NotifyCollectionWrapper<T> Reset(IList<T> innerlist)
		{
			_InnerList = innerlist;
			return this;
		}

      [NonSerialized]
		private IList<T> _InnerList;

		#region INotifyCollectionChanged Members

      [field: NonSerialized]
      public virtual event System.Collections.Specialized.NotifyCollectionChangedEventHandler CollectionChanged;

		/// <summary>
		/// Fires the <see cref="CollectionChanged"/> event to indicate an item has been
		/// added to the end of the collection.
		/// </summary>
		/// <param name="item">Item added to the collection.</param>
		protected void OnItemAdded(T item)
		{
			if (this.CollectionChanged != null)
			{
				this.CollectionChanged(this, new NotifyCollectionChangedEventArgs(
															NotifyCollectionChangedAction.Add, item, this.Count - 1));
			}
		}

		/// <summary>
		/// Fires the <see cref="CollectionChanged"/> event to indicate the collection
		/// has been reset.  This is used when the collection has been cleared or
		/// entirely replaced.
		/// </summary>
		protected void OnCollectionReset()
		{
			if (this.CollectionChanged != null)
			{
				this.CollectionChanged(this, new NotifyCollectionChangedEventArgs(
															NotifyCollectionChangedAction.Reset));
			}
		}

		/// <summary>
		/// Fires the <see cref="CollectionChanged"/> event to indicate an item has
		/// been inserted into the collection at the specified index.
		/// </summary>
		/// <param name="index">Index the item has been inserted at.</param>
		/// <param name="item">Item inserted into the collection.</param>
		protected void OnItemInserted(int index, T item)
		{
			if (this.CollectionChanged != null)
			{
				this.CollectionChanged(this, new NotifyCollectionChangedEventArgs(
															NotifyCollectionChangedAction.Add, item, index));
			}
		}

		/// <summary>
		/// Fires the <see cref="CollectionChanged"/> event to indicate an item has
		/// been replaced into the collection at the specified index.
		/// </summary>
		/// <param name="index">Index the item has been inserted at.</param>
		/// <param name="item">Item inserted into the collection.</param>
		protected void OnItemReplaced(T newItem, T oldItem, int index)
		{
			if (this.CollectionChanged != null)
			{
				this.CollectionChanged(this, new NotifyCollectionChangedEventArgs(
															NotifyCollectionChangedAction.Replace, newItem, oldItem, index));
			}
		}

		/// <summary>
		/// Fires the <see cref="CollectionChanged"/> event to indicate an item has
		/// been removed from the collection at the specified index.
		/// </summary>
		/// <param name="item">Item removed from the collection.</param>
		/// <param name="index">Index the item has been removed from.</param>
		protected void OnItemRemoved(T item, int index)
		{
			if (this.CollectionChanged != null)
			{
				this.CollectionChanged(this, new NotifyCollectionChangedEventArgs(
															NotifyCollectionChangedAction.Remove, item, index));
			}
		}

		#endregion

		#region IList<T> Members

		public int IndexOf(T item)
		{
			return _InnerList.IndexOf(item);
		}

		public void Insert(int index, T item)
		{
			_InnerList.Insert(index, item);
			OnItemInserted(index, item);
		}

		public T this[int index]
		{
			get
			{
				return _InnerList[index];
			}

			set
			{
				T old = _InnerList[index];
				_InnerList[index] = value;
				OnItemReplaced(value, old, index);
			}
		}

		public void RemoveAt(int index)
		{
			T item = _InnerList[index];
			_InnerList.RemoveAt(index);
			OnItemRemoved(item, index);
		}

		#endregion

		#region ICollection<T> Members

		public void Add(T item)
		{
			_InnerList.Add(item);
			OnItemAdded(item);
		}

		public bool Contains(T item)
		{
			return _InnerList.Contains(item);
		}

		public void CopyTo(T[] array, int arrayIndex)
		{
			_InnerList.CopyTo(array, arrayIndex);
		}

		public bool Remove(T item)
		{
			int index = _InnerList.IndexOf(item);
			bool result = _InnerList.Remove(item);
			OnItemRemoved(item, index);
			return result;
		}

		public void Clear()
		{
			_InnerList.Clear();
			OnCollectionReset();
		}

		public int Count
		{
			get
			{
				if (_InnerList != null)
					return _InnerList.Count;
				return 0;
			}
		}

		public bool IsReadOnly
		{
			get { return _InnerList.IsReadOnly; }
		}

		#endregion

		#region IEnumerable<T> Members

		IEnumerator<T> IEnumerable<T>.GetEnumerator()
		{
			if (_InnerList != null)
				return _InnerList.GetEnumerator();
			return null;
		}

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		protected IEnumerator GetEnumerator()
		{
			if (_InnerList != null)
				return _InnerList.GetEnumerator();
			return null;
		}

		#endregion

		#region IList Members

		public int Add(object value)
		{
			_InnerList.Add((T)value);
			OnItemAdded((T)value);
			return -1;
		}

		public bool Contains(object value)
		{
			return _InnerList.Contains((T)value);
		}

		public int IndexOf(object value)
		{
			return _InnerList.IndexOf((T)value);
		}

		public void Insert(int index, object value)
		{
			_InnerList.Insert(index, (T)value);
			OnItemInserted(index, (T)value);
		}

		public bool IsFixedSize
		{
			get { return false; }
		}

		public void Remove(object value)
		{
			int index = _InnerList.IndexOf((T)value);
			bool result = _InnerList.Remove((T)value);
			OnItemRemoved((T)value, index);
		}

		object IList.this[int index]
		{
			get
			{
				return _InnerList[index];
			}
			set
			{
				T old = _InnerList[index];
				_InnerList[index] = (T)value;
				OnItemReplaced((T)value, old, index);
			}
		}

		#endregion

		#region ICollection Members

		public void CopyTo(Array array, int index)
		{
			throw new NotImplementedException();
		}

		public bool IsSynchronized
		{
			get { return false; }
		}

		public object SyncRoot
		{
			get { return this; }
		}

		#endregion
	}

	public interface IObservableCollection<T> : IList<T>, ICollection<T>, IEnumerable<T>, INotifyCollectionChanged, IList, ICollection, IEnumerable
	{
	}

	// [Serializable]
	[CollectionDataContract]
	[KnownType("GetKnownTypes")]
	public class MyObservableCollection<T> : ObservableCollection<T>, IObservableCollection<T>
	{
		static Type[] GetKnownTypes()
		{
			return new Type[] { typeof(MyObservableCollection<T>) };
		}
	}
}
