﻿using System;
using System.IO;
using System.Runtime.Serialization;

namespace Structura.Utils
{
	/// <summary>
	/// fake class to allow .NET multi targetting classes to use the serializabe attribute
	/// </summary>
	[AttributeUsage(AttributeTargets.Class)]
	public sealed class Serializable : Attribute
	{

	}

   /// <summary>
   /// fake class to allow .NET multi targetting classes to use the serializabe attribute
   /// </summary>
   public sealed class NonSerialized : Attribute
   {

   }

	public static partial class Helpers
	{
		public static T DeepClone<T>(this T obj)
		{
			T cloned = default(T);
			var serializer = new DataContractSerializer(typeof(T));
			using (var ms = new MemoryStream())
			{
				serializer.WriteObject(ms, obj);
				ms.Position = 0;
				cloned = (T)serializer.ReadObject(ms);
			}
			return cloned;
		}
	}
}
