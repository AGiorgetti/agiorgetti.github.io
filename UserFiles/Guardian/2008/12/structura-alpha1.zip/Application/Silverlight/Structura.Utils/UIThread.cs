﻿using System;
using System.Windows.Threading;

namespace Structura.Utils
{
	public static class UIThread
	{
		public static Dispatcher Dispatcher { get; set; }
		public static void Run(Action a)
		{
			Dispatcher.BeginInvoke(a);
		}
	}
}
