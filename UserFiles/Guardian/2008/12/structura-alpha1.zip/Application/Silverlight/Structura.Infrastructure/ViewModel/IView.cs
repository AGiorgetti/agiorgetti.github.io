﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Structura.Infrastructure.ViewModel
{
	/// <summary>
	/// the view must implement this interface
	/// </summary>
	public interface IView
	{
		/// <summary>
		/// used to close the current view
		/// </summary>
		void Close();

		/// <summary>
		/// used to refresh the interface in some way
		/// </summary>
		void UpdateInterface();
	}
}
