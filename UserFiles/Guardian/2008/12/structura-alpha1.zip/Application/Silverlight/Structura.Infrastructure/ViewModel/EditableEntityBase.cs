﻿using System.ComponentModel;
using System.Runtime.Serialization;
using Structura.Utils;
using System;

namespace Structura.Infrastructure.ViewModel
{
   [DataContract(IsReference = true)]
	[Serializable]
	public abstract class EditableEntityBase : EntityBase, IEditableObject
	{
		#region IEditableObject Members

      [NonSerialized]
		bool _editing;
      [NonSerialized]
		protected object Backup;

		public void BeginEdit()
		{
			if (!_editing)
			{
				_editing = true;
				Backup = DeepClone();
			}
		}

		public void CancelEdit()
		{
			if (_editing)
			{
				OnCancelEdit(Backup);
				_editing = false;
			}

		}

		public void EndEdit()
		{
			if (_editing)
			{
				_editing = false;
				this.Backup = null;
			}
		}

		/// <summary>
		/// function called to reassign the value of the object under editing getting them from the backup
		/// </summary>
		/// <param name="backup"></param>
		protected abstract void OnCancelEdit(object backup);

		#endregion
	}
}
