﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Structura.Infrastructure.IOC;

namespace Structura.Infrastructure.ViewModel
{
	public class ViewExt : View
	{
		public ViewExt()
			: base()
		{ }

		public ViewExt(IIoC ioc)
			: base()
		{
			IOC = ioc;
		}

		public ViewExt(IIoC ioc, ControllerExt controller)
			: base()
		{
			IOC = ioc;
			Controller = controller;
		}

		protected IIoC IOC;

      public override object Controller
      {
         get { return base.Controller as ControllerExt; }
         set
         {
            base.Controller = value as ControllerExt;
            ((ControllerExt)value).IOC = IOC;
         }
      }

	}
}
