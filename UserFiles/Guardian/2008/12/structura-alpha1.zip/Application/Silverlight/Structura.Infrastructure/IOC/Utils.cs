﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Reflection;
using System.IO;
using System.Windows.Resources;
using System.Collections.Generic;
using System.Xml.Linq;
using System.Linq;

namespace Structura.Infrastructure.IOC
{
	public class PackageUtil
	{
		/// <summary>
		/// decodes the stream and load the assembly in memory if not already loaded
		/// </summary>
		/// <param name="stream"></param>
		/// <returns></returns>
		public static Assembly LoadAssembly(Stream stream)
		{
			Assembly asm = (new AssemblyPart()).Load(stream);
			return asm;
		}
		/// <summary>
		/// loads all the assemblies in the Xap file and return a reference to the requested one
		/// </summary>
		/// <param name="packageStream"></param>
		/// <param name="assemblyName"></param>
		/// <returns></returns>
		public static Assembly LoadAssemblyFromXap(Stream packageStream, string assemblyName)
		{
			string appManifestString = new StreamReader(Application.GetResourceStream(
				new StreamResourceInfo(packageStream, null),
				new Uri("AppManifest.xaml", UriKind.Relative)).Stream)
			.ReadToEnd();

			IEnumerable<AssemblyPart> list = ParseAssemblyManifest(appManifestString);

			Assembly asm = null;
			foreach (AssemblyPart assemblyPart in list)
			{
				string source = assemblyPart.Source;
				StreamResourceInfo streamInfo = Application.GetResourceStream(
					new StreamResourceInfo(packageStream, "application/binary"),
					new Uri(source, UriKind.Relative));
				if (source == assemblyName)
				{
					asm = assemblyPart.Load(streamInfo.Stream);
				}
				else
				{
					assemblyPart.Load(streamInfo.Stream);
				}
			}
			return asm;
		}

		/// <summary>
		/// load an assembly intop the runtime if it's not present in the already loaded list provided
		/// </summary>
		/// <param name="packageStream">stream che rappresenta lo XAP</param>
		/// <param name="loadedAssemblies">Dictionary of already loaded assemblies (the key is the plain assembly name, without the extension),
		/// this list will be updated with the newly loaded assemblies; you can pass null to ignore this list and always
		/// load all the assemblies</param>
		/// <returns></returns>
		public static void LoadAssembliesFromXap(Stream packageStream, Dictionary<string, Assembly> loadedAssemblies)
		{
			string appManifestString = new StreamReader(Application.GetResourceStream(
				new StreamResourceInfo(packageStream, null),
				new Uri("AppManifest.xaml", UriKind.Relative)).Stream)
			.ReadToEnd();
			Assembly asm = null;

			IEnumerable<AssemblyPart> list = ParseAssemblyManifest(appManifestString);

			foreach (var assemblyPart in list)
			{
				//check if it's already loaded
				string source = assemblyPart.Source;
				string key = source.EndsWith(".dll", StringComparison.InvariantCultureIgnoreCase) ? source.Substring(0, source.Length - 4) : source;
				if (loadedAssemblies != null)
					lock (loadedAssemblies)
					{
						if (loadedAssemblies.ContainsKey(key))
						{
							asm = loadedAssemblies[key];
						}
						else
						{
							asm = LoadAssembly(packageStream, assemblyPart);
							loadedAssemblies.Add(Utils.ExtractAssemblyNameFromAssemblyFullName(asm.FullName), asm);
						}
					}
				else
				{
					asm = LoadAssembly(packageStream, assemblyPart);
				}
				//yield return asm;
			}
		}

		private static IEnumerable<AssemblyPart> ParseAssemblyManifest(string appManifestString)
		{
			//parse the Modules info file
			XDocument doc = XDocument.Parse(appManifestString);
			XNamespace ns = doc.Root.Attribute("xmlns").Value;
			//parse the data with linq
			IEnumerable<AssemblyPart> list = from mod in doc.Root.Element(ns + "Deployment.Parts").Descendants(ns + "AssemblyPart")
														select new AssemblyPart()
														{
															Source = mod.Attribute("Source").Value
														};
			return list;
		}

		private static Assembly LoadAssembly(Stream packageStream, AssemblyPart assemblyPart)
		{
			StreamResourceInfo streamInfo = Application.GetResourceStream(
								  new StreamResourceInfo(packageStream, "application/binary"),
								  new Uri(assemblyPart.Source, UriKind.Relative));
			return assemblyPart.Load(streamInfo.Stream);
		}

		public static IEnumerable<Assembly> GetCurrentlyLoadedAssemblies()
		{
			System.Reflection.Assembly asm;
			foreach (AssemblyPart ap in Deployment.Current.Parts)
			{
				System.Windows.Resources.StreamResourceInfo sri = Application.GetResourceStream(new Uri(ap.Source, UriKind.Relative));
				asm = new AssemblyPart().Load(sri.Stream);
				yield return asm;
			}
		}
	}

	//abstracts the WebClient
	public class SLPackage
	{
		private Uri _packageUri;
		private Type _fromType;
		private string _toType;
		private string _name;
		private ResolveCompletedCallback _resolveCallback;

		public class PackageEventArgs : EventArgs
		{
			private Stream _packageStream;
			private string _packageUri;
			private Type _fromType;
			private string _toType;
			private string _name;
			private ResolveCompletedCallback _resolveCallback;
			public PackageEventArgs(Stream packageStream, string packageUri)
			{
				this._packageStream = packageStream;
				this._packageUri = packageUri;
			}
			public PackageEventArgs(Stream packageStream, string packageUri, Type fromtype, string toType, string name) :
				this(packageStream, packageUri)
			{
				this._fromType = fromtype;
				this._toType = toType;
				this._name = name;
			}
			public PackageEventArgs(Stream packageStream, string packageUri, Type fromtype, string toType, string name, ResolveCompletedCallback callback) :
				this(packageStream, packageUri, fromtype, toType, name)
			{
				this._resolveCallback = callback;
			}
			public Stream PackageStream { get { return _packageStream; } }
			public String PackageUri { get { return _packageUri; } }
			public Type FromType { get { return _fromType; } }
			public string ToType { get { return _toType; } }
			public string Name { get { return _name; } }
			public ResolveCompletedCallback ResolveCallback { get { return _resolveCallback; } }
		}

		public event EventHandler<PackageEventArgs> PackageDownloaded;

		public SLPackage(Uri uri)
		{
			_packageUri = uri;
		}

		public void LoadPackage()
		{
			WebClient webClient = new WebClient();
			webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(webClient_OpenReadCompleted);
			webClient.OpenReadAsync(_packageUri);
		}

		private void webClient_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
		{
			PackageEventArgs pe = null;
			try
			{
				pe = new PackageEventArgs(e.Result, this._packageUri.OriginalString);
			}
			catch
			{
				PackageDownloaded(this, null);
				return;
			}
			PackageDownloaded(this, pe);
		}

		public void LoadPackage(Type fromType, string toType, string name, ResolveCompletedCallback callback)
		{
			_fromType = fromType;
			_toType = toType;
			_name = name;
			_resolveCallback = callback;
			WebClient webClient = new WebClient();
			webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(webClient_OpenReadCompleted2);
			webClient.OpenReadAsync(_packageUri);
		}

		private void webClient_OpenReadCompleted2(object sender, OpenReadCompletedEventArgs e)
		{
			PackageEventArgs pe = null;
			try
			{
				pe = new PackageEventArgs(e.Result, this._packageUri.OriginalString, _fromType, _toType, _name, _resolveCallback);
			}
			catch
			{
				PackageDownloaded(this, null);
				return;
			}
			PackageDownloaded(this, pe);
		}

	}

	public class Utils
	{
		public static string ExtractAssemblyNameFromTypeFullName(string fullyqualifiedname)
		{
			return fullyqualifiedname.Split(',')[1].Trim();
		}

		public static string ExtractAssemblyNameFromAssemblyFullName(string fullyqualifiedname)
		{
			return fullyqualifiedname.Split(',')[0].Trim();
		}
	}
}
