﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace Structura.Infrastructure.IOC
{
	/// <summary>
	/// interface for the module that is able to retrieve the configuration for
	/// the IoC system, the file will map each external types provided to the application.
	/// The ApplicationInitializer knows how to parse the xml data returned to it.
	/// </summary>
	public interface IApplicationConfigurationProvider
	{
		/// <summary>
		/// returns the xml formatted data
		/// </summary>
		/// <returns></returns>
		List<TypeSetting> GetConfiguration();
	}

	/// <summary>
	/// configuration data, if the Uri is not present this must be handled like a normal type
	/// (not like an external one, so the application does not have to download any data to create it)
	/// </summary>
	public class TypeSetting
	{
		public string FromType { get { return _fromType; } }
		private string _fromType;
		public string ToType { get { return _toType; } }
		private string _toType;
		public string Name { get { return _name; } }
		private string _name;
		public Uri Uri { get { return _uri; } }
		private Uri _uri;

		public TypeSetting(string fromType, string toType, string name, Uri uri)
		{
			_fromType = fromType;
			_toType = toType;
			_name = name;
			_uri = uri;
		}
	}
}
