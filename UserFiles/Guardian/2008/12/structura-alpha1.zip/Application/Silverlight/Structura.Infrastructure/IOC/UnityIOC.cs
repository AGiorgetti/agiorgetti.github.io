﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.SLUnity;
using System.Reflection;
using System.Collections.Generic;
using Microsoft.Practices.Composite.UnityExtensions;

namespace Structura.Infrastructure.IOC
{
	/// <summary>
	/// Actual implementation of the class that shields the IoC container and adds functionalities
	/// for downloading XAP and DLL files for a deferred type registration just before the type resolution
	/// </summary>
	public class UnityIoC : IIoC
	{
		/// <summary>
		/// for this first implementation we use Unity as our IoC system
		/// </summary>
		private readonly IUnityContainer _unityContainer;

		/// <summary>
		/// Initializes a new instance of <see cref="UnityIoC"/>.
		/// </summary>
		/// <param name="unityContainer">The <seealso cref="IUnityContainer"/> that will be used
		/// by the <see cref="Resolve"/> and <see cref="TryResolve"/> methods.</param>
		public UnityIoC(IUnityContainer unityContainer)
		{
			_unityContainer = unityContainer;

			foreach (Assembly asm in PackageUtil.GetCurrentlyLoadedAssemblies())
			{
				_LoadedAssemblies.Add(Utils.ExtractAssemblyNameFromAssemblyFullName(asm.FullName), asm);
			}
		}

		///// <summary>
		///// Resolve an instance of the requested type from the container.
		///// </summary>
		///// <param name="type">The type of object to get from the container.</param>
		///// <returns>An instance of <paramref name="type"/>.</returns>
		///// <exception cref="ResolutionFailedException"><paramref name="type"/> cannot be resolved by the container.</exception>
		//public object Resolve(Type type)
		//{
		//   return _unityContainer.Resolve(type);
		//}

		///// <summary>
		///// Tries to resolve an instance of the requested type from the container.
		///// </summary>
		///// <param name="type">The type of object to get from the container.</param>
		///// <returns>
		///// An instance of <paramref name="type"/>. 
		///// If the type cannot be resolved it will return a <see langword="null"/> value.
		///// </returns>
		//public object TryResolve(Type type)
		//{
		//   object resolved;
		//   try
		//   {
		//      resolved = Resolve(type);
		//   }
		//   catch
		//   {
		//      resolved = null;
		//   }
		//   return resolved;
		//}

		#region IIoC Members

		public event EventHandler<ResolveCompletedEventArgs> ResolveCompleted;

		/// <summary>
		/// if the callback is not specified the event handles will be called, otherwise
		/// we will invoke the callback at the end of the object creation
		/// </summary>
		/// <param name="result">Object Resolved</param>
		/// <param name="func">Callback to invoke at the end of the process, if null all the event wired will be called</param>
		private void OnResolveCompleted(object result, ResolveCompletedCallback func)
		{
			if (func != null)
				func(result);
			else
				if (ResolveCompleted != null)
					ResolveCompleted(this, new ResolveCompletedEventArgs(result));
		}

		private void OnResolveCompleted<T>(T result, ResolveCompletedCallback<T> func)
		{
			if (func != null)
				func(result);
			else
				if (ResolveCompleted != null)
					ResolveCompleted(this, new ResolveCompletedEventArgs(result));
		}

		public object Resolve(Type type, string name)
		{
			return _unityContainer.Resolve(type, name);
		}

		public T Resolve<T>(string name)
		{
			return (T)_unityContainer.Resolve(typeof(T), name);
		}

		public void BeginResolve(Type type, string name)
		{
			BeginResolve(type, name, null);
		}

		public void BeginResolve<T>(string name, ResolveCompletedCallback<T> callback)
		{
			T t = default(T);
			try
			{
				t = (T)_unityContainer.Resolve(typeof(T), name);
			}
			catch (Exception e)
			{
				//todo: log the error some way
			}

			if (t == null)
			{
				//try to look for the dll that contains the type, download and load it into the runtime
				IoCTypeKey k = new IoCTypeKey(typeof(T), name);
				if (_ExternalTypes.ContainsKey(k))
				{
					IoCTypeValue v = _ExternalTypes[k];
					//check in the list of already downloaded assemblies
					string uri = v.Uri.ToString();
					//check if the assembly is in a downloading state, if so exit with an exception
					if (_DownloadingAssembliesGuard.Contains(uri))
						throw new ArgumentException(string.Format("Package: {0} is being downloaded by another action", uri));

					//now check if we have already downloaded the assembly requested by the mapping
					string asmn = Utils.ExtractAssemblyNameFromTypeFullName(v.ToType);
					if (_LoadedAssemblies.ContainsKey(asmn))
					{
						T resolvedType = (T)RegisterAndResolveType(typeof(T), v.ToType, name);
						OnResolveCompleted(resolvedType, callback);
					}
					else
					{
						OnDownloadStarted(new DownloadPackageEventArgs());
						SLPackage p = new SLPackage(v.Uri);
						p.PackageDownloaded += (sender, e) =>
						{
							LoadFromStream(e);
							t = (T)RegisterAndResolveType(e.FromType, e.ToType, e.Name);
							_DownloadingAssembliesGuard.Remove(e.PackageUri);
							OnDownloadCompleted(new DownloadPackageEventArgs());
							OnResolveCompleted<T>(t, callback);
						};
						_DownloadingAssembliesGuard.Add(uri);
						p.LoadPackage(typeof(T), v.ToType, name, null);
					}
				}
				else
					throw new TypeNotRegisteredException(string.Format("Trying to create\nname: {0}\nfrom: {1}", name, typeof(T).ToString()));
			}
			else
				OnResolveCompleted(t, callback);
		}

		public void BeginResolve(Type type, string name, ResolveCompletedCallback callback)
		{
			object t = null;
			try
			{
				t = _unityContainer.Resolve(type, name);
			}
			catch (Exception e)
			{
				//todo: log the error some way
			}

			if (t == null)
			{
				//try to look for the dll that contains the type, download and load it into the runtime
				IoCTypeKey k = new IoCTypeKey(type, name);
				if (_ExternalTypes.ContainsKey(k))
				{
					IoCTypeValue v = _ExternalTypes[k];
					//check in the list of already downloaded assemblies
					string uri = v.Uri.ToString();
					//check if the assembly is in a downloading state, if so exit with an exception
					if (_DownloadingAssembliesGuard.Contains(uri))
						throw new ArgumentException(string.Format("Package: {0} is being downloaded by another action", uri));
					//now check if we have already downloaded the assembly requested by the mapping
					string asmn = Utils.ExtractAssemblyNameFromTypeFullName(v.ToType);
					if (_LoadedAssemblies.ContainsKey(asmn))
					{
						object resolvedType = RegisterAndResolveType(type, v.ToType, name);
						OnResolveCompleted(resolvedType, callback);
					}
					else
					{
						OnDownloadStarted(new DownloadPackageEventArgs());
						SLPackage p = new SLPackage(v.Uri);
						p.PackageDownloaded += p_PackageDownloaded;
						_DownloadingAssembliesGuard.Add(uri);
						p.LoadPackage(type, v.ToType, name, callback);
					}
				}
				else
					throw new TypeNotRegisteredException(string.Format("Trying to create\nname: {0}\nfrom: {1}", name, type.ToString()));
			}
			else
				OnResolveCompleted(t, callback);
		}

		void p_PackageDownloaded(object sender, SLPackage.PackageEventArgs e)
		{
			//now I have the stream for the Xap, I can load the assembly and register an nstance of the type
			LoadFromStream(e);
			object t = RegisterAndResolveType(e.FromType, e.ToType, e.Name);
			_DownloadingAssembliesGuard.Remove(e.PackageUri);
			OnDownloadCompleted(new DownloadPackageEventArgs());
			OnResolveCompleted(t, e.ResolveCallback);
		}

		private void LoadFromStream(SLPackage.PackageEventArgs e)
		{
			switch (System.IO.Path.GetExtension(e.PackageUri).ToLower())
			{
				case ".dll":
					LoadAssemblyFromStream(e.PackageStream, e.PackageUri);
					break;
				default:
					//Xap files are in the default case
					PackageUtil.LoadAssembliesFromXap(e.PackageStream, _LoadedAssemblies);
					break;
			}
		}

		void LoadAssemblyFromStream(System.IO.Stream stream, string uri)
		{
			string assemblyname = System.IO.Path.GetFileNameWithoutExtension(uri);
			if (!_LoadedAssemblies.ContainsKey(assemblyname))
				lock (_LoadedAssemblies)
				{
					Assembly asm = PackageUtil.LoadAssembly(stream);
					_LoadedAssemblies.Add(assemblyname, asm);
				}
		}

		private object RegisterAndResolveType(Type fromType, string toType, string name)
		{
			string asmn = Utils.ExtractAssemblyNameFromTypeFullName(toType);
			Assembly asm = _LoadedAssemblies[asmn];
			//now we have to register the type
			Type _toType = asm.GetType(toType.Split(',')[0].Trim());
			RegisterType(fromType, _toType, name);
			//resolve the type and fire the event
			object typeResolved = _unityContainer.Resolve(fromType, name);
			return typeResolved;
		}

		public void RegisterType(Type fromType, Type toType, string name)
		{
			_unityContainer.RegisterType(fromType, toType, name);
		}

		/// <summary>
		/// list of informations used to download the XAP and DLL files for the deferred type registration
		/// before the resolution phase
		/// </summary>
		private Dictionary<IoCTypeKey, IoCTypeValue> _ExternalTypes = new Dictionary<IoCTypeKey, IoCTypeValue>();

		/// <summary>
		/// holds a list of all the assembly loaded by the runtime, since we cannot have this information by the runtime
		/// we store a map of the assembly loaded while we proceed to load them in memory.
		/// </summary>
		private Dictionary<string, Assembly> _LoadedAssemblies = new Dictionary<string, Assembly>();

		public Dictionary<string, Assembly> LoadedAssemblies { get { return _LoadedAssemblies; } }

		private List<string> _DownloadingAssembliesGuard = new List<string>();

		public void RegisterType(Type fromType, string toType, string name, Uri uri)
		{
			//1- verify if the type was already downloaded and mapped
			Type t = Type.GetType(toType);
			if (t != null)
			{
				//check to see if the type is registered
				if (!_unityContainer.IsTypeRegistered(t))
				{
					RegisterType(fromType, t, name);
				}
			}
			else
			{
				// the type is an external type, we have to store all the information
				// needed by the Resolve() to download and create an instance of the type
				IoCTypeKey k = new IoCTypeKey(fromType, name);
				if (!_ExternalTypes.ContainsKey(k))
					_ExternalTypes.Add(k, new IoCTypeValue(toType, uri));
			}
		}

		public void RegisterInstance(Type FromType, string name, object instance)
		{
			_unityContainer.RegisterInstance(FromType, name, instance);
		}

		protected void OnDownloadStarted(DownloadPackageEventArgs e)
		{
			if (DownloadStarted != null)
				DownloadStarted(this, e);
		}

		protected void OnDownloadCompleted(DownloadPackageEventArgs e)
		{
			if (DownloadCompleted != null)
				DownloadCompleted(this, e);
		}

		public event EventHandler<DownloadPackageEventArgs> DownloadStarted;

		public event EventHandler<DownloadPackageEventArgs> DownloadCompleted;

		#endregion

	}
}
