﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace Structura.Infrastructure
{
	public class ResultEventArgs<T> : EventArgs
	{
		public T Result { get; private set; }

		public ResultEventArgs(T value)
		{
			Result = value;
		}
	}

	public class EnumerableResultEventArgs<T> : EventArgs
	{
		public IEnumerable<T> Result { get; private set; }

		public EnumerableResultEventArgs(IEnumerable<T> list)
		{
			Result = list;
		}
	}
}
