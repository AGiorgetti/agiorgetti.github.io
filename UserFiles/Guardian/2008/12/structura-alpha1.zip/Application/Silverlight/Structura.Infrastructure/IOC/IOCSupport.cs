﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Structura.Infrastructure.IOC
{
	internal class IoCTypeKey
	{
		public Type FromType;
		public string Name;

		public IoCTypeKey(Type fromtype, string name)
		{
			FromType = fromtype;
			Name = name;
		}

		public override bool Equals(object obj)
		{
			IoCTypeKey t = obj as IoCTypeKey;
			return ((FromType == t.FromType) && (Name == t.Name));
		}

		public override int GetHashCode()
		{
			return FromType.GetHashCode() ^ Name.GetHashCode();
		}
	}

	internal class IoCTypeValue
	{
		public string ToType;
		public Uri Uri;

		public IoCTypeValue(string totype, Uri uri)
		{
			ToType = totype;
			Uri = uri;
		}
	}
}
