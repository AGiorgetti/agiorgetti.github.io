﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Structura.Infrastructure.IOC
{
	/// <summary>
	/// callback function the argoment is the object resolved
	/// </summary>
	/// <param name="result"></param>
	public delegate void ResolveCompletedCallback(object result);

	public delegate void ResolveCompletedCallback<T>(T result);

	/// <summary>
	/// Interface that wrap the actualy IoC system, we will add method to support
	/// dynamic loading of assemblies or Xap files if the system isn't able to resolve a type
	/// given the fact that the use registered some information to retrieve the data to create the 
	/// instances.
	/// 
	/// In our dreams the types we want to create are totally decoupled, that is...
	/// nothing (even their interface) should be known to the main module, so we need to specify
	/// each type with a tag name (string) and we need to ask to the container to create 
	/// types passing in that string parameters.
	/// 
	/// The container then have to check if it 'knows' how to create the type of it
	/// has to download the assembly that contains the actual type.
	/// </summary>
	/// <remarks>
	/// if the container is registered as interface/singleton object inside itself and
	/// if a controller or any other class has in the constructor an instance of this
	/// container interface as a parameter it will be automatically assigned 
	/// the instance registered as singleton, if and only if the type is created
	/// using the IOC container itself
	/// </remarks>
	public interface IIoC
	{
		/// <summary>
		/// Resolve an instance of the requested type from the container.
		/// </summary>
		/// <param name="type">The type of object to get from the container.</param>
		/// <returns>An instance of <paramref name="type"/>.</returns>
		//object Resolve(Type type);

		/// <summary>
		/// Tries to resolve an instance of the requested type from the container.
		/// </summary>
		/// <param name="type">The type of object to get from the container.</param>
		/// <returns>
		/// An instance of <paramref name="type"/>. 
		/// If the type cannot be resolved it will return a <see langword="null" /> value.
		/// </returns>
		//object TryResolve(Type type);

		/// <summary>
		/// Tries to resolve an instance of the requested type from the container.
		/// </summary>
		/// <param name="type">The type of object to get from the container.</param>
		/// <param name="name">Friendly name of the type</param>
		/// <returns></returns>
		void BeginResolve(Type type, string name);

		/// <summary>
		/// Try to resolve the type, when the resolution is completed the callback is executed
		/// no event will be fired
		/// </summary>
		/// <param name="type">The type of object to get from the container.</param>
		/// <param name="name">Friendly name of the type</param>
		/// <param name="callback">callback that is executed once the type is resolved</param>
		void BeginResolve(Type type, string name, ResolveCompletedCallback callback);

		/// <summary>
		/// Try to resolve the type, when the resolution is completed the callback is executed
		/// no event will be fired
		/// (Generic version)
		/// </summary>
		/// <typeparam name="T">The type of object to get from the container.</typeparam>
		/// <param name="name">Friendly name of the type</param>
		/// <param name="callback">callback that is executed once the type is resolved</param>
		void BeginResolve<T>(string name, ResolveCompletedCallback<T> callback);

		/// <summary>
		/// Resolve an instance of the requested type from the container.
		/// </summary>
		/// <param name="type">The type of object to get from the container.</param>
		/// <param name="name">Friendly name of the type</param>
		/// <returns>An instance of <paramref name="type"/>.</returns>
		/// <remarks>Be very careful when using these function and try to istantiate only
		/// types that are already known to the container.</remarks>
		object Resolve(Type type, string name);

		/// <summary>
		/// Resolve an instance of the requested type from the container.
		/// (Generic version)
		/// </summary>
		/// <typeparam name="T">The type of object to get from the container.</typeparam>
		/// <param name="name">Friendly name of the type</param>
		/// <returns>An instance of <paramref name="type"/>.</returns>
		/// <remarks>Be very careful when using these function and try to istantiate only
		/// types that are already known to the container.</remarks>
		T Resolve<T>(string name);

		/// <summary>
		/// event called every time you ask for a begin resolve without a callback
		/// if you use the BeginResolve that passes in a callback the event will not be fired
		/// </summary>
		event EventHandler<ResolveCompletedEventArgs> ResolveCompleted;

		/// <summary>
		/// Register a type into the UnityIoC
		/// </summary>
		/// <param name="fromType">Interface/service implemented by the type</param>
		/// <param name="toType">Actual Type to create</param>
		/// <param name="name">Friendly name of the type</param>
		void RegisterType(Type fromType, Type toType, string name);

		/// <summary>
		/// Register a type into the UnityIoC, used for external types
		/// </summary>
		/// <param name="fromType">Interface/service implemented by the type</param>
		/// <param name="toType">Fully Assembly Qualified name of the Actual Type to create</param>
		/// <param name="name">Friendly name of the type</param>
		/// <param name="uri">uri of the dll or xap to download</param>
		void RegisterType(Type fromType, string toType, string name, Uri uri);

		/// <summary>
		/// register an instance of an object as a singleton
		/// </summary>
		/// <param name="FromType"></param>
		/// <param name="name"></param>
		/// <param name="instance"></param>
		void RegisterInstance(Type FromType, string name, object instance);

		event EventHandler<DownloadPackageEventArgs> DownloadStarted;

		event EventHandler<DownloadPackageEventArgs> DownloadCompleted;
	}

	public class DownloadPackageEventArgs : EventArgs
	{

	}

	public class ResolveCompletedEventArgs : EventArgs
	{
		private object _Result = null;
		public object Result { get { return _Result; } }

		public ResolveCompletedEventArgs(object result)
		{
			_Result = result;
		}
	}

	public class TypeNotRegisteredException : Exception
	{
		//
		// For guidelines regarding the creation of new exception types, see
		//    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpgenref/html/cpconerrorraisinghandlingguidelines.asp
		// and
		//    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dncscol/html/csharp07192001.asp
		//

		public TypeNotRegisteredException() { }
		public TypeNotRegisteredException(string message) : base(message) { }
		public TypeNotRegisteredException(string message, Exception inner) : base(message, inner) { }
	}
}
