﻿using System;
using System.Windows;
using System.Windows.Controls;


namespace Structura.Infrastructure.ViewModel
{
	/// <summary>
	/// Represents a View user control that is associated with a Controller/Presenter/ViewModel.
	/// The Controller - which will expose the data for bindings - is surfaced as the View's DataContext.
	/// </summary>
	public class View : UserControl, IView
	{

		/// <summary>
		/// Represents the View attached property.
		/// </summary>
		public static readonly DependencyProperty ModelProperty =
			 DependencyProperty.RegisterAttached("Controller", typeof(object), typeof(View), null);

		/// <summary>
		/// Initializes an instance of a View.
		/// </summary>
		public View()
		{
		}

		/// <summary>
		/// Initializes an instance of a View with the specified model.
		/// </summary>
		/// <param name="viewModel">The associated controller.</param>
		public View(Controller viewModel)
		{
			Controller = viewModel;
		}

		/// <summary>
		/// Gets or sets the model associated with the view.
		/// 
		/// It must be of type object to have designer support
		/// </summary>
		public virtual object Controller
		{
			get
			{
				return DataContext; // as Controller;
			}
			set
			{
				if (!(value is Controller))
					throw new ArgumentException("The value assigned must be derived from Controller");
				SetValue(ModelProperty, value);
				DataContext = value;
				((Controller)value).View = this;
			}
		}

		/// <summary>
		/// Gets the model associated with the specified framework element.
		/// </summary>
		/// <param name="element">The element to lookup.</param>
		/// <returns>The associated model object if any.</returns>
		public static object GetController(FrameworkElement element)
		{
			object model = element.GetValue(ModelProperty);

			return model;
		}

		/// <summary>
		/// Sets the controller associated with the specified framework element.
		/// The model is also made available for binding by using it to set the
		/// DataContext of the element.
		/// </summary>
		/// <param name="element">The element to associate with the model.</param>
		/// <param name="value">The controller to use.</param>
		public static void SetController(FrameworkElement element, object value)
		{
			((View)element).Controller = value as Controller;
		}

		#region IView Members

		public virtual void Close()
		{
			
		}

		public virtual void UpdateInterface()
		{
			
		}

		#endregion
	}
}
