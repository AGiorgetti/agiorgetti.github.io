﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.Threading;
using Structura.Utils;

namespace Structura.Infrastructure.ViewModel
{
   /// <summary>
   /// Provides a base class for implementing models that encapsulate
   /// data and/or behavior that is independent of the presentation.
   /// </summary>
   [DataContract(IsReference = true), Serializable]
   public abstract class Model : INotifyPropertyChanged
   {
      /// <summary>
      /// a dictionary to cache property changed event args generated for each property
      /// </summary>
      [NonSerialized]
      private static readonly Dictionary<string, PropertyChangedEventArgs> _eventArgsMap =
          new Dictionary<string, PropertyChangedEventArgs>();

      //[NonSerialized]
      private SynchronizationContext _syncContext { get { return SynchronizationContext.Current; } }

      ///// <summary>
      ///// Initializes an instance of a Model.
      ///// </summary>
      //protected Model()
      //{
      //}

      /// <summary>
      /// function to assign the value of a property to an internal member
      /// and to raid the corresponding property chanhed event
      /// </summary>
      /// <typeparam name="T">Type of the property to set</typeparam>
      /// <param name="field">internal variable that holds the value</param>
      /// <param name="value">new value to set</param>
      /// <param name="propName">name of the property</param>
      protected void innerSet<T>(ref T field, T value, string propName)
      {
         if ((field == null) && (value == null)) return;
         if ((field != null) && (field.Equals(value))) return;
         field = value;
         RaisePropertyChanged(propName);
      }

      /// <summary>
      /// Get a PropertyChangedEventArgs instance fromt he dictionary or
      /// create a new one if not present
      /// </summary>
      /// <param name="propertyName">name of the property</param>
      /// <returns>Instance of the class</returns>
      private static PropertyChangedEventArgs GetEventArgs(string propertyName)
      {
         PropertyChangedEventArgs pe = null;
         if (_eventArgsMap.TryGetValue(propertyName, out pe) == false)
         {
            pe = new PropertyChangedEventArgs(propertyName);
            _eventArgsMap[propertyName] = pe;
         }

         return pe;
      }

      /// <summary>
      /// Raises a change notification event to signal a change in the
      /// specified property's value.
      /// </summary>
      /// <param name="propertyName">The property that has changed.</param>
      protected void RaisePropertyChanged(string propertyName)
      {
         if (String.IsNullOrEmpty(propertyName))
         {
            throw new ArgumentNullException("propertyName");
         }

         if (PropertyChanged == null)
         {
            return;
         }

         if (_syncContext != null)
            _syncContext.Post(delegate(object state)
            {
               PropertyChanged(this, GetEventArgs(propertyName));
            }, null);
         else
            UIThread.Run(() =>
               {
                  PropertyChanged(this, GetEventArgs(propertyName));
               });
      }

      /// <summary>
      /// Raises a change notification event to signal a change in the
      /// specified properties.
      /// </summary>
      /// <param name="propertyNames">The properties that have changed.</param>
      protected void RaisePropertyChanged(params string[] propertyNames)
      {
         if ((propertyNames == null) || (propertyNames.Length == 0))
         {
            throw new ArgumentNullException("propertyNames");
         }
         if (PropertyChanged == null)
         {
            return;
         }

         if (_syncContext != null)
            _syncContext.Post(delegate(object state)
            {
               foreach (string propertyName in propertyNames)
               {
                  PropertyChanged(this, GetEventArgs(propertyName));
               }
            }, null);
         else
            UIThread.Run(() =>
               {
                  foreach (string propertyName in propertyNames)
                  {
                     PropertyChanged(this, GetEventArgs(propertyName));
                  }
               });
      }

      #region Implementation of INotifyPropertyChanged

      /// <summary>
      /// lets make it virtual to be used with ORMs proxies
      /// </summary>
      [field: NonSerialized]
      public virtual event PropertyChangedEventHandler PropertyChanged;

      //[NonSerialized]
      //private PropertyChangedEventHandler _PropertyChanged;

      //public virtual event PropertyChangedEventHandler PropertyChanged
      //{
      //   add { _PropertyChanged += value; }
      //   remove { _PropertyChanged -= value; }
      //}

      #endregion

   }
}
