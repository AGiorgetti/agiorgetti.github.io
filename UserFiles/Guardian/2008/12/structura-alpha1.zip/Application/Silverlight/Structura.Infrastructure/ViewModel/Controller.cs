﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Structura.Infrastructure.IOC;

namespace Structura.Infrastructure.ViewModel
{
	/// <summary>
	/// controller class related to a view, encapsulated data and behaviors
	/// </summary>
	public class Controller : Model
	{
        //public Controller()
        //    : base()
        //{ }

		public IView View { get; set; }
	}

	/// <summary>
	/// extended controller class with support for IOC
	/// </summary>
	public class ControllerExt : Controller
	{
		public IIoC IOC { get; set; }
	}
}
