﻿using System.Runtime.Serialization;
using Structura.Utils;
using System;

namespace Structura.Infrastructure.ViewModel
{
	[DataContract(IsReference=true), Serializable]
	public abstract class EntityBase : Model
	{
		#region ICloneable Members

		public abstract object DeepClone();

		#endregion
	}
}
