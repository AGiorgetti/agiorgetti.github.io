﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Structura.Infrastructure.IOC
{
	/// <summary>
	/// request to an external source the list of types to register into the UnityIoC
	/// 
	/// for external types the external source will reply with something like this:
	/// IService (interface implemented), Type (Fully qualified name of the type to Create), Friendly name
	///  
	/// still to decide how to implement this
	/// </summary>
	public class ApplicationInitializer
	{
		public ApplicationInitializer(IIoC ioc, IApplicationConfigurationProvider configurator)
		{
			_ioc = ioc;
			_configurator = configurator;
		}

		IIoC _ioc = null;
		IApplicationConfigurationProvider _configurator = null;

		/// <summary>
		/// use the configuration provider to initialize the ioc system
		/// </summary>
		public void Init()
		{
			foreach (TypeSetting ts in _configurator.GetConfiguration())
			{
				Type fromType = Type.GetType(ts.FromType);
				if (ts.Uri == null)
				{
					//register a 'local' type
					Type toType = Type.GetType(ts.ToType);
					_ioc.RegisterType(fromType, toType, ts.Name);
				}
				else
				{
					//register an 'external' type
					_ioc.RegisterType(fromType, ts.ToType, ts.Name, ts.Uri);
				}
			}
		}
	}
}
