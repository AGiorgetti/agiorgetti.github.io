﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestApp.Entities;
using Structura.Utils;

namespace TestApp.Silverlight.UnitTest
{
	[TestClass]
	public class GenericEqualTest
	{
		[TestMethod]
		public void TestEqualOnSinglePublicProperty()
		{
			TestEntityForEquality te1 = new TestEntityForEquality("1", "2", "3");
			TestEntityForEquality te2 = new TestEntityForEquality("1", "2", "3");
			//PrivateField it's a public property
			Assert.IsTrue(Equality.GenericEquals(te1, te2, "PrivateField"));
		}

		//non possiamo accedere alle proprietà non public o interal
		[TestMethod, ExpectedException(typeof(NullReferenceException))]
		public void TestEqualOnSinglePrivateProperty()
		{
			TestEntityForEquality te1 = new TestEntityForEquality("1", "2", "3");
			TestEntityForEquality te2 = new TestEntityForEquality("1", "2", "3");
			Assert.IsTrue(Equality.GenericEquals(te1, te2, "ProtectedFieldProperty"));
		}
	}
}
