﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestApp.Entities;
using Structura.Utils;

namespace TestApp.UnitTest
{
	[TestClass]
	public class TestEntitiesTest
	{
		[TestMethod]
		public void TestEntityNoAttributeDeepClone()
		{
			TestEntityNoAttributes e = new TestEntityNoAttributes("1");
			TestEntityNoAttributes eCloned = e.DeepClone();
			Assert.AreEqual(e.PublicField, eCloned.PublicField);
		}

		[TestMethod]
		public void TestEntityAttributeDeepClone()
		{
			TestEntityAttributes e = new TestEntityAttributes("1", "2", "3");
			TestEntityAttributes eCloned = e.DeepClone();
			Assert.AreEqual(e.PublicField, eCloned.PublicField);
			Assert.AreEqual(e.ProtectedField, eCloned.ProtectedField);
			Assert.AreEqual(e.PrivateField, eCloned.PrivateField);
		}
	}
}
