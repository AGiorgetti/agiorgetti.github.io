﻿using System;
using TestApp.Infrastructure;
using TestApp.Entities;
using System.Collections.Generic;
using Structura.Infrastructure.ViewModel;
using TestApp.DataLayer.DataService;
using Structura.Infrastructure;

namespace TestApp.DataLayer
{
	public class DataLayer : IDataLayer
	{
		#region AssetDefinition

		public void GetAllClientsAsync(Guid customerID)
		{
			TestApp.DataLayer.DataService.DataServiceClient c = new TestApp.DataLayer.DataService.DataServiceClient();
			c.GetAllClientsCompleted += (sender, e) =>
			{
				if (e.Error == null)
					OnGetAllClientsCompleted(new EnumerableResultEventArgs<Client>(
						e.Result));
				else
				{
					//if we have an error we return an empty list, 
					//todo: find a better way to notify errors
					OnGetAllClientsCompleted(new EnumerableResultEventArgs<Client>(new List<Client>()));
				}
			};
			c.GetAllClientsAsync(customerID);
		}

		private void OnGetAllClientsCompleted(EnumerableResultEventArgs<Client> e)
		{
			if (GetAllClientsCompleted != null)
				GetAllClientsCompleted(this, e);
		}

		public event EventHandler<EnumerableResultEventArgs<Client>> GetAllClientsCompleted;

		public void GetClientAsync(Guid assetID)
		{
			TestApp.DataLayer.DataService.DataServiceClient c = new TestApp.DataLayer.DataService.DataServiceClient();
			c.GetClientCompleted += (sender, e) =>
			{
				if (e.Error == null)
					OnGetClientCompleted(new ResultEventArgs<Client>(e.Result));
				else
					throw e.Error;
			};
			c.GetClientAsync(assetID);
		}

		private void OnGetClientCompleted(ResultEventArgs<Client> e)
		{
			if (GetClientCompleted != null)
				GetClientCompleted(this, e);
		}

		public event EventHandler<ResultEventArgs<Client>> GetClientCompleted;

		public void GetAllInvoicesAsync(Guid customerId)
		{
			TestApp.DataLayer.DataService.DataServiceClient c = new TestApp.DataLayer.DataService.DataServiceClient();
			c.GetAllInvoicesCompleted += (sender, e) =>
			{
				if (e.Error == null)
					OnGetAllInvoicesCompleted(new EnumerableResultEventArgs<Invoice>(Helpers.AdjustInvoiceList(e.Result)));
				else
				{
					//if we have an error we return an empty list, 
					//todo: find a better way to notify errors
					OnGetAllInvoicesCompleted(new EnumerableResultEventArgs<Invoice>(new List<Invoice>()));
				}
			};
			c.GetAllInvoicesAsync(customerId);
		}

		private void OnGetAllInvoicesCompleted(EnumerableResultEventArgs<Invoice> e)
		{
			if (GetAllInvoicesCompleted != null)
				GetAllInvoicesCompleted(this, e);
		}

		public event EventHandler<EnumerableResultEventArgs<Invoice>> GetAllInvoicesCompleted;

		public void GetInvoiceAsync(Guid id)
		{
			TestApp.DataLayer.DataService.DataServiceClient c = new TestApp.DataLayer.DataService.DataServiceClient();
			c.GetInvoiceCompleted += (sender, e) =>
			{
				if (e.Error == null)
					OnGetInvoiceCompleted(new ResultEventArgs<Invoice>(Helpers.AdjustEntityBase(e.Result) as Invoice));
				else
					throw e.Error;
			};
			c.GetInvoiceAsync(id);
		}

		private void OnGetInvoiceCompleted(ResultEventArgs<Invoice> e)
		{
			if (GetInvoiceCompleted != null)
				GetInvoiceCompleted(this, e);
		}

		public event EventHandler<ResultEventArgs<Invoice>> GetInvoiceCompleted;

		#endregion

		public void BeginSave(EntityBase o)
		{
			TestApp.DataLayer.DataService.DataServiceClient c = new TestApp.DataLayer.DataService.DataServiceClient();
			c.SaveCompleted += (sender, e) =>
			{
				if (e.Error == null)
					OnSaveCompleted(new ResultEventArgs<EntityBase>(Helpers.AdjustEntityBase(e.Result)));
				else
					throw e.Error;
			};
			// todo: check these calls, prevent any array classes to be sent back
			Helpers.AdjustEntityBase(o);
			c.SaveAsync(o);
		}

		private void OnSaveCompleted(ResultEventArgs<EntityBase> e)
		{
			if (SaveCompleted != null)
				SaveCompleted(this, e);
		}

		public event EventHandler<ResultEventArgs<EntityBase>> SaveCompleted;

		public void BeginDelete(EntityBase o)
		{
			TestApp.DataLayer.DataService.DataServiceClient c = new TestApp.DataLayer.DataService.DataServiceClient();
			c.DeleteCompleted += (sender, e) =>
			{
				if (e.Error == null)
					OnDeleteCompleted(e);
				else
					throw e.Error;
			};
			// todo: check these calls, prevent any array classes to be sent back
			Helpers.AdjustEntityBase(o);

			c.DeleteAsync(o);
		}

		private void OnDeleteCompleted(EventArgs e)
		{
			if (DeleteCompleted != null)
				DeleteCompleted(this, e);
		}

		public event EventHandler DeleteCompleted;

	}
}
