﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Structura.Silverlight.Controls.Windows;
using Structura.Infrastructure.IOC;
using Microsoft.Practices.SLUnity;
using TestApp.AppManager.Presenter;
using Structura.Silverlight.Controls.Menu.DropDownMenu;

namespace TestApp.AppManager.View
{
	public partial class Main : Structura.Infrastructure.ViewModel.View, IMainView
	{
		public Main()
		{
			InitializeComponent();

			_WindowsManager = new WindowsManager(LayoutRoot);
			_AppManager = this.Controller as AppManagerController; //new AppManagerController();
			_AppManager.Init(this, new UnityIoC(new UnityContainer()));
			_AppManager.IoC.DownloadStarted += (sender, e) => { GlobalWaiting.StartWait(); };
			_AppManager.IoC.DownloadCompleted += (sender, e) => { GlobalWaiting.StopWait(); };
			_AppManager.IoC.RegisterInstance(typeof(IWindowsManager), null, _WindowsManager);
		}

		private AppManagerController _AppManager;
		private IWindowsManager _WindowsManager;

		#region IMainView Members

		public void DisplayModules(List<TestApp.AppManager.Presenter.ModuleInfo> modules)
		{
			// do nothing
		}

		public void DisplayModuleData(TestApp.AppManager.Presenter.ModuleSettings ms)
		{
			// do nothing
		}

		public void AddMainMenu(string menuText, List<TestApp.AppManager.Presenter.MenuItemInfo> menuItems)
		{
			MainMenuItem mmi = MainMenu.CreateMainMenuItem(menuText);
			foreach (var mi in menuItems)
			{
				var newMi = MainMenu.CreateMenuItem(mi.Name);
				newMi.Tag = mi.TypeSettingName;
				newMi.MenuItemClick += (sender, e) =>
				{
					_AppManager.IoC.BeginResolve<TestApp.Infrastructure.IExecutable>((sender as MenuItem).Tag.ToString(), (exe) =>
						{
							object o = exe.Execute();
							if (o != null)
							{
								//open in a new window
								Window w = new Window(o as UserControl);
								w.Caption = (sender as MenuItem).Text;
								_WindowsManager.Show(w);
							}
						});
				};
				mmi.AddSubmenu(newMi);
			}
			MainMenu.AddMenu(mmi);
		}

		#endregion

	}
}
