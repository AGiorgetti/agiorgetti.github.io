﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using TestApp.AppManager.View;
using TestApp.Infrastructure;
using Structura.Infrastructure.IOC;
using Structura.Infrastructure.ViewModel;
using TestApp.Entities;
using Structura.Infrastructure;

namespace TestApp.AppManager.Presenter
{
	public class AppManagerController : Controller
	{
		public void Init(IMainView view, IIoC iocContainer)
		{
			// create the IoC layer and register as a singleton
			IoC = iocContainer;
			IoC.RegisterInstance(typeof(IIoC), null, IoC);

			// creates and loads the AppSettings class
			AppSettings AppSettings = new AppSettings(IoC);
			IoC.SetAppSettings(AppSettings);

			this.View = view;

			appConfig = new AppConfigurator();

			// load 'static' config variables
			// EntitiesSettings.StoareDesignerBaseUri = appConfig.GetAssetCategoryIconUri();

			appConfig.GetModulesCompleted += appConfig_GetModulesCompleted;
			appConfig.GetModuleCompleted += appConfig_GetModuleCompleted;
			appConfig.GetAddictionalModulesToRegisterCompleted += appConfig_GetAddictionalModulesToRegisterCompleted;
			appConfig.GetAddictionalModulesToRegisterAsync();
		}

		void appConfig_GetAddictionalModulesToRegisterCompleted(object sender, EnumerableResultEventArgs<TypeSetting> e)
		{
			// register the types in the IoC, not like single instances
			//we can now register all the types into the IoC System
			RegisterTypes(e.Result);

			// when dont lets start with some modules
			appConfig.BeginGetModules();
		}

		public IIoC IoC { get; private set; }
		private IAppConfigurator appConfig;

		#region "Dynamyc modules Loading and menu building"

		/// <summary>
		/// holds a list of all modules that can be loaded by the application
		/// </summary>
		private List<ModuleInfo> AvailableModules;
		private Dictionary<ModuleInfo, ModuleSettings> ModulesSettings = new Dictionary<ModuleInfo, ModuleSettings>();

		private int CurrentModuleIndex = 0;

		void appConfig_GetModulesCompleted(object sender, GetModulesCompletedEventArgs e)
		{
			//we have the complete module list
			AvailableModules = e.Modules;
			(View as IMainView).DisplayModules(AvailableModules);
			//start to retrieve each module types and menu configuration
			GetNextModuleConfiguration();
		}

		private void GetNextModuleConfiguration()
		{
			if (CurrentModuleIndex < AvailableModules.Count)
				appConfig.BeginGetModule(AvailableModules[CurrentModuleIndex]);
			else
				ConfigureApplication();
		}

		void appConfig_GetModuleCompleted(object sender, GetModuleCompletedEventArgs e)
		{
			ModulesSettings.Add(AvailableModules[CurrentModuleIndex], e.Settings);
			(View as IMainView).DisplayModuleData(e.Settings);
			CurrentModuleIndex++;
			GetNextModuleConfiguration();
		}

		private void RegisterTypes(IEnumerable<TypeSetting> types)
		{
			foreach (TypeSetting ts in types)
			{
				IoC.RegisterType(Type.GetType(ts.FromType), ts.ToType, ts.Name, ts.Uri);
			}
		}

		private void ConfigureApplication()
		{
			//go on with application initialization
			//we can now register all the types into the IoC System
			foreach (var ms in ModulesSettings.Values)
				RegisterTypes(ms.TypeSettings);
			//it's now time to build the menu system
			foreach (var ms in ModulesSettings.Values)
				(View as IMainView).AddMainMenu(ms.MainMenuName, ms.MenuItems);
		}

		#endregion

	}
}
