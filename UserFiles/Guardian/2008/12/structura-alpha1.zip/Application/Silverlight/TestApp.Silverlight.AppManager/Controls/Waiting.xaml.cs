﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TestApp.AppManager.Controls
{
	public partial class Waiting : UserControl
	{
		public Waiting()
		{
			InitializeComponent();
		}

		public void StartWait()
		{
			this.Visibility = Visibility.Visible;
		}

		public void StopWait()
		{
			this.Visibility = Visibility.Collapsed;
		}
	}
}
