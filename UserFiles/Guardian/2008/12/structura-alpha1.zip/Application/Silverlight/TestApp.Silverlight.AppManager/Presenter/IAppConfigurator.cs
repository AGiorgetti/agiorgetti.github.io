﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using TestApp.Infrastructure;
using Structura.Infrastructure.IOC;
using Structura.Infrastructure;

namespace TestApp.AppManager.Presenter
{
	public interface IAppConfigurator : IApplicationConfigurationProvider
	{
		/// <summary>
		/// Get the list of the modules that are part of the application
		/// It will provide a list of ModuleInfo data
		/// </summary>
		void BeginGetModules();

		event EventHandler<GetModulesCompletedEventArgs> GetModulesCompleted;

		/// <summary>
		/// Get the information of the single module, like the menu voices
		/// and similar
		/// </summary>
		/// <param name="mi"></param>
		void BeginGetModule(ModuleInfo mi);

		event EventHandler<GetModuleCompletedEventArgs> GetModuleCompleted;

		/// <summary>
		/// Gets information about new or addictional module or classes to
		/// register into the IoC container. May not be needed by WPF application+
		/// since usually the configuration is local to the app.config, but
		/// can be used to retrieve remote configurations anyway.
		/// </summary>
		void GetAddictionalModulesToRegisterAsync();

		event EventHandler<EnumerableResultEventArgs<TypeSetting>> GetAddictionalModulesToRegisterCompleted;
	}
	
	public class GetModulesCompletedEventArgs : EventArgs
	{
		public List<ModuleInfo> Modules { get; private set; }

		public GetModulesCompletedEventArgs(List<ModuleInfo> modules)
		{
			Modules = modules;
		}
	}
	
	public class GetModuleCompletedEventArgs : EventArgs
	{
		public ModuleSettings Settings { get; private set; }
		
		public GetModuleCompletedEventArgs(ModuleSettings ms)
		{
			Settings = ms;
		}
	}

	public class ModuleInfo : ApplicationModule
	{
		private string _url;
		public string Url { get { return _url; } set { _url = value; } }

		public ModuleInfo()
		{ }
	}

	public class MenuItemInfo
	{
		public string Name { get; set; }
		public string TypeSettingName { get; set; }
	}

	public class ModuleSettings
	{
		public List<TypeSetting> TypeSettings { get; private set; }

		public string MainMenuName { get; private set; }

		public List<MenuItemInfo> MenuItems { get; private set; }

		public ModuleSettings(
			List<TypeSetting> typeSettings,
			string mainMenuName,
			List<MenuItemInfo> menuItems)
		{
			TypeSettings = typeSettings;
			MainMenuName = mainMenuName;
			MenuItems = menuItems;
		}
	}

}
