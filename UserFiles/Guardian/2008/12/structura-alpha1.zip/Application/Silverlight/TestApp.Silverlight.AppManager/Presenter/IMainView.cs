﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using TestApp.AppManager.Presenter;
using TestApp.Infrastructure;
using Structura.Infrastructure.ViewModel;

namespace TestApp.AppManager.View
{
	public interface IMainView : IView
	{

		/// <summary>
		/// add a menu to the main menu bar
		/// </summary>
		/// <param name="menuText"></param>
		/// <param name="menuItems"></param>
		void AddMainMenu(string menuText, List<MenuItemInfo> menuItems);

		#region "Debug functions"

		void DisplayModules(List<ModuleInfo> modules);

		void DisplayModuleData(ModuleSettings ms);

		#endregion
	}
}
