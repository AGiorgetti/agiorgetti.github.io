﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SL.IoC.Infrastructure;
using System.Collections.Generic;

namespace TestApp.AppManager
{
	/// <summary>
	/// no more used
	/// </summary>
	public class StaticApplicationConfigurationProvider : IApplicationConfigurationProvider
	{

		#region IApplicationConfigurationProvider Members

		public System.Collections.Generic.List<TypeSetting> GetConfiguration()
		{
			List<TypeSetting> list = new List<TypeSetting>();
			list.Add(new TypeSetting(typeof(TestApp.Infrastructure.Module).AssemblyQualifiedName, "TestApp.TestModule1.Module, TestApp.TestModule1", "TestModule1", new Uri("/ClientBin/TestApp.TestModule1.dll", UriKind.Relative)));
			return list;
		}

		#endregion
	}
}
