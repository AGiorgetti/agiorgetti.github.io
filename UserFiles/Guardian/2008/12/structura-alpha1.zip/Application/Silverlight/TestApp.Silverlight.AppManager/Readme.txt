﻿Attenzione per il momento i file che specificano la posizione dei webservice usati dai moduli vengono inclusi manualmente nell'applicazione principale
(ServiceReferences.ClientConfig) con build action 'content' questo perchè il costruttore di default dei webservice cerca di estrarre queste informazioni dallo 
XAP principale e non da eventuali moduli caricati dinamicamente.

AppManager è strattamente legato al modulo di gestione degli utenti
quindi determinati automatismi come la richiesta username e password vengono 
gestiti in automatico

alcuni dati derivanti (come l'utente correntemente registrato sono poi salvati nelle
classi che gestiscono le proprietà del software e che sono contenute nel sistema di inversione di controllo)
