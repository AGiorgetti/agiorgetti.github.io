﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq;
using System.Xml.Linq;
using System.Collections.Generic;
using Structura.Infrastructure.IOC;
using System.Windows.Resources;
using System.IO;
using Structura.Infrastructure;

namespace TestApp.AppManager.Presenter
{
	/// <summary>
	/// knows how to retrieve information to configure any application module installed
	/// </summary>
	public class AppConfigurator : IAppConfigurator
	{

		public event EventHandler<GetModulesCompletedEventArgs> GetModulesCompleted;

		private void OnGetModulesCompleted(GetModulesCompletedEventArgs e)
		{
			if (GetModulesCompleted != null)
				GetModulesCompleted(this, e);
		}

		public void BeginGetModules()
		{
			WebClient wc = new WebClient();
			wc.DownloadStringCompleted += new DownloadStringCompletedEventHandler(wc_GetModulesCompleted);
			wc.DownloadStringAsync(new Uri("/Modules.xml", UriKind.Relative));
		}

		void wc_GetModulesCompleted(object sender, DownloadStringCompletedEventArgs e)
		{
			if (e.Error == null)
			{
				//parse the Modules info file
				XDocument doc = XDocument.Parse(e.Result);

				//parse the data with linq
				IEnumerable<ModuleInfo> list = from mod in doc.Descendants("ModuleInfo")
														 select new ModuleInfo
														 {
															 Id = new Guid((string)mod.Element("ID")),
															 Name = (string)mod.Element("Name"),
															 Version = (string)mod.Element("Version"),
															 Url = (string)mod.Element("Url")
														 };

				List<ModuleInfo> l = new List<ModuleInfo>();
				l.AddRange(list);
				OnGetModulesCompleted(new GetModulesCompletedEventArgs(l));
			}
			else
			{
				//todo:handle the error
			}
		}

		public System.Collections.Generic.List<TypeSetting> GetConfiguration()
		{
			throw new NotImplementedException();
		}

		public void BeginGetModule(ModuleInfo mi)
		{
			WebClient wc = new WebClient();
			wc.DownloadStringCompleted += new DownloadStringCompletedEventHandler(wc_GetModuleCompleted);
			wc.DownloadStringAsync(new Uri(mi.Url, UriKind.Relative));
		}

		void wc_GetModuleCompleted(object sender, DownloadStringCompletedEventArgs e)
		{
			if (e.Error == null)
			{
				//parse the Modules info file
				XDocument doc = XDocument.Parse(e.Result);
				
				var tsl = from ts in doc.Root.Element("TypeSettings").Descendants("TypeSetting")
							 select new TypeSetting(
								 (string)ts.Element("FromType"),
								 (string)ts.Element("ToType"),
								 (string)ts.Element("Name"),
								 new Uri((string)ts.Element("Uri"), UriKind.Relative)
							);

				var mil = from mi in doc.Root.Element("Menu").Element("Items").Descendants("Item")
							 select new MenuItemInfo
							 {
								 Name = (string)mi.Element("Name"),
								 TypeSettingName = (string)mi.Element("TypeSettingName")
							 };
							 
				var miname = (string)doc.Root.Element("Menu").Element("Name");

				var typeList = new List<TypeSetting>();
				typeList.AddRange(tsl);
				string menuName = miname;
				var menuitemsList = new List<MenuItemInfo>();
				menuitemsList.AddRange(mil);
				var ms = new ModuleSettings(typeList, menuName, menuitemsList);
				OnGetModuleCompleted(new GetModuleCompletedEventArgs(ms));
			}
			else
			{
				//todo:handle the error
			}
		}

		public event EventHandler<GetModuleCompletedEventArgs> GetModuleCompleted;

		private void OnGetModuleCompleted(GetModuleCompletedEventArgs e)
		{
			if (GetModuleCompleted != null)
				GetModuleCompleted(this, e);
		}


		public string GetAssetCategoryIconUri()
		{
			StreamResourceInfo sri = Application.GetResourceStream(new Uri("Maintenance.ClientConfig", UriKind.Relative));
			if (sri != null)
			{
				string config = new StreamReader(sri.Stream).ReadToEnd();
				XDocument doc = XDocument.Parse(config);
				//XNamespace ns = doc.Root.Attribute("xmlns").Value;
				return doc.Root.Element("AssetCategoryIconUri").Attribute("Uri").Value;
			}
			return string.Empty;
		}



		#region IAppConfigurator Members


		public void GetAddictionalModulesToRegisterAsync()
		{
			WebClient wc = new WebClient();
			wc.DownloadStringCompleted += new DownloadStringCompletedEventHandler(wc_GetTypesConfigCompleted);
			wc.DownloadStringAsync(new Uri("/TypesConfig.xml", UriKind.Relative));
		}

		void wc_GetTypesConfigCompleted(object sender, DownloadStringCompletedEventArgs e)
		{
			var typeList = new List<TypeSetting>();
			if (e.Error == null)
			{
				//parse the Modules info file
				XDocument doc = XDocument.Parse(e.Result);

				var tsl = from ts in doc.Root.Element("TypeSettings").Descendants("TypeSetting")
							 select new TypeSetting(
								 (string)ts.Element("FromType"),
								 (string)ts.Element("ToType"),
								 (string)ts.Element("Name"),
								 new Uri((string)ts.Element("Uri"), UriKind.Relative)
							);

				typeList.AddRange(tsl);
			}
			else
			{
				//todo:handle the error
			}
			OnGetAddictionalModulesToRegisterCompleted(new EnumerableResultEventArgs<TypeSetting>(typeList));
		}

		private void OnGetAddictionalModulesToRegisterCompleted(EnumerableResultEventArgs<TypeSetting> e)
		{
			if (GetAddictionalModulesToRegisterCompleted != null)
				GetAddictionalModulesToRegisterCompleted(this, e);
		}

		public event EventHandler<EnumerableResultEventArgs<TypeSetting>> GetAddictionalModulesToRegisterCompleted;

		#endregion
	}
}
