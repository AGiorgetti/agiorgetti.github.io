﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.SLUnity;
using TestApp.AppManager.View;
using TestApp.AppManager.Presenter;
using Structura.Infrastructure.IOC;
using Structura.Infrastructure.ViewModel;

namespace TestApp.AppManager
{
    public partial class ConfigFileParseView : Structura.Infrastructure.ViewModel.View, IMainView
    {
        public ConfigFileParseView()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(Main_Loaded);
        }

        void Main_Loaded(object sender, RoutedEventArgs e)
        {
            (this.Controller as AppManagerController).Init(this, new UnityIoC(new UnityContainer()));
        }

        public void DisplayModules(List<TestApp.AppManager.Presenter.ModuleInfo> modules)
        {
            grd.ItemsSource = modules;
        }
        
        System.Collections.ObjectModel.ObservableCollection<string> MenuNameList = new System.Collections.ObjectModel.ObservableCollection<string>();
        System.Collections.ObjectModel.ObservableCollection<TypeSetting> TypeSettingsList = new System.Collections.ObjectModel.ObservableCollection<TypeSetting>();
        System.Collections.ObjectModel.ObservableCollection<MenuItemInfo> MenuItemsList = new System.Collections.ObjectModel.ObservableCollection<MenuItemInfo>();

        public void DisplayModuleData(TestApp.AppManager.Presenter.ModuleSettings ms)
        {
            MenuNameList.Add(ms.MainMenuName);
            foreach (var mi in ms.MenuItems)
                MenuItemsList.Add(mi);
            foreach (var ts in ms.TypeSettings)
                TypeSettingsList.Add(ts);

            grdMenuNames.ItemsSource = MenuNameList;
            grdMenuItems.ItemsSource = MenuItemsList;
            grdTypes.ItemsSource = TypeSettingsList;
        }

        #region IMainView Members

        public void AddMainMenu(string menuText, List<MenuItemInfo> menuItems)
        {
            //do nothing
        }

        #endregion

    }
}
