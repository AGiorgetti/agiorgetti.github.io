﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Structura.Infrastructure.IOC;

namespace TestApp.Infrastructure
{
	/// <summary>
	/// holds any settings relative to the application
	/// </summary>
	public class AppSettings
	{
      /// <summary>
      /// Hypothetical CUstomer of the application
      /// </summary>
      public Guid CustomerId { get { return new Guid("F370D2B2-56D9-40c7-87CB-455DEFC5A11D"); } }

      /// <summary>
      /// Hypothetical user logged
      /// </summary>
		public Guid LoggedUserId
		{
         get { return new Guid("F370D2B2-56D9-40c7-87CB-455DEFC5A11D"); }
		}

		public AppSettings(IIoC ioc)
		{
			_ioc = ioc;
		}

		private IIoC _ioc;
	}

	public static class InfrastructureIoCExtensions
	{
		public static AppSettings GetAppSettings(this IIoC ioc)
		{
			return ioc.Resolve<AppSettings>("AppSettings");
		}

		public static void SetAppSettings(this IIoC ioc, AppSettings settings)
		{
			ioc.RegisterInstance(typeof(AppSettings), "AppSettings", settings);
		}
	}

	public static class RegisteredTypes
	{
		public const string DataLayer = "DataLayer";
	}
}
