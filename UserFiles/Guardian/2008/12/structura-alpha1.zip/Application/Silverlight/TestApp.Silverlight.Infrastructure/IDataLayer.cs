﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using TestApp.Entities;
using Structura.Infrastructure.ViewModel;
using Structura.Infrastructure;

namespace TestApp.Infrastructure
{
	public interface IDataLayer
	{
		void GetAllClientsAsync(Guid customerId);
		event EventHandler<EnumerableResultEventArgs<Client>> GetAllClientsCompleted;

		void GetClientAsync(Guid id);
		event EventHandler<ResultEventArgs<Client>> GetClientCompleted;

		void GetAllInvoicesAsync(Guid customerId);
		event EventHandler<EnumerableResultEventArgs<Invoice>> GetAllInvoicesCompleted;

		void GetInvoiceAsync(Guid id);
		event EventHandler<ResultEventArgs<Invoice>> GetInvoiceCompleted;

		void BeginSave(EntityBase obj);
		event EventHandler<ResultEventArgs<EntityBase>> SaveCompleted;

		void BeginDelete(EntityBase obj);
		event EventHandler DeleteCompleted;
	}
}
