﻿using System;

namespace TestApp.Infrastructure
{
	/// <summary>
	/// Interface that defines a module (like the user & permission management module or
	/// the Asset management module)
	/// </summary>
	public abstract class ApplicationModule
	{
		/// <summary>
		/// Module unique ID
		/// </summary>
		public Guid Id { get { return _ID; } set { _ID = value; } }
		private Guid _ID = Guid.Empty;

		private string _Name;
		public string Name { get { return _Name; } set { _Name = value; } }

		private string _Version;
		public string Version { get { return _Version; } set { _Version = value; } }

		protected ApplicationModule()
		{ }

		protected ApplicationModule(Guid id, string name, string version)
		{
			_ID = id;
			_Name = name;
			_Version = version;
		}

	}
}
