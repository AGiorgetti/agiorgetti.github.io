﻿Test module built like a 
Silverlight Application