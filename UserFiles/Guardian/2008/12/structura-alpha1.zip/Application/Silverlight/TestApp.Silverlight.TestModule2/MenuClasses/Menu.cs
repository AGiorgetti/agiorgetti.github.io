﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TestApp.Infrastructure;

namespace TestApp.TestModule2.MenuClasses
{
	public class Menu1 : IExecutable
	{
		#region IExecutable Members

		public object Execute()
		{
			System.Windows.Browser.HtmlPage.Window.Alert("TM2 Menu1 Clicked");
			return null;
		}

		#endregion
	}

	public class Menu2 : IExecutable
	{
		#region IExecutable Members

		public object Execute()
		{
			System.Windows.Browser.HtmlPage.Window.Alert("TM2 Menu2 Clicked");
			return null;
		}

		#endregion
	}
}
