﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Structura.Silverlight.Controls.FileUploader;
using System.Collections.ObjectModel;
using Structura.Silverlight.Controls.FileServices.FileServicesWCF;
using System.IO;
using Structura.Infrastructure;
using System.ComponentModel;

namespace Structura.Silverlight.Controls.FileServices
{
	public class FileServices : IFileUploader
	{
		FileServicesClient fsClient = new FileServicesClient();

		public void GetImageDataAsync(Guid id, string format)
		{
			fsClient.GetImageDataCompleted += new EventHandler<GetImageDataCompletedEventArgs>(fsClient_GetImageDataCompleted);
			fsClient.GetImageDataAsync(id, format);
		}

		void fsClient_GetImageDataCompleted(object sender, GetImageDataCompletedEventArgs e)
		{
			if (e.Error == null)
				if (GetImageDataCompleted != null)
					GetImageDataCompleted(this, new ResultEventArgs<ImageData>(e.Result));
				else
					throw e.Error;
		}

		public event EventHandler<ResultEventArgs<ImageData>> GetImageDataCompleted;


		#region "Upload Maintenance Designer Resource Icon or similar used by the visualization"

		/// <summary>
		/// uploads a category icon, the upload progress can be checked subscribing to 
		/// events of the returned file structure
		/// </summary>
		/// <param name="fi"></param>
		/// <returns></returns>
		/// <remarks>
		/// la proprietà target fie name indica il nome con cui verrà rinominato il file una volta spostato nella 
		/// directory ad accesso pubblico, se non è presente o è presente null il file assumerà il nome originario
		/// </remarks>
		public UploadFileInfoWCFEx QueueDesignerResourceFileUpload(FileInfo fi, string targetFileName)
		{
			UploadFileInfoWCFEx f = new UploadFileInfoWCFEx(fi);
			f.ChunkSize = ChunkSize;
			f.Tag = targetFileName;
			f.StatusChanged += new EventHandler(UploadDesignerResourceFile_StatusChanged);
			DesignerResourceFiles.Add(f);
			return f;
		}

		public void UploadDesignerResourceFiles()
		{
			foreach (UploadFileInfo f in DesignerResourceFiles)
				if (f.Status != FileUploadStatus.Complete)
					f.Upload();
		}

		void UploadDesignerResourceFile_StatusChanged(object sender, EventArgs e)
		{
			// ask to finalize when the upload is complete
			UploadFileInfoWCFEx f = sender as UploadFileInfoWCFEx;
			if (f.Status == FileUploadStatus.Complete)
			{
				// move the file to the category folder
				fsClient.MoveToDesignerFolderCompleted += new EventHandler<AsyncCompletedEventArgs>(fsClient_MoveToDesignerFolderCompleted);
				string newFileName = f.Filename;
				if (f.Tag != null)
					newFileName = f.Tag.ToString();
				fsClient.MoveToDesignerFolderAsync(f.Filename, newFileName, f);
			}
		}

		void fsClient_MoveToDesignerFolderCompleted(object sender, AsyncCompletedEventArgs e)
		{
			// file upload operation finalized
			(e.UserState as UploadFileInfoWCFEx).IsFinalized = true;
		}

		public System.Collections.ObjectModel.ObservableCollection<UploadFileInfo> DesignerResourceFiles
		{
			get { return _DesignerResourceFiles; }
		}
		private ObservableCollection<UploadFileInfo> _DesignerResourceFiles = new ObservableCollection<UploadFileInfo>();

		#endregion


		#region IFileUploader Members

		public void AddFile(System.IO.FileInfo fi)
		{
			UploadFileInfoWCFEx f = new UploadFileInfoWCFEx(fi);
			f.ChunkSize = ChunkSize;
			f.StatusChanged += new EventHandler(f_StatusChanged);
			Files.Add(f);
		}

		void f_StatusChanged(object sender, EventArgs e)
		{
			// the upload is complete, ask the web server to finalize it;
			UploadFileInfoWCFEx f = sender as UploadFileInfoWCFEx;
			if (f.Status == FileUploadStatus.Complete)
			{
				fsClient.RenameFileCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(client_RenameFileCompleted);
				fsClient.RenameFileAsync(f.Filename, f.ID.ToString(), f);
			}
		}

		void client_RenameFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
		{
			// file upload operation finalized
			(e.UserState as UploadFileInfoWCFEx).IsFinalized = true;
		}

		int mChunkSize = 1048576;
		// int mChunkSize = 4096;
		public int ChunkSize
		{
			get { return mChunkSize; }
			set { mChunkSize = value; }
		}

		public System.Collections.ObjectModel.ObservableCollection<UploadFileInfo> Files
		{
			get { return _Files; }
		}
		private ObservableCollection<UploadFileInfo> _Files = new ObservableCollection<UploadFileInfo>();

		public void Upload()
		{
			foreach (UploadFileInfo f in Files)
				if (f.Status != FileUploadStatus.Complete)
					f.Upload();
		}

		#endregion

	}

	public class UploadFileInfoWCFEx : UploadFileInfoWCF
	{
		public UploadFileInfoWCFEx(FileInfo fi) :
			base(fi)
		{
		}

		private bool _IsFinalized = false;
		public bool IsFinalized
		{
			get { return _IsFinalized; }
			set
			{
				_IsFinalized = value;
				OnPropertyChanged("IsFinalized");
				if (_IsFinalized == true)
					if (UploadFinalized != null)
						UploadFinalized(this, EventArgs.Empty);
			}
		}

		/// <summary>
		/// used to specify addictional properties or postbuild actions
		/// </summary>
		public object Tag { get; set; }

		public event EventHandler UploadFinalized;

	}
}
