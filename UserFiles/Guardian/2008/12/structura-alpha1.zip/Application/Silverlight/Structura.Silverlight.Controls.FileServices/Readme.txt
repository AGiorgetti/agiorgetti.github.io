﻿nome progetto errato è Maintenance.FileServices

Silverlight project

Extension File Services built over the FileUploader controls
they can use an extended version of the same web services to provide new functionalities, like streaming back of files and so on
built over the file upload control.