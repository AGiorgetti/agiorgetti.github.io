﻿using Structura.Infrastructure.ViewModel;
using System.Collections.ObjectModel;
using TestApp.Entities;
using TestApp.Infrastructure;
using Structura.Utils;

namespace TestApp.Silverlight.InvoiceModule.Controller
{
	public class ManageClientsController : ControllerExt
	{
		/// <summary>
		/// the data that represent a building, it's used by the View to bind
		/// </summary>
		private ObservableCollection<Client> _Clients;
		public ObservableCollection<Client> Clients
		{
			get { return _Clients; }
			set { innerSet(ref _Clients, value, "Clients"); }
		}

		/// <summary>
		/// gets all the AssetDefinition for the logged-in Customer
		/// </summary>
		public void GetClientsAsync()
		{
         IDataLayer dl = IOC.Resolve<IDataLayer>(RegisteredTypes.DataLayer);
         dl.GetAllClientsCompleted += (sender, e) =>
			{
				Clients = e.Result.ToObservableCollection();
				View.UpdateInterface();
			};
			dl.GetAllClientsAsync(IOC.GetAppSettings().CustomerId);
		}

		/// <summary>
		/// tries to delete an asset
		/// </summary>
		/// <param name="ad"></param>
		/// <remarks>
		/// check if the asset is used by another asset..etc etc...
		/// </remarks>
		public void DeleteClientAsync(Client client)
		{
			//remove from the database
         IDataLayer dl = IOC.Resolve<IDataLayer>(RegisteredTypes.DataLayer);
         dl.DeleteCompleted += (sender, e) =>
			{
				//remove from the collection
				Clients.Remove(client);
				View.UpdateInterface();
			};
			dl.BeginDelete(client);
		}

		public void CreateClient()
		{
			//chiede alla view di aprire la finestra di editing di un nuovo asset (se non si specificano 
			//parameteri viene sempre creato un nuovo asset)
			EditClient(null);
		}

      public void EditClient(Client client)
		{
			if (client != null)
				client = client.DeepClone() as Client;
			(View as IManageClientsView).ShowEditClient(client);
		}
	}
}
