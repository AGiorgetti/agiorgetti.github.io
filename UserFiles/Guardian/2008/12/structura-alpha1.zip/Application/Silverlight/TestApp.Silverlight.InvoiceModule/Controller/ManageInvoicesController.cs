﻿using Structura.Infrastructure.ViewModel;
using System.Collections.ObjectModel;
using TestApp.Entities;
using TestApp.Infrastructure;
using Structura.Utils;

namespace TestApp.Silverlight.InvoiceModule.Controller
{
	public class ManageInvoicesController : ControllerExt
	{
		/// <summary>
		/// the data that represent a building, it's used by the View to bind
		/// </summary>
		private ObservableCollection<Invoice> _Invoices;
		public ObservableCollection<Invoice> Invoices
		{
			get { return _Invoices; }
         set { innerSet(ref _Invoices, value, "Invoices"); }
		}

		/// <summary>
		/// gets all the Invoices for the logged-in Customer
		/// </summary>
		public void GetDataAsync()
		{
         IDataLayer dl = IOC.Resolve<IDataLayer>(RegisteredTypes.DataLayer);
         dl.GetAllInvoicesCompleted += (sender, e) =>
			{
				Invoices = e.Result.ToObservableCollection();
				View.UpdateInterface();
			};
			dl.GetAllInvoicesAsync(IOC.GetAppSettings().CustomerId);
		}

		/// <summary>
		/// tries to delete an asset
		/// </summary>
		/// <param name="ad"></param>
		/// <remarks>
		/// check if the asset is used by another asset..etc etc...
		/// </remarks>
		public void DeleteAsync(Invoice invoice)
		{
			//remove from the database
         IDataLayer dl = IOC.Resolve<IDataLayer>(RegisteredTypes.DataLayer);
         dl.DeleteCompleted += (sender, e) =>
			{
				//remove from the collection
				Invoices.Remove(invoice);
				View.UpdateInterface();
			};
			dl.BeginDelete(invoice);
		}

		public void CreateInvoice()
		{
			//chiede alla view di aprire la finestra di editing di un nuovo asset (se non si specificano 
			//parameteri viene sempre creato un nuovo asset)
			EditInvoice(null);
		}

      public void EditInvoice(Invoice invoice)
		{
			if (invoice != null)
				invoice = invoice.DeepClone() as Invoice;
			(View as IManageInvoicesView).ShowEditInvoice(invoice);
		}
	}
}
