﻿using Structura.Infrastructure.ViewModel;
using TestApp.Entities;
using TestApp.Infrastructure;
using System;

namespace TestApp.Silverlight.InvoiceModule.Controller
{
   public class EditClientController : ControllerExt
   {
      private Client _Client;
      public Client Client
      {
         get { return _Client; }
         set { innerSet(ref _Client, value, "Client"); }
      }

      /// <summary>
      /// initialize the controller, create a new client if null is passed in
      /// </summary>
      /// <param name="client"></param>
      public void Init(Client client)
      {
         if (client == null)
         {
            client = new Client();
            client.CustomerId = IOC.GetAppSettings().CustomerId;
            client.ClientId = Guid.NewGuid();
         }
         Client = client;
      }

      /// <summary>
      /// starts a request to save the data
      /// </summary>
      public void SaveAsync()
      {
         IDataLayer dl = IOC.Resolve<IDataLayer>(RegisteredTypes.DataLayer);
         dl.SaveCompleted += (sender, e) =>
         {
            Client = e.Result as Client;
            View.UpdateInterface();
         };
         dl.BeginSave(Client);
      }

   }
}
