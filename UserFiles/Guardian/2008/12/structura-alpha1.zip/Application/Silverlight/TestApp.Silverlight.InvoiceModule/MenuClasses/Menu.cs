﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TestApp.Infrastructure;
using Structura.Silverlight.Controls.Windows;
using Structura.Infrastructure.IOC;

namespace TestApp.Silverlight.InvoiceModule
{
	public class MenuManageClients : TestApp.Infrastructure.IExecutable
	{
		public MenuManageClients(IIoC ioc)
		{
			_ioc = ioc;
		}
		
		private IIoC _ioc;
		#region IExecutable Members

		public object Execute()
		{
			return new View.ManageClients(_ioc);
		}

		#endregion
	}

	public class MenuManageInvoices : TestApp.Infrastructure.IExecutable
	{
      public MenuManageInvoices(IIoC ioc)
		{
			_ioc = ioc;
		}
		
		private IIoC _ioc;
		#region IExecutable Members

		public object Execute()
		{
			return new View.ManageInvoices(_ioc);
		}

		#endregion
	}
}
