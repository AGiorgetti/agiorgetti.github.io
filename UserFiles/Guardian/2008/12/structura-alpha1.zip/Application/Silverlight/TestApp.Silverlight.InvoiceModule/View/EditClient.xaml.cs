﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TestApp.Silverlight.Extensions.Views;
using Structura.Infrastructure.IOC;
using TestApp.Silverlight.InvoiceModule.Controller;
using TestApp.Entities;
using Structura.Silverlight.Controls.Windows;

namespace TestApp.Silverlight.InvoiceModule.View
{
   public partial class EditClient : ExtendedView
   {
      public EditClient(IIoC ioc) :
			base(ioc)
		{
         Controller = new EditClientController();

			InitializeComponent();

         // if it's programmatically created you have to call it before the binding are processed or they do not seem to work
         // Controller = new EditClientController();

			(Controller as EditClientController).Init(null);
			//we want default scrollbars for this form
			this.LayoutUpdated += new EventHandler(EditClient_LayoutUpdated);
		}

      public EditClient(IIoC ioc, Client client) :
			base(ioc)
		{
         Controller = new EditClientController();

			InitializeComponent();
         
         // if it's programmatically created you have to call it before the binding are processed or they do not seem to work
         // Controller = new EditClientController();

         (Controller as EditClientController).Init(client);
			//we want default scrollbars for this form
         this.LayoutUpdated += new EventHandler(EditClient_LayoutUpdated);
		}

		void EditClient_LayoutUpdated(object sender, EventArgs e)
		{
			Window w = Parent as Window;
			w.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
			w.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
			//let's call this method once
         this.LayoutUpdated -= EditClient_LayoutUpdated;
		}

		private void btnSave_Click(object sender, RoutedEventArgs e)
		{
			Waiting.Start();
         (Controller as EditClientController).SaveAsync();
		}

		private void btnCancel_Click(object sender, RoutedEventArgs e)
		{
			Close();
		}

		public override void UpdateInterface()
		{
			Waiting.Stop();
		}
   }
}
