﻿using Structura.Infrastructure.ViewModel;
using TestApp.Entities;
using TestApp.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;

namespace TestApp.Silverlight.InvoiceModule.Controller
{
   public class EditInvoiceController : ControllerExt
   {
      private Invoice _Invoice;
      public Invoice Invoice
      {
         get { return _Invoice; }
         set { innerSet(ref _Invoice, value, "Invoice"); }
      }
         
      private List<Client> _Clients;
      public List<Client> Clients
      {
         get { return _Clients; }
         set { innerSet<List<Client>>(ref _Clients, value, "Clients"); }
      }

      /// <summary>
      /// initialize the controller, create a new client if null is passed in
      /// </summary>
      /// <param name="client"></param>
      public void Init(Invoice invoice)
      {
         // get the data to initialize the form (like the list of clients)
         // after we got the clients we can init the form.
         IDataLayer dl = IOC.Resolve<IDataLayer>(RegisteredTypes.DataLayer);
         dl.GetAllClientsCompleted += (sender, e) =>
            {
               Clients = e.Result.ToList();
               if (invoice == null)
               {
                  invoice = new Invoice();
                  invoice.CustomerId = IOC.GetAppSettings().CustomerId;
                  invoice.Date = DateTime.Now;
               }
               Invoice = invoice;
               View.UpdateInterface();
            };
         dl.GetAllClientsAsync(IOC.GetAppSettings().CustomerId);
      }

      /// <summary>
      /// starts a request to save the data
      /// </summary>
      public void SaveAsync()
      {
         IDataLayer dl = IOC.Resolve<IDataLayer>(RegisteredTypes.DataLayer);
         dl.SaveCompleted += (sender, e) =>
         {
            Invoice = e.Result as Invoice;
            View.UpdateInterface();
         };
         dl.BeginSave(Invoice);
      }

      public void AddInvoiceItem()
      {
         InvoiceItem ii = new InvoiceItem();
         ii.Name = "(empty)";
         ii.Code = "(empty)";
         Invoice.ItemsBindingCollection.Add(ii);
      }

      public void RemoveInvoiceItem(InvoiceItem item)
      {
         if (Invoice.ItemsBindingCollection.Contains(item))
            Invoice.ItemsBindingCollection.Remove(item);
      }

   }
}
