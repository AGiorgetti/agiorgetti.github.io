﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using Structura.Silverlight.Controls.FileUploader.FileUploaderServiceWCF;

namespace Structura.Silverlight.Controls.FileUploader
{
	/// <summary>
	/// contains info about the file to upload + methods to perform the upload using the 
	/// HttpHandler
	/// </summary>
	public class UploadFileInfoWCF : UploadFileInfo
	{
		UploaderServiceClient usClient = new UploaderServiceClient();

		public long ChunkSize = 4194304;

		private bool cancel;
		private bool remove;

		public UploadFileInfoWCF(FileInfo file) :
			base(file)
		{
			usClient.UploadDataChunkCompleted += new EventHandler<UploadDataChunkCompletedEventArgs>(usClient_UploadDataChunkCompleted);
			Status = FileUploadStatus.Pending;
		}

		public override void CancelUpload()
		{
			cancel = true;
		}

		public override void RemoveUpload()
		{
			cancel = true;
			remove = true;
			if (Status != FileUploadStatus.Uploading)
				Status = FileUploadStatus.Removed;
		}

		public override void Upload()
		{
			if (File == null)
				return;
			Status = FileUploadStatus.Uploading;
			cancel = false;

			CheckFileOnServer();
		}

		private void CheckFileOnServer()
		{
			usClient.GetBytesCompleted += new EventHandler<GetBytesCompletedEventArgs>(usClient_GetBytesCompleted);
			usClient.GetBytesAsync(Filename);
		}

		void usClient_GetBytesCompleted(object sender, GetBytesCompletedEventArgs e)
		{
			long lengthtemp = 0;
			if (e.Error == null)
				lengthtemp = e.Result;

			if (lengthtemp > 0)
			{
				MessageBoxResult result;
				if (lengthtemp == Length)
				{
					result = MessageBox.Show("File already exists, overwrite?", "Overwrite?", MessageBoxButton.OKCancel);
					if (result == MessageBoxResult.OK)
						lengthtemp = 0;
					else
					{
						BytesUploaded = Length;
						Status = FileUploadStatus.Complete;
						return;
					}
				}
				else
				{
					result = MessageBox.Show("File already exists, continue upload?", "Continue?", MessageBoxButton.OKCancel);
					if (result == MessageBoxResult.Cancel)
						lengthtemp = 0;
				}
			}

			UploadFileEx();
		}

		public void UploadFileEx()
		{
			Status = FileUploadStatus.Uploading;

			if (!cancel)
			{
				long chunkSize;
				if (Stream.Position > -1 && Stream.Position < Stream.Length)
				{
					bool append = (Stream.Position > 0);
					bool complete = false;

					if (Stream.Length - Stream.Position >= ChunkSize)
					{
						chunkSize = ChunkSize;
						complete = true;
					}
					else
						chunkSize = Stream.Length - Stream.Position;

					byte[] fileBytes = new byte[chunkSize];
					int byteCount = Stream.Read(fileBytes, 0, (int)chunkSize);

					//we can upload the data
					usClient.UploadDataChunkAsync(Filename, fileBytes, byteCount, append, complete);
				}
			}
			else
			{
				// handle cancel
				CloseStream();
				if (remove)
					Status = FileUploadStatus.Removed;
				else
					Status = FileUploadStatus.Canceled;
			}
		}

		void usClient_UploadDataChunkCompleted(object sender, UploadDataChunkCompletedEventArgs e)
		{
			if (e.Error == null)
			{
				// lets update the informations for the file, we use the taskid to get the fileinfo object
				BytesUploaded += (int)(e.Result);
				if (!IsUploadCompleted)
					UploadFileEx();
				else
				{
					// upload ended, lets close the stream
					CloseStream();
					Status = FileUploadStatus.Complete;
				}
			}
			else
			{
				// something bad happened, close the stream and report the error
				CloseStream();
				Status = FileUploadStatus.Failure;
				// System.Windows.Browser.HtmlPage.Window.Alert(e.Error.Message);
			}
		}
	}
}
