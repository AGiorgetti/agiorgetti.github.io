﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.ComponentModel;
using System.Threading;
using System.Collections.Generic;
using Structura.Utils;

namespace Structura.Silverlight.Controls.FileUploader
{
	/// <summary>
	/// contains all the informations about a file beeing uploaded
	/// this is not the best design on earth since this class contains both presentation properties
	/// and functions to operate on the files (that is: the stream handling)
	/// but the structure is simple enough anyway.
	/// </summary>
	public abstract class UploadFileInfo : INotifyPropertyChanged
	{
		private Guid mID;
		private long mBytesUploaded;
		private FileInfo mInfo;
		private Stream mStream = null;
		private long mLength;
		private FileUploadStatus mStatus = FileUploadStatus.Uploading;

		public UploadFileInfo(FileInfo fi)
		{
			mID = Guid.NewGuid();
			mInfo = fi;
			mStream = File.OpenRead();
			mLength = mStream.Length;
			mStream.Close();
			mStream = null;
		}

		public Guid ID
		{
			get { return mID; }
			set { mID = value; }
		}

		internal FileInfo File
		{
			get { return mInfo; }
		}

		public string Filename
		{
			get { return File.Name; }
		}

		internal Stream Stream
		{
			get
			{
				if (mStream == null)
					mStream = File.OpenRead();
				return mStream;
			}
		}

		public long Length
		{
			get { return mLength; }
		}

		public long BytesUploaded
		{
			get { return mBytesUploaded; }
			set
			{
				mBytesUploaded = value;
				OnPropertyChanged("BytesUploaded");
				OnPropertyChanged("UploadPercent");
				OnPropertyChanged("IsUploadCompleted");
			}
		}

		public bool IsUploadCompleted
		{
			get { return (mBytesUploaded == mLength); }
		}

		public int UploadPercent
		{
			get { return (int)((BytesUploaded * 100) / Length); }
		}

		public FileUploadStatus Status
		{
			get { return mStatus; }
			set
			{
				mStatus = value;
				OnPropertyChanged("Status");
				OnStatusChanged();
			}
		}

		protected void OnStatusChanged()
		{
			if (StatusChanged != null)
				StatusChanged(this, EventArgs.Empty);
		}

		public event EventHandler StatusChanged;

		public void CloseStream()
		{
			if (mStream != null)
			{
				mStream.Close();
				mStream.Dispose();
				mStream = null;
			}
		}

		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string propertyName)
		{
			//if (PropertyChanged != null)
			//   PropertyChanged(this, new PropertyChangedEventArgs(propName));

			if (String.IsNullOrEmpty(propertyName))
			{
				throw new ArgumentNullException("propertyName");
			}

			if (PropertyChanged == null)
			{
				return;
			}

			if (SynchronizationContext.Current != null)
			{
				SynchronizationContext.Current.Post(delegate(object state)
				{
					PropertyChanged(this, GetEventArgs(propertyName));
				}, null);
			}
			else
				UIThread.Run(() =>
				{
					PropertyChanged(this, GetEventArgs(propertyName));
				});

		}

		/// <summary>
		/// Get a PropertyChangedEventArgs instance fromt he dictionary or
		/// create a new one if not present
		/// </summary>
		/// <param name="propertyName">name of the property</param>
		/// <returns>Instance of the class</returns>
		private static PropertyChangedEventArgs GetEventArgs(string propertyName)
		{
			PropertyChangedEventArgs pe = null;
			if (_eventArgsMap.TryGetValue(propertyName, out pe) == false)
			{
				pe = new PropertyChangedEventArgs(propertyName);
				_eventArgsMap[propertyName] = pe;
			}

			return pe;
		}

		private static readonly Dictionary<string, PropertyChangedEventArgs> _eventArgsMap =
			 new Dictionary<string, PropertyChangedEventArgs>();

		#endregion

		public abstract void CancelUpload();

		public abstract void RemoveUpload();

		public abstract void Upload();
	}

	public enum FileUploadStatus
	{
		Pending = 0,
		Uploading = 1,
		Complete = 2,
		Failure = 3,
		Canceled = 4,
		Removed = 5
	}
}
