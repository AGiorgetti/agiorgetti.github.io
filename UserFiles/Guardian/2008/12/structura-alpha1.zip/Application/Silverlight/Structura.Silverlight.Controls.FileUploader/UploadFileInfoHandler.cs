﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;

namespace Structura.Silverlight.Controls.FileUploader
{
	/// <summary>
	/// contains info about the file to upload + methods to perform the upload using the 
	/// HttpHandler
	/// </summary>
	public class UploadFileInfoHandler : UploadFileInfo
	{
		public long ChunkSize = 4194304;

		public string UploadUrl { get; set; }

		private bool cancel;
		private bool remove;

		public UploadFileInfoHandler(FileInfo file) :
			base(file)
		{
			Status = FileUploadStatus.Pending;
		}

		public UploadFileInfoHandler(FileInfo file, string uploadUrl)
			: this(file)
		{
			UploadUrl = uploadUrl;
		}

		public override void CancelUpload()
		{
			cancel = true;
		}

		public override void RemoveUpload()
		{
			cancel = true;
			remove = true;
			if (Status != FileUploadStatus.Uploading)
				Status = FileUploadStatus.Removed;
		}

		public override void Upload()
		{
			if (File == null || string.IsNullOrEmpty(UploadUrl))
				return;
			Status = FileUploadStatus.Uploading;
			cancel = false;

			CheckFileOnServer();
		}

		private void CheckFileOnServer()
		{
			UriBuilder ub = new UriBuilder(UploadUrl);
			ub.Query = string.Format("{1}filename={0}&GetBytes=true", File.Name, string.IsNullOrEmpty(ub.Query) ? "" : ub.Query.Remove(0, 1) + "&");
			WebClient client = new WebClient();
			client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);
			client.DownloadStringAsync(ub.Uri);
		}

		void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
		{
			long lengthtemp = 0;
			if (!string.IsNullOrEmpty(e.Result))
			{
				lengthtemp = long.Parse(e.Result);
			}
			if (lengthtemp > 0)
			{
				MessageBoxResult result;
				if (lengthtemp == Length)
				{
					result = MessageBox.Show("File already exists, overwrite?", "Overwrite?", MessageBoxButton.OKCancel);
					if (result == MessageBoxResult.OK)
						lengthtemp = 0;
					else
					{
						BytesUploaded = Length;
						Status = FileUploadStatus.Complete;
						return;
					}
				}
				else
				{
					result = MessageBox.Show("File already exists, continue upload?", "Continue?", MessageBoxButton.OKCancel);
					if (result == MessageBoxResult.Cancel)
						lengthtemp = 0;
				}
			}

			UploadFileEx();
		}

		public void UploadFileEx()
		{
			Status = FileUploadStatus.Uploading;
			long temp = Length - BytesUploaded;

			UriBuilder ub = new UriBuilder(UploadUrl);
			bool complete = temp <= ChunkSize;
			ub.Query = string.Format("{3}filename={0}&StartByte={1}&Complete={2}", File.Name, BytesUploaded, complete, string.IsNullOrEmpty(ub.Query) ? "" : ub.Query.Remove(0, 1) + "&");

			HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(ub.Uri);
			webrequest.Method = "POST";
			webrequest.BeginGetRequestStream(new AsyncCallback(WriteCallback), webrequest);
		}

		private void WriteCallback(IAsyncResult asynchronousResult)
		{
			HttpWebRequest webrequest = (HttpWebRequest)asynchronousResult.AsyncState;
			// End the operation.
			Stream requestStream = webrequest.EndGetRequestStream(asynchronousResult);

			byte[] buffer = new Byte[4096];
			int bytesRead = 0;
			int tempTotal = 0;

			Stream fileStream = File.OpenRead();

			//using (FileStream fileStream = File.OpenRead())
			//{
			fileStream.Position = BytesUploaded;
			while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0 && tempTotal + bytesRead < ChunkSize && !cancel)
			{
				requestStream.Write(buffer, 0, bytesRead);
				requestStream.Flush();
				BytesUploaded += bytesRead;
				tempTotal += bytesRead;
			}
			//}

			// only close the stream if it came from the file, don't close resizestream so we don't have to resize it over again.
			fileStream.Close();
			requestStream.Close();
			webrequest.BeginGetResponse(new AsyncCallback(ReadCallback), webrequest);
		}

		private void ReadCallback(IAsyncResult asynchronousResult)
		{
			HttpWebRequest webrequest = (HttpWebRequest)asynchronousResult.AsyncState;
			HttpWebResponse response = (HttpWebResponse)webrequest.EndGetResponse(asynchronousResult);
			StreamReader reader = new StreamReader(response.GetResponseStream());

			string responsestring = reader.ReadToEnd();
			reader.Close();

			if (cancel)
			{
				if (remove)
					Status = FileUploadStatus.Removed;
				else
					Status = FileUploadStatus.Canceled;
			}
			else if (BytesUploaded < Length)
				UploadFileEx();
			else
			{
				Status = FileUploadStatus.Complete;
			}
		}
	}
}
