﻿using System;
using System.IO;
namespace Structura.Silverlight.Controls.FileUploader
{
	public interface IFileUploader
	{
		int ChunkSize { get; set; }
		System.Collections.ObjectModel.ObservableCollection<UploadFileInfo> Files { get; }
		// add a file to be uploaded
		void AddFile(FileInfo fi);
		// start uploading the files
		void Upload();
	}
}
