﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using Structura.Silverlight.Controls.FileUploader.FileUploaderService;
using System.Windows.Resources;
using System.Xml.Linq;
using System.Collections.Generic;

namespace Structura.Silverlight.Controls.FileUploader
{
	/// <summary>
	/// the main class that implements all the logic to read files locally and call the webserver that will store them in the 
	/// remote storage
	/// </summary>
	public class FileUploaderHandler : Structura.Silverlight.Controls.FileUploader.IFileUploader
	{
		int mChunkSize = 1048576;
		
		public int ChunkSize
		{
			get { return mChunkSize; }
			set { mChunkSize = value; }
		}

		public string UploadUrl { get; set; }

		public ObservableCollection<UploadFileInfo> Files
		{
			get { return mFiles; }
		}
		private ObservableCollection<UploadFileInfo> mFiles = new ObservableCollection<UploadFileInfo>();

		public FileUploaderHandler()
		{
			StreamResourceInfo sri = Application.GetResourceStream(new Uri("FileService.ClientConfig", UriKind.Relative));
			if (sri != null)
			{
				string config = new StreamReader(sri.Stream).ReadToEnd();
				XDocument doc = XDocument.Parse(config);
				//XNamespace ns = doc.Root.Attribute("xmlns").Value;
				UploadUrl = doc.Root.Element("FileUploaderHandler").Attribute("UploadUrl").Value;
			}
		}

		public FileUploaderHandler(string uploadUrl) :
			this()
		{
			UploadUrl = uploadUrl;
		}

		public FileUploaderHandler(int chunksizeinBytes)
			: this()
		{
			ChunkSize = chunksizeinBytes;
		}

		/// <summary>
		/// Add the file to the internal list and start uploading it
		/// </summary>
		/// <param name="fi"></param>
		public void AddFile(FileInfo fi)
		{
			if (string.IsNullOrEmpty(UploadUrl))
				throw new ArgumentNullException("UploadUrl not setted");
			UploadFileInfoHandler f = new UploadFileInfoHandler(fi, UploadUrl);
			f.ChunkSize = ChunkSize;
			// f.StatusChanged += new EventHandler(f_StatusChanged);
			mFiles.Add(f);
		}

		void f_StatusChanged(object sender, EventArgs e)
		{
			UploadFileInfoHandler f = sender as UploadFileInfoHandler;
			if (f.Status == FileUploadStatus.Complete)
				mFiles.Remove(f);
		}

		public void Upload()
		{
			foreach (UploadFileInfoHandler f in mFiles)
				if (f.Status != FileUploadStatus.Complete)
					f.Upload();
		}
	}
}
