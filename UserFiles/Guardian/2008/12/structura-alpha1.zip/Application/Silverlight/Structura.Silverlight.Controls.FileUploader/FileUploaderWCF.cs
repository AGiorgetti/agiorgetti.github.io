﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using Structura.Silverlight.Controls.FileUploader.FileUploaderServiceWCF;

namespace Structura.Silverlight.Controls.FileUploader
{
	/// <summary>
	/// the main class that implements all the logic to read files locally and call the webserver that will store them in the 
	/// remote storage
	/// </summary>
	public class FileUploaderWCF : Structura.Silverlight.Controls.FileUploader.IFileUploader
	{
		int mChunkSize = 1048576;
		// int mChunkSize = 4096;
		public int ChunkSize
		{
			get { return mChunkSize; }
			set { mChunkSize = value; }
		}

		public ObservableCollection<UploadFileInfo> Files
		{
			get { return mFiles; }
		}
		private ObservableCollection<UploadFileInfo> mFiles = new ObservableCollection<UploadFileInfo>();

		public FileUploaderWCF()
		{
		}

		public FileUploaderWCF(int chunksizeinBytes)
			: this()
		{
			ChunkSize = chunksizeinBytes;
		}

		/// <summary>
		/// Add the file to the internal list
		/// </summary>
		/// <param name="fi"></param>
		public void AddFile(FileInfo fi)
		{
			UploadFileInfoWCF f = new UploadFileInfoWCF(fi);
			f.ChunkSize = ChunkSize;
			mFiles.Add(f);
		}

		public void Upload()
		{
			foreach (UploadFileInfo f in mFiles)
				if (f.Status != FileUploadStatus.Complete)
					f.Upload();
		}

	}
}
