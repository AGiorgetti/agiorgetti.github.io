﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TestApp.TestModule1
{
	public class Module : TestApp.Infrastructure.ApplicationModule
	{
		public Module() :
			base(new Guid("A9018FE7-5BF7-4d42-98A4-627AD64DE697"),
				  "TestModule1",
				  System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString())
		{ }
	}
}
