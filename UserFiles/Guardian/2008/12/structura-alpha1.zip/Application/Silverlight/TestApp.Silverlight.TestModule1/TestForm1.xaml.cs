﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TestApp.TestModule1
{
	public partial class TestForm1 : UserControl
	{
		public TestForm1()
		{
			InitializeComponent();

			this.btnOK.Click += new RoutedEventHandler(btnOK_Click);
		}

		void btnOK_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Browser.HtmlPage.Window.Alert("clicked");
		}
	}
}
