﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TestApp.Infrastructure;
using Structura.Silverlight.Controls.Windows;
using Structura.Infrastructure.IOC;

namespace TestApp.TestModule1.MenuClasses
{
	public class Menu1 : TestApp.Infrastructure.IExecutable
	{
		public Menu1(IIoC ioc)
		{
			_ioc = ioc;
		}
		
		private IIoC _ioc;
		#region IExecutable Members

		public object Execute()
		{
			//System.Windows.Browser.HtmlPage.Window.Alert("TM1 Menu1 Clicked");
			//open the window getting a reference to the IWindowManager throught tht IoC
			
			//_ioc.BeginResolve<IWindowsManager>(null, (e) => {
			//   e.ShowWindow(new TestForm1(), "TIoC test", new Point(0,0));
			//});

			IWindowsManager wm = _ioc.Resolve<IWindowsManager>(null);
			wm.Show(new TestForm1(), "TIoC test", new Point(0,0));
			
			return null;
		}

		#endregion
	}

	public class Menu2 : TestApp.Infrastructure.IExecutable
	{
		#region IExecutable Members

		public object Execute()
		{
			//System.Windows.Browser.HtmlPage.Window.Alert("TM1 Menu2 Clicked");
			//return null;
			return new TestForm1();
		}

		#endregion
	}
}
