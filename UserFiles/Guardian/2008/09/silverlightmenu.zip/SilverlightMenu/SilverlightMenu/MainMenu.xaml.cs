﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightMenu
{
	/// <summary>
	/// The main menu bar, it contains Menu items, each Menu can contain some SubMenu items.
	/// 
	/// you can actually insert Menu elements only by code.
	/// </summary>
	public partial class MainMenu : UserControl
	{
		public MainMenu()
		{
			InitializeComponent();
		}
		
		public void AddMenu(Menu m)
		{
			MenuContainer.Children.Add(m);
		}
		
		public void RemoveMenu(Menu m)
		{
			MenuContainer.Children.Remove(m);
		}
	}
}
