﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightMenu
{
	/// <summary>
	/// Level 0  menu items
	/// 
	/// note: if the popup is defined in Xaml and it's named...it seems you cannot open 2 popups with the
	/// same name even if they are in different instances of the menu control,
	/// so I decided to try to create the control at runtime. this way it works.
	/// </summary>
	public partial class Menu : UserControl, IMenu
	{
		public Menu()
		{
			InitializeComponent();

			this.MenuButton.Click += new RoutedEventHandler(MenuButton_Click);
		}

		public Menu(string text) :
			this()
		{
			Text = text;
		}

		System.Windows.Controls.Primitives.Popup p;
		StackPanel pnl;
		PopupProvider pp = null;

		void MenuButton_Click(object sender, RoutedEventArgs e)
		{
			OnMenuClick();
		}

		/// <summary>
		/// add a submenu
		/// </summary>
		/// <param name="sm">the menu item to add</param>
		/// <remarks>
		/// internally it creates the stuctures to hold the submenu items only
		/// if they are actually added to the menu itself.
		/// it also will create the popup provider to handle open and close events
		/// </remarks>
		public void AddSubmenu(SubMenu sm)
		{
			if (p == null)
			{
				p = new System.Windows.Controls.Primitives.Popup();
				pnl = new StackPanel();
				p.Child = pnl;
				MenuLayout.Children.Add(p);
			}
			pnl.Children.Add(sm);
			sm.ParentMenu = this;
			EnablePopupProvider();
		}

		private void EnablePopupProvider()
		{
			if (pp == null)
				pp = new PopupProvider(MenuButton, MenuButton, p, pnl, Direction.Bottom);
		}

		private void DisablePopupProvider()
		{
			if (pp != null)
			{
				pp.Dispose();
				pp = null;
			}
		}

		/// <summary>
		/// Remove a menu from the list
		/// </summary>
		/// <param name="sm">the menu item to remove</param>
		/// <remarks>internally it will destroy the popup provider so we are sure that
		/// events for opening and closing a menu aren't triggered</remarks>
		public void RemoveSubmenu(SubMenu sm)
		{
			sm.ParentMenu = null;
			pnl.Children.Remove(sm);
			if (pnl.Children.Count == 0)
			{
				DisablePopupProvider();
			}
		}

		public string Text
		{
			get { return this.MenuButton.Content.ToString(); }
			set { this.MenuButton.Content = value; }
		}

		public bool IsEnabled
		{
			get { return this.MenuButton.IsEnabled; }
			set
			{
				this.MenuButton.IsEnabled = value;
				//this is not strictly needed if the menu control is implemented as a button
				//cause if the control is disabled no event will be fired
				if (value)
					EnablePopupProvider();
				else
					DisablePopupProvider();
			}
		}

		public event MenuClickEventHandler MenuClick;

		/// <summary>
		/// the click even is fired only if this menu do not have childrens
		/// </summary>
		private void OnMenuClick()
		{
			if (((pnl == null) || (pnl.Children.Count == 0)) && (MenuClick != null))
				MenuClick(this, new MenuClickEventArgs());
		}

		#region IMenu Members

		public void CloseMenuPopup()
		{
			if (pp != null)
				pp.BeginClosingPopup();
		}

		public IMenu ParentMenu { get; set; }

		#endregion
	}
}
