﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace CustomButtons
{
	public class CustomButton : Button, INotifyPropertyChanged
	{
		public CustomButton() : base()
		{
			this.DefaultStyleKey = typeof(CustomButton);
		}

		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			GradientStop gs = GetTemplateChild("EllipseBackGroundColor") as GradientStop;
			if (gs != null)
				gs.Color = BackgroundColor;
		}

		#region BackgroundColor

		/// <summary> 
		/// Gets or sets the BackgroundColor possible Value of the Color object.
		/// </summary> 
		public Color BackgroundColor
		{
			get { return (Color)GetValue(BackgroundColorProperty); }
			set { SetValue(BackgroundColorProperty, value); }
		}

		/// <summary> 
		/// Identifies the BackgroundColor dependency property.
		/// </summary> 
		public static readonly DependencyProperty BackgroundColorProperty =
						DependencyProperty.Register(
								"BackgroundColor",
								typeof(Color),
								typeof(CustomButton),
								new PropertyMetadata(OnBackgroundColorPropertyChanged));

		/// <summary>
		/// BackgroundColorProperty property changed handler. 
		/// </summary>
		/// <param name="d">CustomButton that changed its BackgroundColor.</param>
		/// <param name="e">DependencyPropertyChangedEventArgs.</param> 
		private static void OnBackgroundColorPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			CustomButton _CustomButton = d as CustomButton;
			if (_CustomButton != null)
			{
				OnPropertyChanged(_CustomButton, "BackgroundColor");
			}
		}
		#endregion BackgroundColor

		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;
		
		private static void OnPropertyChanged(CustomButton btn, string propertyName)
		{
			if (btn.PropertyChanged != null)
				btn.PropertyChanged(btn, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
		}

		#endregion
	}
}
