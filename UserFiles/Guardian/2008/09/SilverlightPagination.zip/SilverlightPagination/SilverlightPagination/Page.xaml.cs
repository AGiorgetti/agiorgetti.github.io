﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightPagination
{
	public partial class Page : UserControl
	{
		public Page()
		{
			InitializeComponent();

			this.Loaded += new RoutedEventHandler(Page_Loaded);
		}

		void Page_Loaded(object sender, RoutedEventArgs e)
		{
			GridPager.LinkedControl = DisplayGrid;
			GridPager.SetPager(new Pager<Data>(BuildData()));
			ItemsControlPager.LinkedControl = DisplayItemsControl;
			ItemsControlPager.SetPager(new Pager<Data>(BuildData()));
		}

		public List<Data> BuildData()
		{
			List<Data> list = new List<Data>();
			for (int i = 0; i < 10; i++)
				for (int j = 0; j < 10; j++)
					list.Add(new Data()
					{
						Name = "Test_" + i.ToString() + "_" + j.ToString(),
						Surname = "Test_" + i.ToString() + "_" + j.ToString()
					});

			return list;
		}
	}

	public class Data
	{
		public string Name { get; set; }
		public string Surname { get; set; }
	}
}
