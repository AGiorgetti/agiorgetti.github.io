﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;

namespace SilverlightPagination
{
	/// <summary>
	/// Generic functions exposed by the view, the actual implementation
	/// of this interface will be based on a list class to hold also the 
	/// data of the view.
	/// </summary>
	public interface IPagedList : System.Collections.IList
	{
		/// <summary>
		/// total number of records
		/// </summary>
		int TotalCount { get; }

		/// <summary>
		/// index of the page represented by this view
		/// </summary>
		int PageIndex { get; }

		/// <summary>
		/// Size of the page
		/// </summary>
		int PageSize { get; }

		/// <summary>
		/// Total number of pages available
		/// </summary>
		int TotalPages { get; }

		/// <summary>
		/// do a previous page exists?
		/// </summary>
		bool IsPreviousPage { get; }

		/// <summary>
		/// do a next page exist?
		/// </summary>
		bool IsNextPage { get; }

		/// <summary>
		/// is this the first page?
		/// </summary>
		bool IsFirst { get; }

		/// <summary>
		/// is this the last page?
		/// </summary>
		bool IsLast { get; }
	}

	/// <summary>
	/// functions exposed by the pager, they will build a view over the data
	/// </summary>
	public interface IPager
	{
		IPagedList ToPageList(int index);

		IPagedList ToPageList(int index, int pagesize);
	}

	/// <summary>
	/// The physical implementatio of the view, it's based on a List<> to also hold the data
	/// the source can be a List of anything or the result of a Linq query.
	/// Page index is 0 based
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class PagedList<T> : List<T>, IPagedList
	{
		public PagedList(IQueryable<T> source, int index, int pageSize)
		{
			this._TotalCount = source.Count();
			this._PageSize = pageSize;
			this._PageIndex = index;
			this.AddRange(source.Skip(index * pageSize).Take(pageSize).ToList());
		}

		public PagedList(List<T> source, int index, int pageSize)
		{
			this._TotalCount = source.Count();
			this._PageSize = pageSize;
			this._PageIndex = index;
			this.AddRange(source.Skip(index * pageSize).Take(pageSize).ToList());
		}

		public int TotalCount
		{
			get { return _TotalCount; }
		}
		private int _TotalCount;

		public int PageIndex
		{
			get { return _PageIndex; }
		}
		private int _PageIndex;

		public int PageSize
		{
			get { return _PageSize; }
		}
		private int _PageSize;

		public int TotalPages
		{
			get { return (_TotalCount / _PageSize) + Math.Min(_TotalCount % _PageSize, 1); }
		}

		public bool IsPreviousPage
		{
			get
			{
				return (PageIndex > 0);
			}
		}

		public bool IsNextPage
		{
			get
			{
				return PageIndex < Math.Max(TotalPages - 1, 0);
			}
		}

		public bool IsFirst
		{
			get
			{
				return PageIndex == 0;
			}
		}

		public bool IsLast
		{
			get
			{
				return PageIndex == Math.Max(TotalPages - 1, 0);
			}
		}
	}

	public static class Pagination
	{
		public static PagedList<T> ToPagedList<T>(IQueryable<T> source, int index, int pageSize)
		{
			return new PagedList<T>(source, index, pageSize);
		}

		public static PagedList<T> ToPagedList<T>(IQueryable<T> source, int index)
		{
			return new PagedList<T>(source, index, 10);
		}

		public static PagedList<T> ToPagedList<T>(List<T> source, int index, int pageSize)
		{
			return new PagedList<T>(source, index, pageSize);
		}

		public static PagedList<T> ToPagedList<T>(List<T> source, int index)
		{
			return new PagedList<T>(source, index, 10);
		}
	}

	/// <summary>
	/// extremely simple implementation of the pager, 
	/// given a list of data or a Linq query
	/// this class will build a series of views over it
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class Pager<T> : IPager
	{
		public Pager(List<T> source)
		{
			lSource = source;
		}
		private List<T> lSource;

		public Pager(IQueryable<T> source)
		{
			qSource = source;
		}
		private IQueryable<T> qSource;

		private const int DefaultPageSize = 10;

		public IPagedList ToPageList(int index)
		{
			if (lSource != null)
				return new PagedList<T>(lSource, index, DefaultPageSize);

			return new PagedList<T>(qSource, index, DefaultPageSize);
		}

		public IPagedList ToPageList(int index, int pagesize)
		{
			if (pagesize <= 0)
				pagesize = DefaultPageSize;

			if (lSource != null)
				return new PagedList<T>(lSource, index, pagesize);

			return new PagedList<T>(qSource, index, pagesize);
		}
	}
}
