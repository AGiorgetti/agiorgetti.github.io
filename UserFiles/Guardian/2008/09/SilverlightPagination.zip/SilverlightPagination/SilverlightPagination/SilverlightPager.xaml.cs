﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Reflection;
using System.Collections;
using System.ComponentModel;

namespace SilverlightPagination
{
	public partial class SilverlightPager : UserControl
	{
		public SilverlightPager()
		{
			InitializeComponent();
		}

		/// <summary>
		/// the pager used as  datasource
		/// </summary>
		public void SetPager(IPager source)
		{
			_Source = source;
			GetDataAndBuildPager();
		}
		private IPager _Source;

		#region Linked Control

		/// <summary> 
		/// Gets or sets the LinkedControl possible Value of the Control object.
		/// </summary> 
		public System.Windows.Controls.Control LinkedControl
		{
			get { return (System.Windows.Controls.Control)GetValue(LinkedControlProperty); }
			set
			{
				//check if the control supports the items source property
				_itemsSource = value.GetType().GetProperty("ItemsSource");
				if (_itemsSource == null)
					throw new ArgumentException("ItemsSource not supported");
				SetValue(LinkedControlProperty, value);
			}
		}

		/// <summary> 
		/// Identifies the LinkedControl dependency property.
		/// </summary> 
		public static readonly DependencyProperty LinkedControlProperty =
						DependencyProperty.Register(
								"LinkedControl",
								typeof(System.Windows.Controls.Control),
								typeof(SilverlightPager),
								new PropertyMetadata(null));

		private PropertyInfo _itemsSource;

		private void SetItemsSource(IEnumerable list)
		{
			if (LinkedControl != null)
				_itemsSource.SetValue(LinkedControl, list, null);
		}

		#endregion

		#region "Display Properties"

		/// <summary> 
		/// Gets or sets the PagerButtonStyle possible Value of the Style object.
		/// </summary> 
		public Style PagerButtonStyle
		{
			get { return (Style)GetValue(PagerButtonStyleProperty); }
			set { SetValue(PagerButtonStyleProperty, value); }
		}

		// Using a DependencyProperty as the backing store for PagerButtonStyle.  This enables animation, styling, binding, etc...
		public static readonly DependencyProperty PagerButtonStyleProperty =
			 DependencyProperty.Register("PagerButtonStyle", typeof(Style), typeof(SilverlightPager), new PropertyMetadata(null));


		/// <summary> 
		/// Gets or sets the PagerSelectedButtonStyle possible Value of the Style object.
		/// </summary> 
		public Style PagerSelectedButtonStyle
		{
			get { return (Style)GetValue(PagerSelectedButtonStyleProperty); }
			set { SetValue(PagerSelectedButtonStyleProperty, value); }
		}

		/// <summary> 
		/// Identifies the PagerSelectedButtonStyle dependency property.
		/// </summary> 
		public static readonly DependencyProperty PagerSelectedButtonStyleProperty =
						DependencyProperty.Register(
								"PagerSelectedButtonStyle",
								typeof(Style),
								typeof(SilverlightPager),
								new PropertyMetadata(null));


		/// <summary> 
		/// Gets or sets the PageSize possible Value of the int object.
		/// </summary> 
		public int PageSize
		{
			get { return (int)GetValue(PageSizeProperty); }
			set { SetValue(PageSizeProperty, value); }
		}

		/// <summary> 
		/// Identifies the PageSize dependency property.
		/// </summary> 
		public static readonly DependencyProperty PageSizeProperty =
						DependencyProperty.Register(
								"PageSize",
								typeof(int),
								typeof(SilverlightPager),
								new PropertyMetadata(null));

		/// <summary>
		/// max interval of pages to display in the pager
		/// </summary>
		public int PageInterval { set { _PageInterval = value; } get { return _PageInterval; } }
		private int _PageInterval = 5;

		private void SetButtonStyle(Button ctrl, Style style)
		{
			if (style != null)
				ctrl.Style = style;
		}

		#endregion

		#region Core drawing routines

		/// <summary>
		/// the current page index, each button will have the next page index setted in the Tag property
		/// remember that the pager works with a 0 based index
		/// </summary>
		private int _CurrentPageIndex = 0;

		public int CurrentPageIndex
		{
			get { return _CurrentPageIndex + 1; }
			set
			{
				_CurrentPageIndex = Math.Max(value - 1, 0);
				GetDataAndBuildPager();
			}
		}

		/// <summary>
		/// buildup the pager aligning the buttons
		/// </summary>
		private void GetDataAndBuildPager()
		{
			if (_Source == null)
				throw new ArgumentException("No pager setted");
			//Get the page data
			IPagedList page = _Source.ToPageList(_CurrentPageIndex, PageSize);
			//Build the layout
			LayoutRoot.Children.Clear();
			//First button
			Button b = new Button();
			b.Tag = 0;
			b.IsEnabled = !page.IsFirst;
			b.Content = "<<";
			b.Click += new RoutedEventHandler(b_Click);
			SetButtonStyle(b, PagerButtonStyle);
			LayoutRoot.Children.Add(b);
			//Prev button
			b = new Button();
			b.Tag = _CurrentPageIndex - 1;
			b.IsEnabled = page.IsPreviousPage;
			b.Content = "<";
			b.Click += new RoutedEventHandler(b_Click);
			SetButtonStyle(b, PagerButtonStyle);
			LayoutRoot.Children.Add(b);
			for (int i = Math.Max(0, _CurrentPageIndex - PageInterval); i <= Math.Min(page.TotalPages, _CurrentPageIndex + PageInterval)-1; i++)
			{
				b = new Button();
				b.Tag = i;
				b.Content = (i + 1).ToString();
				b.IsEnabled = true;
				LayoutRoot.Children.Add(b);
				if ((i == page.PageIndex) && (PagerSelectedButtonStyle != null))
					SetButtonStyle(b, PagerSelectedButtonStyle);
				else
				{
					b.Click += new RoutedEventHandler(b_Click);
					SetButtonStyle(b, PagerButtonStyle);
				}

			}
			//Next Button
			b = new Button();
			b.Tag = _CurrentPageIndex + 1;
			b.IsEnabled = page.IsNextPage;
			b.Content = ">";
			b.Click += new RoutedEventHandler(b_Click);
			SetButtonStyle(b, PagerButtonStyle);
			LayoutRoot.Children.Add(b);
			//Last Button
			b = new Button();
			b.Tag = page.TotalPages;
			b.IsEnabled = !page.IsLast;
			b.Content = ">>";
			b.Click += new RoutedEventHandler(b_Click);
			SetButtonStyle(b, PagerButtonStyle);
			LayoutRoot.Children.Add(b);

			//update the linked control
			SetItemsSource(page);
		}

		void b_Click(object sender, RoutedEventArgs e)
		{
			//set the new current page
			_CurrentPageIndex = (int)(((Button)sender).Tag);
			GetDataAndBuildPager();
		}

		#endregion
	}
}
