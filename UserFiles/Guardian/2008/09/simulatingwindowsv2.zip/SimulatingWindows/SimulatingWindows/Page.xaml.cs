﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SimulatingWindows
{
	public partial class Page : UserControl
	{
		public Page()
		{
			InitializeComponent();
			this.Loaded += new RoutedEventHandler(Page_Loaded);
		}

		void Page_Loaded(object sender, RoutedEventArgs e)
		{
			wm = new WindowsManager(LayoutRoot);
			
			this.btn.Click += new RoutedEventHandler(btn_Click);
			wm.ShowWindow(new TestStyle(), "Test 1", new Point(100,100));
		}

		int i = 0;
			
		void btn_Click(object sender, RoutedEventArgs e)
		{
			i++;
			wm.ShowWindow(new WindowContent(), "Windows " + i.ToString(), new Point(100, 100));
		}
		
		private WindowsManager wm = null;
	}
}
