﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SimulatingWindows
{
	public class Window : ContentControl
	{
		private FrameworkElement captionBar = null;
		private Grid window = null;
		private TextBlock captionText;

		public Window()
		{
			this.DefaultStyleKey = typeof(Window);
		}

		/// <summary>
		/// Gets called once the template is applied
		/// </summary>
		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();

			window = GetTemplateChild("PART_Window") as Grid;

			captionBar = GetTemplateChild("PART_CaptionBar") as FrameworkElement;

			captionText = GetTemplateChild("PART_CaptionText") as TextBlock;
			captionText.Text = _Caption;

			Button closeButton = GetTemplateChild("PART_CloseButton") as Button;
			if (closeButton != null)
				closeButton.Click += new RoutedEventHandler(closeButton_Click);

			DefineDragEvents();
			DefineResizeEvents();

			Canvas.SetZIndex(this, currentZIndex);
		}

		public event EventHandler Closed;

		public void Close()
		{
			this.Visibility = Visibility.Collapsed;
			//raise the closed event
			if (Closed != null)
				Closed(this, EventArgs.Empty);
		}

		void closeButton_Click(object sender, RoutedEventArgs e)
		{
			Close();
		}

		#region Properties

		/// <summary>
		/// Sets whether dragging is enable
		/// </summary>
		public bool DraggingEnabled { get { return _DraggingEnabled; } set { _DraggingEnabled = value; } }
		private bool _DraggingEnabled = true;

		public bool ResizeEnabled { get { return _ResizeEnabled; } set { _ResizeEnabled = value; } }
		private bool _ResizeEnabled = true;

		/// <summary>
		/// this property accesses and set and internal member of the template
		/// used top draw the title of the window, it may happen that you want to get or set
		/// this property before the template is actually loaded, so you have to
		/// bufferize the value and apply it later in the OnApplyTemplate function
		/// </summary>
		public string Caption
		{
			get { return (captionText != null) ? captionText.Text : _Caption; }
			set
			{
				if (captionText != null)
					captionText.Text = value;
				else
					_Caption = value;
			}
		}
		private string _Caption = "";

		#endregion

		#region Dragging Functions

		private bool isDragging = false;
		private Point initialWindowLocation;
		private Point initialDragPoint;
		private static int currentZIndex = 1;

		private void DefineDragEvents()
		{
			if (captionBar != null)
			{
				captionBar.MouseLeftButtonDown +=
					 new MouseButtonEventHandler(captionBar_MouseLeftButtonDown);
				captionBar.MouseMove +=
					new MouseEventHandler(captionBar_MouseMove);
				captionBar.MouseLeftButtonUp +=
					 new MouseButtonEventHandler(captionBar_MouseLeftButtonUp);
			}
		}

		/// <summary>
		/// Fires when the left mouse button goes down on the caption bar
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void captionBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if (DraggingEnabled)
			{
				// Bring the panel to the front
				Canvas.SetZIndex(this, currentZIndex++);
				// Capture the mouse
				((FrameworkElement)sender).CaptureMouse();
				// Store the start position
				this.initialDragPoint = e.GetPosition(this.Parent as UIElement);
				this.initialWindowLocation.X = Canvas.GetLeft(this);
				this.initialWindowLocation.Y = Canvas.GetTop(this);
				// Set dragging to true
				this.isDragging = true;
			}
		}

		/// <summary>
		/// Fires when the left mouse button goes up on the caption bar
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void captionBar_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (DraggingEnabled)
			{
				// Release the mouse
				((FrameworkElement)sender).ReleaseMouseCapture();
				// Set dragging to false
				isDragging = false;
			}
		}

		/// <summary>
		/// Fires when the mouse moves on the caption bar
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void captionBar_MouseMove(object sender, MouseEventArgs e)
		{
			if (this.isDragging)
			{
				Point position = e.GetPosition(this.Parent as UIElement);
				Canvas c = this.Parent as Canvas;
				// Move the panel
				double X = initialWindowLocation.X + position.X - initialDragPoint.X;
				if ((X >= 0) && (X + captionBar.ActualWidth <= c.ActualWidth))
					Canvas.SetLeft(this, X);
				double Y = initialWindowLocation.Y + position.Y - initialDragPoint.Y;
				if ((Y >= 0) && (Y + captionBar.ActualHeight <= c.ActualHeight))
					Canvas.SetTop(this, Y);
			}
		}

		#endregion

		#region Resize Functions

		private const int HotSpotWidth = 2;
		private bool isResizing = false;
		private ResizeAnchor resizeAnchor = ResizeAnchor.None;
		private Point initialResizePoint;
		private Size initialWindowSize;
		private const int MinWindowWidth = 60;

		private enum ResizeAnchor
		{
			None,
			Left,
			Top,
			Right,
			Bottom
		}

		private void DefineResizeEvents()
		{
			if (window != null)
			{
				window.MouseLeftButtonDown += new MouseButtonEventHandler(window_MouseLeftButtonDown);
				window.MouseMove += new MouseEventHandler(window_MouseMove);
				window.MouseLeftButtonUp += new MouseButtonEventHandler(window_MouseLeftButtonUp);
			}
		}

		void window_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if ((ResizeEnabled) && (isResizing))
			{
				// Release the mouse
				((FrameworkElement)sender).ReleaseMouseCapture();
				// Set resizing to false
				isResizing = false;
			}
		}

		void window_MouseMove(object sender, MouseEventArgs e)
		{
			if (ResizeEnabled)
			{
				Point pos = e.GetPosition(window);
				if (!isResizing)
				{
					if (pos.Y <= HotSpotWidth)
					{
						window.Cursor = Cursors.SizeNS;
						resizeAnchor = ResizeAnchor.Top;
					}
					else if (pos.Y >= (window.ActualHeight - HotSpotWidth))
					{
						window.Cursor = Cursors.SizeNS;
						resizeAnchor = ResizeAnchor.Bottom;
					}
					else if (pos.X <= HotSpotWidth)
					{
						window.Cursor = Cursors.SizeWE;
						resizeAnchor = ResizeAnchor.Left;
					}
					else if (pos.X >= (window.ActualWidth - HotSpotWidth))
					{
						window.Cursor = Cursors.SizeWE;
						resizeAnchor = ResizeAnchor.Right;
					}
					else if (Cursor != Cursors.Hand)
					{
						window.Cursor = Cursors.Hand;
						resizeAnchor = ResizeAnchor.None;
					}
				}
				else
				{
					Point position = e.GetPosition(this.Parent as UIElement);

					double deltaX = position.X - initialResizePoint.X;
					double deltaY = position.Y - initialResizePoint.Y;

					switch (resizeAnchor)
					{
						case ResizeAnchor.Left:
							//fix to avoid to move the windows when we reached the minimal width resizing from the left
							double MaxX = initialWindowLocation.X + this.initialWindowSize.Width - MinWindowWidth;
							Canvas.SetLeft(this, Math.Min(initialResizePoint.X + deltaX, MaxX));
							this.Width = Math.Max(initialWindowSize.Width - deltaX, MinWindowWidth);
							break;
						case ResizeAnchor.Top:
							double MaxY = initialWindowLocation.Y + this.initialWindowSize.Height - captionBar.ActualHeight;
							Canvas.SetTop(this, Math.Min(initialResizePoint.Y + deltaY, MaxY));
							this.Height = Math.Max(initialWindowSize.Height - deltaY, captionBar.ActualHeight);
							break;
						case ResizeAnchor.Right:
							this.Width = Math.Max(initialWindowSize.Width + deltaX, MinWindowWidth);
							break;
						case ResizeAnchor.Bottom:
							this.Height = Math.Max(initialWindowSize.Height + deltaY, captionBar.ActualHeight);
							break;
					}
				}
			}
		}

		private bool CanResize
		{
			get { return ((ResizeEnabled) && (resizeAnchor != ResizeAnchor.None)); }
		}

		void window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			if ((ResizeEnabled) && (CanResize))
			{
				// Capture the mouse
				((FrameworkElement)sender).CaptureMouse();
				// Store the start position
				this.initialResizePoint = e.GetPosition(this.Parent as UIElement);
				initialWindowSize.Width = (!double.IsNaN(this.Width) ? this.Width : this.ActualWidth);
				initialWindowSize.Height = (!double.IsNaN(this.Height) ? this.Height : this.ActualHeight);
				this.initialWindowLocation.X = Canvas.GetLeft(this);
				this.initialWindowLocation.Y = Canvas.GetTop(this);
				// Set resizing to true
				this.isResizing = true;
			}
		}

		#endregion
	}
}
