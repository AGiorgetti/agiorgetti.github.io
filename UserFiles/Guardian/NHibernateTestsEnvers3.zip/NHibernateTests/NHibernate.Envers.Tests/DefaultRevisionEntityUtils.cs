﻿using System;
using System.Collections.Generic;

namespace NHibernate.Envers.Tests
{
	public class DefaultRevisionEntityUtils
	{
		public static void PrintRevisionInfo(DefaultRevisionEntity rev)
		{
			Console.WriteLine("Rev: {0} {1:o}", rev.Id, rev.RevisionDate);
		}

		public static void PrintRevisionInfos(IEnumerable<DefaultRevisionEntity> revs)
		{
			foreach (var rev in revs)
				PrintRevisionInfo(rev);
		}
	}
}