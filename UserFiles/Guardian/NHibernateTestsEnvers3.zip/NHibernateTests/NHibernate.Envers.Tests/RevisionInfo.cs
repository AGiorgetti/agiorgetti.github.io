﻿using System;

namespace NHibernate.Envers.Tests
{
	/// <summary>
	/// A convenient way to show Revision/Histoty data, thay are returned as array of objects otherwise
	/// </summary>
	/// <typeparam name="TId">The type of the id.</typeparam>
	/// <typeparam name="TTimestamp">The type of the timestamp.</typeparam>
	/// <typeparam name="T"></typeparam>
	public class RevisionInfo<TId, TTimestamp, T> where T : class
	{
		public RevisionInfo(TId revisionId, TTimestamp timestamp, RevisionType operation, T entityRevision)
		{
			Entity = entityRevision;
			Operation = operation;
			RevisionId = revisionId;
			Timestamp = timestamp;
		}

		public TId RevisionId { get; private set; }
		public TTimestamp Timestamp { get; private set; }
		public RevisionType Operation { get; private set; }
		public T Entity { get; private set; }
	}

	/// <summary>
	/// Specific class for CustomRevInfoSample
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class RevisionInfo<T> : RevisionInfo<long, DateTime, T> where T : class
	{
		public RevisionInfo(T entityRevision, RevisionType operation, long revisionId, DateTime timestamp) : 
			base(revisionId, timestamp, operation, entityRevision)
		{
		}
	}
}
