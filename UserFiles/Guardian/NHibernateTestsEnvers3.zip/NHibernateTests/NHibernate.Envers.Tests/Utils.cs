﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using NHibernate.Envers.Query;

namespace NHibernate.Envers.Tests
{
	public class Utils
	{
		public static IEnumerable<RevisionInfo<T>> ToRevisionInfo<T>(IList results) where T : class
		{
			foreach (var item in results)
			{
				var result = item as object[];
				var defaultRevisionEntity = (DefaultRevisionEntity)(result[1]);
				yield return new RevisionInfo<T>(result[0] as T, (RevisionType)result[2], defaultRevisionEntity.Id, defaultRevisionEntity.RevisionDate);
			}
		}

		public static void PrintAuditRevisionInfo<T>(ISessionFactory sf) where T : class
		{
			using (ISession s = sf.OpenSession())
			{
				using (ITransaction tx = s.BeginTransaction())
				{
					IAuditReader auditer = s.Auditer();
					IList resultList = auditer.CreateQuery().ForRevisionsOfEntity(typeof(T), false, true).GetResultList();
					foreach (RevisionInfo<T> revInfo in ToRevisionInfo<T>(resultList))
					{
						Console.WriteLine("Rev={0} Timestamp={1:o} {2} {3}", revInfo.RevisionId, revInfo.Timestamp, revInfo.Operation, revInfo.Entity);
						Console.WriteLine("####");
					}
					tx.Commit();
				}
			}
			Console.WriteLine("---------------");
		}

		public static void PrintEntityList<T>(IEnumerable<T> list)
		{
			Console.WriteLine(string.Format("{0} , count: {1}", list.GetType(), list.Count()));
			foreach (var e in list)
			{
				Console.WriteLine(e.ToString());
			}
		}

		public static void PrintRevisionInfoList<TEntity, TRevisionEntity>(IEnumerable<IRevisionEntityInfo<TEntity,TRevisionEntity>> list) where TRevisionEntity : DefaultRevisionEntity
		{
			Console.WriteLine(string.Format("{0} , count: {1}", list.GetType(), list.Count()));
			foreach (var e in list)
			{
				Console.WriteLine("Rev={0} Timestamp={1:o} Op={2}\n{3}", e.RevisionEntity.Id, e.RevisionEntity.RevisionDate, e.Operation, e.Entity);
			}
		}
	}
}