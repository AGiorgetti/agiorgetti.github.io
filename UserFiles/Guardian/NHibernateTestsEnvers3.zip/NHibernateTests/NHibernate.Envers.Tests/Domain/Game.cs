﻿using NHibernateInitialization.Domain;

namespace NHibernate.Envers.Tests.Domain
{
	public class Game : Entity<int>
	{
		public string Name { get; set; }

		public string Type { get; set; }

		public int Rating { get; set; }

		public string Note { get; set; }

		public override string ToString()
		{
			return string.Format("Id: {3}, Name: {0}, Type: {1}, Rating: {2}, Note: {4}", Name, Type, Rating, Id, Note);
		}
	}
}