﻿using System;
using System.Collections.Generic;
using NHibernate.Envers.Exceptions;
using NHibernate.Envers.Query;
using NHibernate.Envers.Tests.Domain;
using NUnit.Framework;
using System.Linq;

namespace NHibernate.Envers.Tests.Querying
{
	[TestFixture]
	public class Test2
	{
		private NHinit _nh;

		[SetUp]
		public void FixtureSetup()
		{
			_nh = new NHinit();
			_nh.Initialize();
			_nh.InitializeAudit();
			_nh.CreateSchema();
			GenerateTestData();
		}

		[TearDown]
		public void FixtureTearDown()
		{
			_nh.DropSchema();
		}

		/// <summary>
		/// test if the data are created correcly
		/// </summary>
		[Test]
		public void AlwaysPass()
		{
			Assert.IsTrue(true);
		}

		private void GenerateTestData()
		{
			// assuming an empty database
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				Person p;
				Person p2; 
				using (var tx = s.BeginTransaction())
				{
					// create some games
					List<Game> games = new List<Game>();
					for(int i = 0; i< 5; ++i)
					{
						Game g = new Game();
						g.Name = "g" + i;
						g.Note = "note" + i;
						g.Rating = i;
						s.SaveOrUpdate(g);
						games.Add(g);
					}
					// create a person
					p = new Person("Jhon", "Doe");
					p.Games.Add(games[0]);
					p.Games.Add(games[1]);
					s.SaveOrUpdate(p);

					p2 = new Person("Jane", "Doe");
					p2.Games.Add(games[1]);
					p2.Games.Add(games[2]);
					s.SaveOrUpdate(p2);
					tx.Commit();
				}
				// update some data
				using (var tx = s.BeginTransaction())
				{
					
					// create a person
					p.Note = "Modified";
					s.SaveOrUpdate(p);

					p2.Note = "Modified";
					s.SaveOrUpdate(p2);
					tx.Commit();
				}
			}
		}

		/// <summary>
		/// Shows all the entities at a given revision
		/// </summary>
		[Test]
		public void ForEntitiesAtRevision()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var rev = auditReader.CreateQuery().ForEntitiesAtRevision<Person>(1).Results();
					Assert.IsNotNull(rev);
					Assert.That(rev.Count() == 2);
					// print the data on the console
					Utils.PrintEntityList(rev);
					tx.Commit();
				}
			}
		}

		[Test]
		public void ForRevisionsOf()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var rev = auditReader.CreateQuery().ForRevisionsOf<Person>(true).Results();
					Assert.IsNotNull(rev);
					Utils.PrintEntityList(rev);
					tx.Commit();
				}
			}
		}

		[Test]
		public void ForEntitiesAtRevision_Filter()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var rev = auditReader.CreateQuery().ForEntitiesAtRevision<Person>(1)
						.Add(AuditEntity.Property("Name").Eq("Jhon")).Results();
					Assert.IsNotNull(rev);
					Assert.That(rev.Count() == 1);
					// print the data on the console
					Utils.PrintEntityList(rev);
					tx.Commit();
				}
			}
		}

		[Test]
		public void ForHistoryOf()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var rev = auditReader.CreateQuery().ForHistoryOf<Person>(true).Results();
					Assert.IsNotNull(rev);
					Utils.PrintRevisionInfoList(rev);
					tx.Commit();
				}
			}
		}
	}
}