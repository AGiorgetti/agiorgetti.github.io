﻿using NHibernate.Cfg;
using NHibernate.Envers.Tests.Domain;
using NHibernateInitialization;

namespace NHibernate.Envers.Tests.Querying
{
	public class NHinit : NHibernateInitializer
	{
		protected override void ConfOrmMapping(ConfOrm.ObjectRelationalMapper orm, ConfOrm.NH.Mapper mapper)
		{
			orm.TablePerClass<Person>();
			orm.TablePerClass<Game>();
		}

		public void InitializeAudit()
		{
			var enversConf = new NHibernate.Envers.Configuration.Fluent.FluentConfiguration();
			
			// audit the whole domain
			// enversConf.Audit(GetDomainEntities());

			enversConf.Audit<Person>();
			enversConf.Audit<Game>();
			
			// to inspect the metadata
			//var mets = enversConf.CreateMetaData(Configure);

			// Configure.Properties.Add("nhibernate.envers.audit_table_prefix", string.Empty); // default
			// Configure.Properties.Add("nhibernate.envers.audit_table_suffix", "_REV"); // default _AUD
			// Configure.Properties.Add("nhibernate.envers.revision_field_name", "REV"); // default
			// Configure.Properties.Add("nhibernate.envers.revision_type_field_name", "REVTYPE"); // default
			
			Configure.IntegrateWithEnvers(enversConf);
		}
	}
}