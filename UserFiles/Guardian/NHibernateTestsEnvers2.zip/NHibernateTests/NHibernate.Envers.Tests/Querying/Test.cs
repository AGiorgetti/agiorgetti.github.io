﻿using System;
using NHibernate.Envers.Exceptions;
using NHibernate.Envers.Tests.Domain;
using NUnit.Framework;

namespace NHibernate.Envers.Tests.Querying
{
	[TestFixture]
	public class Test
	{
		private NHinit _nh;

		[SetUp]
		public void FixtureSetup()
		{
			_nh = new NHinit();
			_nh.Initialize();
			_nh.InitializeAudit();
			_nh.CreateSchema();
		}

		[TearDown]
		public void FixtureTearDown()
		{
			_nh.DropSchema();
		}

		[Test]
		public void AlwaysPass()
		{
			Assert.IsTrue(true);
		}

		[Test]
		public void GetCurrentRevision_Success()
		{
			// Gets an instance of the current revision entity, to which any entries in the audit tables will be bound.
			// Please note the if {@code persist} is {@code false}, and no audited entities are modified in this session,
			// then the obtained revision entity instance won't be persisted. If {@code persist} is {@code true}, the revision
			// entity instance will always be persisted, regardless of whether audited entities are changed or not.

			// assuming an empty database
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					DefaultRevisionEntity o = auditReader.GetCurrentRevision<DefaultRevisionEntity>(false);
					tx.Commit();
					Assert.IsNotNull(o);
					// it's transient
					Assert.AreEqual(0, o.Id);
				}
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					DefaultRevisionEntity o = auditReader.GetCurrentRevision<DefaultRevisionEntity>(true);
					tx.Commit();
					Assert.IsNotNull(o);
					// it's persisted
					Assert.AreEqual(1, o.Id);
					DefaultRevisionEntityUtils.PrintRevisionInfo(o);
				}
			}
		}

		[Test]
		public void FindRevision_DoesNotExists()
		{
			// assuming an empty database
			Assert.Throws<RevisionDoesNotExistException>(() =>
			{
				using (ISession s = _nh.SessionFactory.OpenSession())
				{
					// look for a non existing revision
					using (var tx = s.BeginTransaction())
					{
						IAuditReader auditReader = s.Auditer();
						var rev = auditReader.FindRevision<DefaultRevisionEntity>(1);
						Assert.IsNotNull(rev);
						tx.Commit();
					}
				}
			});
		}

		[Test]
		public void FindRevision_Success()
		{
			// assuming an empty database
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// create a revision
				using (var tx = s.BeginTransaction())
				{
					// create a person
					Person p = new Person("Jhon", "Doe");
					s.SaveOrUpdate(p);
					tx.Commit();
				}
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var rev = auditReader.FindRevision<DefaultRevisionEntity>(1);
					Assert.IsNotNull(rev);
					DefaultRevisionEntityUtils.PrintRevisionInfo(rev);
					tx.Commit();
				}
			}
		}

		[Test]
		public void FindRevisions_NoRevisions()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// look for a non existing revision
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var rev = auditReader.FindRevisions<DefaultRevisionEntity>(new long[] { 1, 2 });
					Assert.IsNotNull(rev);
					Assert.AreEqual(0, rev.Count);
					tx.Commit();
				}
			}
		}

		[Test]
		public void FindRevisions_Success()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// create a revision
				using (var tx = s.BeginTransaction())
				{
					// create a person
					Person p = new Person("Jhon", "Doe");
					s.SaveOrUpdate(p);
					tx.Commit();
				}
				// create a revision
				using (var tx = s.BeginTransaction())
				{
					// create a person
					Person p = new Person("Jane", "Doe");
					s.SaveOrUpdate(p);
					tx.Commit();
				}
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var revs = auditReader.FindRevisions<DefaultRevisionEntity>(new long[] { 1, 2 });
					Assert.IsNotNull(revs);
					Assert.AreEqual(2, revs.Count);
					DefaultRevisionEntityUtils.PrintRevisionInfos(revs.Values);
					tx.Commit();
				}
			}
		}

		[Test]
		public void FindRevisions_NonExistentRevision()
		{
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// create a revision
				using (var tx = s.BeginTransaction())
				{
					// create a person
					Person p = new Person("Jhon", "Doe");
					s.SaveOrUpdate(p);
					tx.Commit();
				}
				// look for a non existent revision
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var revs = auditReader.FindRevisions<DefaultRevisionEntity>(new long[] { 1, 2 });
					Assert.IsNotNull(revs);
					Assert.AreEqual(1, revs.Count);
					Assert.AreEqual(1, revs[1].Id);
					DefaultRevisionEntityUtils.PrintRevisionInfos(revs.Values);
					tx.Commit();
				}
			}
		}

		/// <summary>
		/// the default mapping uses a timestamp, so we have milliseconds too
		/// </summary>
		[Test]
		public void GetRevisionDate_Success()
		{
			DateTime testStart = DateTime.Now;
			// assuming an empty database
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// create a revision
				using (var tx = s.BeginTransaction())
				{
					// create a person
					Person p = new Person("Jhon", "Doe");
					s.SaveOrUpdate(p);
					tx.Commit();
				}
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					var revisionDatev = auditReader.GetRevisionDate(1);
					Assert.Greater(revisionDatev, testStart);
					tx.Commit();
				}
			}
		}

		[Test]
		public void GetRevisionDate_DoesNotExist()
		{
			// assuming an empty database
			Assert.Throws<RevisionDoesNotExistException>(() =>
															{
																DateTime testStart = DateTime.Now;
																// assuming an empty database
																using (ISession s = _nh.SessionFactory.OpenSession())
																{
																	using (var tx = s.BeginTransaction())
																	{
																		IAuditReader auditReader = s.Auditer();
																		var revisionDatev = auditReader.GetRevisionDate(1);
																		Assert.Greater(revisionDatev, testStart);
																		tx.Commit();
																	}
																}
															});
		}

		[Test]
		public void GetRevisionNumberForDate_DoesNotExist()
		{
			// assuming an empty database
			Assert.Throws<RevisionDoesNotExistException>(() =>
															{
																DateTime testStart = DateTime.Now;
																// assuming an empty database
																using (ISession s = _nh.SessionFactory.OpenSession())
																{
																	using (var tx = s.BeginTransaction())
																	{
																		IAuditReader auditReader = s.Auditer();
																		long num = auditReader.GetRevisionNumberForDate(testStart);
																		Assert.Greater(num, 0);
																		tx.Commit();
																	}
																}
															});
		}

		[Test]
		public void GetRevisionNumberForDate_Success()
		{
			// assuming an empty database
			using (ISession s = _nh.SessionFactory.OpenSession())
			{
				// create a revision
				using (var tx = s.BeginTransaction())
				{
					// create a person
					Person p = new Person("Jhon", "Doe");
					s.SaveOrUpdate(p);
					tx.Commit();
				}
				using (var tx = s.BeginTransaction())
				{
					IAuditReader auditReader = s.Auditer();
					DateTime testStart = DateTime.Now;
					long num = auditReader.GetRevisionNumberForDate(testStart);
					Assert.AreEqual(1, num);
					tx.Commit();
				}
			}
		}
	}
}