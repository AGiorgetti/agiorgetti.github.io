﻿using System;
using System.Collections.Generic;
using System.Linq;
using ConfOrm;
using ConfOrm.NH;
using ConfORM_Tests.ConfORM;
using ConfORM_Tests.Domain;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Cfg.MappingSchema;
using NHibernate.Tool.hbm2ddl;
using NUnit.Framework;

namespace ConfORM_Tests
{
	[TestFixture]
	public class MixedMappings : TestBase
	{
		public class MixedMappingsDomainMapper : IDomainMapper
		{
			private ObjectRelationalMapper _orm;
			Mapper _mapper;

			private IEnumerable<Type> InitConfOrm()
			{
				_orm = new ObjectRelationalMapper();
				_mapper = new Mapper(_orm);

				// define the mapping shape

				// list all the entities we want to map.
				// let's exclude the 'Alien' which will be mapped with a standard XML file 
				IEnumerable<Type> baseEntities = typeof(Person).Assembly.GetTypes()
					.Where(t => t.Namespace == typeof(Person).Namespace && t != typeof(Alien));

				// defines the whole hierarchy coming up from Person
				_orm.TablePerClassHierarchy<Person>();

				// we map all the other classes as Table per class
				_orm.TablePerClass(baseEntities.Where(t => !typeof(Person).IsAssignableFrom(t)));

				// specify the relation we have between Child and Alien otherwise conform will generate a property by default.
				// it has no real clue of what an 'Alien' is and we have to help him!
				_orm.ManyToOne<Child, Alien>();
				_orm.ManyToOne<Alien, Person>();

				return baseEntities;
			}

			#region IDomainMapper Members

			public HbmMapping HbmMapping
			{
				get
				{
					// compile the mapping for the specified entities
					var types = InitConfOrm();
					HbmMapping compileMappingFor = _mapper.CompileMappingFor(types);
					Console.Write(compileMappingFor.AsString());
					return compileMappingFor;
				}
			}

			public IList<HbmMapping> HbmMappings
			{
				get
				{
					// compile the mapping for the specified entities
					var types = InitConfOrm();
					return _mapper.CompileMappingForEach(types).ToList();
				}
			}

			#endregion
		}

		private static void InitializeConfOrm(Configuration nhConfig)
		{
			var domMapper = new MixedMappingsDomainMapper();

			// inject the mapping in NHibernate
			nhConfig.AddDeserializedMapping(domMapper.HbmMapping, "Domain");
			// fix up the schema
			SchemaMetadataUpdater.QuoteTableAndColumns(nhConfig);
		}

		/// <summary>
		/// In the Fixture setup we configure NHibernate and we create the mappings
		/// </summary>
		[Test]
		public void T01_Setup_SessionFactory()
		{
			Configuration nhConfig = ConfigureNHibernate();
			Assert.IsNotNull(nhConfig);
			nhConfig.AddAssembly(typeof(Alien).Assembly);

			// initialize ConfORM engine
			InitializeConfOrm(nhConfig);
			// create the session factory
			Assert.DoesNotThrow(() => SessionFactory = nhConfig.BuildSessionFactory());
			//SessionFactory = NhConfig.BuildSessionFactory();
		}

		[Test]
		public void T02_CreateDatabaseSchema()
		{
			Configuration nhConfig = ConfigureNHibernate();
			Assert.IsNotNull(nhConfig);
			// standard XML mapping
			nhConfig.AddAssembly(typeof(Alien).Assembly);
			// initialize ConfORM engine
			InitializeConfOrm(nhConfig);
			// clear up the database 
			Assert.DoesNotThrow(() => new SchemaExport(nhConfig).Drop(false, true));
			// create it
			Assert.DoesNotThrow(() => new SchemaExport(nhConfig).Create(true, true));
		}

		private ISessionFactory CreateDatabaseAndGetSessionFactory()
		{
			Configuration nhConfig = ConfigureNHibernate();
			Assert.IsNotNull(nhConfig);
			nhConfig.AddAssembly(typeof(Alien).Assembly);
			// initialize ConfORM engine
			InitializeConfOrm(nhConfig);
			// clear up the database 
			Assert.DoesNotThrow(() => new SchemaExport(nhConfig).Drop(false, true));
			// create it
			Assert.DoesNotThrow(() => new SchemaExport(nhConfig).Create(false, true));

			return SessionFactory = nhConfig.BuildSessionFactory();
		}

		[Test]
		public void T03_ChildAlien_TheyCanBeFriends()
		{
			ISessionFactory sf = CreateDatabaseAndGetSessionFactory();

			// create the relation
			using (ISession s = sf.OpenSession())
			{
				int childId;

				using (ITransaction tx = s.BeginTransaction())
				{
					Alien alien = new Alien { Name = "Xfuncz" };
					s.SaveOrUpdate(alien);

					Child child = new Child { FirstName = "Teddy", LastName = "Strange", BirthDate = DateTime.Now, EtFriend = alien };
					s.SaveOrUpdate(child);
					childId = child.Id;

					tx.Commit();
				}

				s.Clear();

				using (ITransaction tx = s.BeginTransaction())
				{
					// get the data
					var loaded = s.Get<Child>(childId);

					tx.Commit();

					Assert.IsNotNull(loaded);
					Assert.IsNotNull(loaded.EtFriend);
					Assert.AreEqual("Xfuncz", loaded.EtFriend.Name);
				}
			}
		}

		[Test]
		public void T04_AlienPerson_TheyCanBeFriends()
		{
			ISessionFactory sf = CreateDatabaseAndGetSessionFactory();

			// create the relation
			using (ISession s = sf.OpenSession())
			{
				int alienId;

				using (ITransaction tx = s.BeginTransaction())
				{
					Person adult = new Adult { FirstName = "Bobby", LastName = "Strange", BirthDate = DateTime.Now };
					s.SaveOrUpdate(adult);

					Alien alien = new Alien { Name = "Xorps", HumanFriend = adult };
					s.SaveOrUpdate(alien);
					alienId = alien.Id;

					tx.Commit();
				}

				s.Clear();

				using (ITransaction tx = s.BeginTransaction())
				{
					// get the data
					var loaded = s.Get<Alien>(alienId);

					tx.Commit();

					Assert.IsNotNull(loaded);
					Assert.IsNotNull(loaded.HumanFriend);
					Assert.AreEqual("Bobby", loaded.HumanFriend.FirstName);
				}
			}
		}
	}
}
