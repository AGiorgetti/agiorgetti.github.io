﻿using System;
using System.Collections.Generic;
using System.Linq;
using ConfOrm;
using ConfOrm.NH;
using ConfORM_Tests.ConfORM;
using ConfORM_Tests.Domain;
using NHibernate.Cfg;
using NHibernate.Cfg.MappingSchema;
using NHibernate.Tool.hbm2ddl;
using NUnit.Framework;

namespace ConfORM_Tests
{
	[TestFixture]
	public class SimpleInitialization : TestBase
	{
		public class SimpleInitializationDomainMapper : IDomainMapper
		{
			private ObjectRelationalMapper _orm;
			Mapper _mapper;

			private IEnumerable<Type> InitConfOrm()
			{
				_orm = new ObjectRelationalMapper();
				_mapper = new Mapper(_orm);

				// define the mapping shape

				// list all the entities we want to map
				IEnumerable<Type> baseEntities = typeof(Person).Assembly.GetTypes().Where(t => t.Namespace == typeof(Person).Namespace);

				// defines the whole hierarchy coming up from Person
				_orm.TablePerClassHierarchy<Person>();

				// we map all the other classes as Table per class
				_orm.TablePerClass(baseEntities.Where(t => !typeof(Person).IsAssignableFrom(t)));

				return baseEntities;
			}

			#region IDomainMapper Members

			public HbmMapping HbmMapping
			{
				get
				{
					// compile the mapping for the specified entities
					var types = InitConfOrm();
					HbmMapping compileMappingFor = _mapper.CompileMappingFor(types);
					Console.Write(compileMappingFor.AsString());
					return compileMappingFor;
				}
			}

			public IList<HbmMapping> HbmMappings
			{
				get
				{
					// compile the mapping for the specified entities
					var types = InitConfOrm();
					return _mapper.CompileMappingForEach(types).ToList();
				}
			}

			#endregion
		}

		private static void InitializeConfOrm(Configuration nhConfig)
		{
			var domMapper = new SimpleInitializationDomainMapper();

			// inject the mapping in NHibernate
			nhConfig.AddDeserializedMapping(domMapper.HbmMapping, "Domain");
			// fix up the schema
			SchemaMetadataUpdater.QuoteTableAndColumns(nhConfig);
		}

		/// <summary>
		/// In the Fixture setup we configure NHibernate and we create the mappings
		/// </summary>
		[Test]
		public void T01_Setup_SessionFactory()
		{
			Configuration nhConfig = ConfigureNHibernate();
			Assert.IsNotNull(nhConfig);
			// initialize ConfORM engine
			InitializeConfOrm(nhConfig);
			// create the session factory
			Assert.DoesNotThrow(() => SessionFactory = nhConfig.BuildSessionFactory());
			// SessionFactory = NhConfig.BuildSessionFactory();
		}

		[Test]
		public void T02_CreateDatabaseSchema()
		{
			Configuration nhConfig = ConfigureNHibernate();
			Assert.IsNotNull(nhConfig);
			// initialize ConfORM engine
			InitializeConfOrm(nhConfig);
			// clear up the database 
			Assert.DoesNotThrow(() => new SchemaExport(nhConfig).Drop(false, true));
			// create it
			Assert.DoesNotThrow(() => new SchemaExport(nhConfig).Create(false, true));
		}
	}
}
