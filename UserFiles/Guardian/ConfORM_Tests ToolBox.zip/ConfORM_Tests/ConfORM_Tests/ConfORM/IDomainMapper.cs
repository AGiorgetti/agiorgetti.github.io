﻿using System.Collections.Generic;
using NHibernate.Cfg.MappingSchema;

namespace ConfORM_Tests.ConfORM
{
	public interface IDomainMapper
	{
		HbmMapping HbmMapping { get; }

		IList<HbmMapping> HbmMappings { get; }
	}
}
