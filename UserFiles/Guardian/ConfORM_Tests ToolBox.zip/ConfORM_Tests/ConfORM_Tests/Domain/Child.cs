﻿namespace ConfORM_Tests.Domain
{
	public class Child : Person
	{     
		public virtual Adult Father { get; set; }

		public virtual Adult Mother { get; set; }

		public virtual Alien EtFriend { get; set; }
	}
}
