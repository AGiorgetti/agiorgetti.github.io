﻿namespace ConfORM_Tests.Domain
{
	public class Alien
	{
		public virtual int Id { get; set; }

		public virtual string Name { get; set; }

		public virtual Person HumanFriend { get; set; }
	}
}
