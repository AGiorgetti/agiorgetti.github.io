﻿using System.Collections.Generic;
using System.Windows;
using Microsoft.Phone.Controls;
using WP7DataContractSerializerBug.Domain;
using WP7DataContractSerializerBug.Helper;

namespace WP7DataContractSerializerBug
{
	public partial class MainPage : PhoneApplicationPage
	{
		// Constructor
		public MainPage()
		{
			InitializeComponent();
		}

		private void AllPublicClick(object sender, RoutedEventArgs e)
		{
			AllPublic obj = new AllPublic();
			string data = DataContractSerializerHelpers.Serialize(obj);
			MessageBox.Show(data);
		}

		private void EntityClick(object sender, RoutedEventArgs e)
		{
			Entity obj = new Entity();
			string data = DataContractSerializerHelpers.Serialize(obj);
			MessageBox.Show(data);
		}

		private void InternalEntityClick(object sender, RoutedEventArgs e)
		{
			InternalEntity obj = new InternalEntity();
			string data = DataContractSerializerHelpers.Serialize(obj);
			MessageBox.Show(data);
		}

		private void ConstructorNotCalled(object sender, RoutedEventArgs e)
		{
			// object constructor is not called during deserialization
			EntityWithConstructor obj = new EntityWithConstructor();
			string data = DataContractSerializerHelpers.Serialize(obj);
			MessageBox.Show(data);
			EntityWithConstructor deser = DataContractSerializerHelpers.Deserialize<EntityWithConstructor>(data);
			// deser.M1 will be "", instead of the "Initialized" specified in the parameterless contructor
			MessageBox.Show("Constructor initialized value (it should be 'Initialized': " + deser.M1);
		}

		private void IsReferenceClick(object sender, RoutedEventArgs e)
		{
			// references are preserved if you specify the 'IsReference = true' parameter of DataContract attribute
			var cont = new EntityContainer();
			cont.Entities = new List<Entity> {new Entity() { P1 = "E1"}};
			cont.SelectedEntity = cont.Entities[0];
			cont.IsReferenceEntities = new List<IsReferenceEntity>() {new IsReferenceEntity(){ P1 = "Ref1"}};
			cont.SelectedIsReferenceEntity = cont.IsReferenceEntities[0];
			
			string data = DataContractSerializerHelpers.Serialize(cont);
			MessageBox.Show(data);
			EntityContainer deser = DataContractSerializerHelpers.Deserialize<EntityContainer>(data);

			bool isEqualEntityP1Content = deser.Entities[0].P1 == deser.SelectedEntity.P1; // true
			bool isSameEntityInstance = deser.Entities[0] == deser.SelectedEntity; //false

			bool isEqualIsReferenceEntityP1Content = deser.IsReferenceEntities[0].P1 == deser.SelectedIsReferenceEntity.P1; //true
			bool isSameIsReferenceEntityInstance = deser.IsReferenceEntities[0] == deser.SelectedIsReferenceEntity; //true

			string message =
				string.Format(
					"Entity\n - same content: {0}\n - same reference: {1} \n\nIsReferenceEntity\n - same content: {2}\n - same reference: {3}",
					isEqualEntityP1Content, isSameEntityInstance, isEqualIsReferenceEntityP1Content, isSameIsReferenceEntityInstance);
			MessageBox.Show(message);
		}

		private void DerivedClassClick(object sender, RoutedEventArgs e)
		{
			DerivedContainer cont = new DerivedContainer();
			cont.Entity = new Derived() {P2 = "data"};

			string data = DataContractSerializerHelpers.Serialize(cont);
			MessageBox.Show(data);
			DerivedContainer deser = DataContractSerializerHelpers.Deserialize<DerivedContainer>(data);
			// deser.Entity is of type Derived.
			MessageBox.Show("Type inside Entity field: " + deser.Entity.GetType().Name);
		}
	}
}