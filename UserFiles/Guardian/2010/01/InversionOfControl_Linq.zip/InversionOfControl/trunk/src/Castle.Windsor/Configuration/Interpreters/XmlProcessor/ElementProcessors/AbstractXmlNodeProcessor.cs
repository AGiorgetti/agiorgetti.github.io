// Copyright 2004-2009 Castle Project - http://www.castleproject.org/
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//#if(!SILVERLIGHT)
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Castle.Windsor.Configuration.Interpreters.XmlProcessor.ElementProcessors
{
	using System;
	using System.Xml;
	
	public abstract class AbstractXmlNodeProcessor : IXmlNodeProcessor
	{
		private static readonly XmlNodeType[] acceptNodes = new XmlNodeType[] {XmlNodeType.Element};

		public AbstractXmlNodeProcessor()
		{
		}

		public abstract String Name { get; }

		public virtual XmlNodeType[] AcceptNodeTypes
		{
			get { return acceptNodes; }
		}

		/// <summary>
		/// Accepts the specified node.
		/// Check if node has the same name as the processor and the node.NodeType
		/// is in the AcceptNodeTypes List
		/// </summary>
		/// <param name="node">The node.</param>
		/// <returns></returns>
		public virtual bool Accept(XNode node)
		{
			return node.Name() == Name && Array.IndexOf(AcceptNodeTypes, node.NodeType) != -1;
		}

		public abstract void Process(IXmlProcessorNodeList nodeList, IXmlProcessorEngine engine);

		protected virtual bool IgnoreNode(XNode node)
		{
			return node.NodeType == XmlNodeType.Comment ||
				node.NodeType == XmlNodeType.Entity ||
				node.NodeType == XmlNodeType.EntityReference;
		}

		/// <summary>
		/// Convert and return child parameter into an XElement
		/// An exception will be throw in case the child node cannot be converted
		/// </summary>
		/// <param name="element">Parent node</param>
		/// <param name="child">Node to be converted</param>
		/// <returns>child node as XElement</returns>
		protected XElement GetNodeAsElement(XElement element, XNode child)
		{
			XElement result = child as XElement;

			if (result == null)
			{
				throw new XmlProcessorException("{0} expects XElement found {1}", element.Name, child.NodeType);
			}

			return result;
		}

		protected String GetRequiredAttribute(XElement element, String attribute)
		{
			String attValue = element.GetAttribute(attribute).Trim();

			if (attValue == "")
			{
				throw new XmlProcessorException("'{0}' requires a non empty '{1}' attribute", element.Name, attribute);
			}

			return attValue;
		}

		protected XNode ImportNode(XElement targetElement, XNode node)
		{
			if (targetElement.Document == node.Document)
				return node;
			XNode cloned = null;

			if (node is XElement)
				cloned = new XElement(node as XElement);
			else if (node is XText)
				cloned = new XText(node as XText);

			targetElement.Add(cloned);

			return cloned;
		}

		protected void AppendChild(XElement element, IList<XNode> nodes)
		{
			DefaultXmlProcessorNodeList childNodes = new DefaultXmlProcessorNodeList(nodes, true);

			while(childNodes.MoveNext())
			{
				AppendChild(element, childNodes.Current);
			}
		}

		protected void AppendChild(XElement element, string text)
		{
			AppendChild(element, CreateText(element, text));
		}

		protected void AppendChild(XElement element, XNode child)
		{
			element.AppendChild(ImportNode(element, child));
		}

		[Obsolete()]
		protected void ReplaceNode(XElement element, XElement newNode, XElement oldNode)
		{
			if (newNode == oldNode) return;

			XNode importedNode = ImportNode(element, newNode);

			element.ReplaceChild(importedNode, oldNode);
		}

		protected XText CreateText(XNode node, string content)
		{
			return new XText(content);
		}

		protected XDocumentFragment CreateFragment(XElement node)
		{
			return new XDocumentFragment(node.Name); //node.Document);
		}

		protected XDocumentFragment CreateFragment(XObject node)
		{
			return new XDocumentFragment("test");  //node.Document;
		}

		protected bool IsTextNode(XNode node)
		{
			return node.NodeType == XmlNodeType.Text || node.NodeType == XmlNodeType.CDATA;
		}

		protected void ReplaceItself(XElement newNode, XElement oldNode)
		{
			if (newNode is XDocumentFragment)
			{
				foreach(XNode n in newNode.Nodes())
					oldNode.AddBeforeSelf(n);
				oldNode.Remove();
			}
			else
				oldNode.ReplaceWith(newNode);
		}

		protected void RemoveItSelf(XNode node)
		{
			node.Remove();
			//node.ParentNode.RemoveChild(node);
		}

		protected void MoveChildNodes(XElement fragment, XElement element)
		{
			var childs = element.Nodes().ToList();
			foreach (var node in childs)
			{
				node.Remove();
				fragment.Add(node);
			}
		}
	}
}
// #endif
