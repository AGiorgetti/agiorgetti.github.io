// Copyright 2004-2009 Castle Project - http://www.castleproject.org/
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//#if(!SILVERLIGHT)
using System.Linq;
using System.Xml.Linq;

namespace Castle.Windsor.Configuration.Interpreters.XmlProcessor.ElementProcessors
{
	using System;
	using System.Text.RegularExpressions;
	using System.Xml;

	public class DefaultTextNodeProcessor : AbstractXmlNodeProcessor
	{
		private static readonly XmlNodeType[] acceptNodes = new XmlNodeType[] {XmlNodeType.CDATA, XmlNodeType.Text};

		/// <summary>
		/// Properties names can contain a-zA-Z0-9_. 
		/// i.e. #!{ my_node_name } || #{ my.node.name }
		/// spaces are trimmed
		/// </summary>
#if !SILVERLIGHT
		private static readonly Regex PropertyValidationRegExp = new Regex(@"(\#!?\{\s*((?:\w|\.)+)\s*\})", RegexOptions.Compiled);
#else
		private static readonly Regex PropertyValidationRegExp = new Regex(@"(\#!?\{\s*((?:\w|\.)+)\s*\})");
#endif
		public DefaultTextNodeProcessor()
		{
		}

		public override String Name
		{
			get { return "#text"; }
		}

		public override XmlNodeType[] AcceptNodeTypes
		{
			get { return acceptNodes; }
		}

		public override void Process(IXmlProcessorNodeList nodeList, IXmlProcessorEngine engine)
		{
			//XElement node = nodeList.Current as XElement;
			//ProcessString(node, node.Value, engine);
			
			XNode node = nodeList.Current;
			ProcessString(node, node.ToString(), engine);
		}

		/// <summary>
		/// Processes the string.
		/// </summary>
		/// <param name="node">The node.</param>
		/// <param name="value">The value.</param>
		/// <param name="engine">The context.</param>
		public void ProcessString(XObject node, string value, IXmlProcessorEngine engine)
		{
         //XElement fragment = CreateFragment(node);
			XElement fragment;
				if ((node is XAttribute) || (node is XText))
					fragment = new XElement("Attr");
				else
					fragment = new XElement((node as XElement).Name);
			Match match;
			int pos = 0;
			while((match = PropertyValidationRegExp.Match(value, pos)).Success)
			{
				if (pos < match.Index)
				{
					AppendChild(fragment, value.Substring(pos, match.Index - pos));
				}

				string propRef = match.Groups[1].Value; // #!{ propKey }
				string propKey = match.Groups[2].Value; // propKey

				XNode prop = engine.GetProperty(propKey);

				if (prop != null)
				{
					// When node has a parentNode (not an attribute)
					// we copy any attributes for the property into the parentNode
					if (node.Parent != null)
					{
						MoveAttributes(node.Parent as XElement, prop as XElement);
					}

					AppendChild(fragment, (prop as XElement).Nodes().ToList());
				}
				else if (IsRequiredProperty(propRef))
				{
					throw new XmlProcessorException(String.Format("Required configuration property {0} not found", propKey));
				}

				pos = match.Index + match.Length;
			}

			// Appending anything left
			if (pos > 0 && pos < value.Length)
			{
				AppendChild(fragment, value.Substring(pos, value.Length - pos));
			}

			// we only process when there was at least one match
			// even when the framents contents is empty since
			// that could mean that there was a match but the property
			// reference was a silent property
			if (pos > 0)
			{
				if (node.NodeType == XmlNodeType.Attribute)
				{
					(node as XAttribute).Value = fragment.Value.Trim();
				}
				else if (node is XText)
				{
					XText text = (node as XText);
					if (!fragment.HasElements)
						text.Value = fragment.Value.Trim();
					else
					{
						// I need to replcae the nde with the elements created
						foreach (var xNode in fragment.Nodes())
						{
							text.AddBeforeSelf(xNode);
						}
						text.Remove();
					}
					//using (var reader=fragment.CreateReader())
					//{
					//   reader.MoveToContent();
					//   (node as XText).Value = reader.ReadInnerXml().Trim();
					//}
					
               // (node as XText).Value = fragment.Value.Trim();
					//(node as XText).Value = fragment.ToString().Replace("<Attr>", "").Replace("</Attr>","").Trim();
				}
				else
				{
					(node as XNode).ReplaceWith(fragment);
				}
			}
		}

		private bool IsRequiredProperty(string propRef)
		{
			return propRef.StartsWith("#{");
		}

		private void MoveAttributes(XElement targetElement, XElement srcElement)
		{
			//for(int i = srcElement.Attributes().Count() - 1; i > -1; i--)
			//{
			//   XAttribute importedAttr = ImportNode(targetElement, srcElement.Attributes().ToList()[i]) as XAttribute;
			//   targetElement.Add(importedAttr);
			//}

			foreach (var attribute in srcElement.Attributes())
			{
				targetElement.Add(attribute);
			}
		}
	}
}

//#endif
