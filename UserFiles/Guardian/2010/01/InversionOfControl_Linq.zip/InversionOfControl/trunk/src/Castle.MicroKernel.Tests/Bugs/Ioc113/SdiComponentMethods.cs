#region Header

// Copyright � 2006-2008 F&L methode� software www.fenlsoftware.nl

#endregion

namespace Castle.MicroKernel.Tests.Bugs.Ioc113
{
	public enum SdiComponentMethods
	{
		Initialize,
		Start,
		DoSomething,
		Stop,
		Dispose,
	}
}
