﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Castle.Windsor.Configuration.Interpreters
{
	public static class LinqExtensions
	{
		public static bool HasAttribute(this XElement elem, string attribute)
		{
			return elem.Attribute(attribute) != null;
		}

		public static string InnerXml(this XElement elem)
		{
			return elem.Nodes().Aggregate("", (b, node) => b += node.ToString());
		}

		public static string GetAttribute(this XElement elem, string attribute)
		{
			XAttribute xAttribute = elem.Attribute(attribute);
			if (xAttribute != null) return xAttribute.Value;
			return string.Empty;
		}

		public static string Name(this XNode node)
		{
			XElement elem = node as XElement;
			if (elem != null)
				return elem.Name.LocalName;

			if (node is XProcessingInstruction)
				return (node as XProcessingInstruction).Target;
			
			//if (node is XText)
			//   return "#text";
			
			return node.ToString();
		}

		public static void AppendChild(this XNode node, XNode child)
		{
			(node as XElement).Add(child);
		}

		public static void ReplaceChild(this XNode node, XNode nodeToAdd, XNode nodeToReplace)
		{
			nodeToReplace.Remove();
			(node as XElement).Add(nodeToAdd);
		}
	}

	public class XDocumentFragment : XElement
	{
		public XDocumentFragment(string name) : base(name)
		{ }

		public XDocumentFragment(XName name)
			: base(name)
		{ }
	}
}
