namespace Castle.Windsor.Tests.Bugs.FACILITIES_ISSUE_111.Components
{
	public interface IB_Facilities_Issue_111
	{
		void Method();
	}
}
