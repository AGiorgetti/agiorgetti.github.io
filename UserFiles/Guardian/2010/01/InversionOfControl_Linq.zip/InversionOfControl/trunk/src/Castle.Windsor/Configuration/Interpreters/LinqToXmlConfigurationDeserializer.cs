﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Castle.Core.Configuration;

namespace Castle.Windsor.Configuration.Interpreters
{
	/// <summary>
	/// Pendent
	/// </summary>
	public class LinqToXmlConfigurationDeserializer
	{
		/// <summary>
		/// Deserializes the specified node into an abstract representation of configuration.
		/// </summary>
		/// <param name="node">The node.</param>
		/// <returns></returns>
		public IConfiguration Deserialize(XElement node)
		{
			return Deserialize(node);
		}

		public static IConfiguration GetDeserializedNode(XElement node)
		{
			ConfigurationCollection configChilds = new ConfigurationCollection();

			StringBuilder configValue = new StringBuilder();

			//if (node.HasElements)
			//{
				foreach(XNode child in node.Nodes())
				{
					if (IsTextNode(child))
					{
						configValue.Append((child as XText).Value);
					}
					else if (child.NodeType == XmlNodeType.Element)
					{
						configChilds.Add(GetDeserializedNode(child as XElement));
					}
				}
			//}

			MutableConfiguration config = new MutableConfiguration(node.Name.LocalName, GetConfigValue(configValue.ToString()));

			foreach(XAttribute attribute in node.Attributes())
			{
				config.Attributes.Add(attribute.Name.LocalName, attribute.Value);
			}

			config.Children.AddRange(configChilds);

			return config;
		}

		/// <summary>
		/// If a config value is an empty string we return null, this is to keep
		/// backward compability with old code
		/// </summary>
		public static string GetConfigValue(string value)
		{
			return string.IsNullOrEmpty(value) ? null : value.Trim();
		}

		public static bool IsTextNode(XNode node)
		{
			return node.NodeType == XmlNodeType.Text || node.NodeType == XmlNodeType.CDATA ;
				// || ((node.NodeType == XmlNodeType.Element) && !(node as XElement).HasElements);
		}
	}
}

