// Copyright 2004-2009 Castle Project - http://www.castleproject.org/
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//#if(!SILVERLIGHT)
using System.Linq;
using System.Xml.Linq;

namespace Castle.Windsor.Configuration.Interpreters.XmlProcessor.ElementProcessors
{
	using System;
	using System.Xml;

	public class AttributesElementProcessor : AbstractXmlNodeProcessor
	{
		public override String Name
		{
			get { return "attributes"; }
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="nodeList"></param>
		/// <param name="engine"></param>
		/// <example>
		/// <code>
		/// 	<properties>
		///			<attributes>
		///				<myAttribute>attributeValue</myAttribute>
		///			</attributes>
		///			<myProperty>propertyValue</myProperty>
		///		</properties>
		/// </code>
		/// </example>
		public override void Process(IXmlProcessorNodeList nodeList, IXmlProcessorEngine engine)
		{
			XElement element = nodeList.Current as XElement;

			DefaultXmlProcessorNodeList childNodes = new DefaultXmlProcessorNodeList(element.Nodes().ToList());

			while(childNodes.MoveNext())
			{
				engine.DispatchProcessCurrent(childNodes);

				if (IgnoreNode(childNodes.Current)) continue;

				XElement elem = GetNodeAsElement(element, childNodes.Current);

				AppendElementAsAttribute(element.Parent, childNodes.Current as XElement);
			}

			RemoveItSelf(element);
		}

		protected void AppendElementAsAttribute(XNode parentElement, XElement element)
		{
			XAttribute attribute = new XAttribute(element.Name, element.Value);

			(parentElement as XElement).Add(attribute);
		}
	}
}

//#endif
