﻿namespace ConfORM_Tests.Domain
{
	public class Child : Person
	{     
		public Adult Father { get; set; }

		public Adult Mother { get; set; }
	}
}
