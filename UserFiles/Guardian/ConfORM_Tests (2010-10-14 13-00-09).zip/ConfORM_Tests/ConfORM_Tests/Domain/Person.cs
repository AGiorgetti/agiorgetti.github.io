﻿using System;
using System.Collections.Generic;

namespace ConfORM_Tests.Domain
{
	public class Person
	{
		protected Person()
		{
			Pets = new List<Pet>();
			HeldItems = new List<Item>();
		}

		public int Id { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }

		public IList<Pet> Pets { get; set; }

		/// <summary>
		/// property used for Linq provider equality extension tests
		/// </summary>
		/// <value>The long.</value>
		public long Long { get; set; }
		
		/// <summary>
		/// property used for Linq provider equality extension tests
		/// </summary>
		/// <value>The GUID.</value>
		public Guid Guid { get; set; }

		/// <summary>
		/// Gets or sets the held items.
		/// property used for Custom UserType tests
		/// </summary>
		/// <value>The held items.</value>
		public IList<Item> HeldItems { get; set; }

		/// <summary>
		/// Gets or sets the right hand item.
		/// property used for Custom UserType tests
		/// </summary>
		/// <value>The right hand.</value>
		public Item RightHand { get; set; }

		/// <summary>
		/// Gets or sets the left hand item.
		/// property used for Custom UserType tests
		/// </summary>
		/// <value>The left hand.</value>
		public Item LeftHand { get; set; }

        /// <summary>
        /// Gets or sets the birth date.
        /// </summary>
        /// <value>The birth date.</value>
	    public DateTime BirthDate { get; set; }

	    #region "Equality Member for NHibernate"
		
		public bool Equals(Person other)
		{
			if (ReferenceEquals(null, other)) return false;
			if (ReferenceEquals(this, other)) return true;
			return other.Id == Id;
		}

		public override bool Equals(object obj)
		{
			if (ReferenceEquals(null, obj)) return false;
			if (ReferenceEquals(this, obj)) return true;
			if (obj.GetType() != typeof (Person)) return false;
			return Equals((Person) obj);
		}

		public override int GetHashCode()
		{
			return Id;
		}

		public static bool operator ==(Person left, Person right)
		{
			return Equals(left, right);
		}

		public static bool operator !=(Person left, Person right)
		{
			return !Equals(left, right);
		}

		#endregion
	}
}
