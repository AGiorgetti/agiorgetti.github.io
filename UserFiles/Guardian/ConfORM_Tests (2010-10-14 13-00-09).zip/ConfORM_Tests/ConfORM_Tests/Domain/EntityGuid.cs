﻿using System;

namespace ConfORM_Tests.Domain
{
	/// <summary>
	/// Entity used in the transaction tests, this one has a guid key (not handled by the database)
	/// </summary>
	public class EntityGuid
	{
		public Guid Id { get; set; }

		public string Name { get; set; }
	}
}
