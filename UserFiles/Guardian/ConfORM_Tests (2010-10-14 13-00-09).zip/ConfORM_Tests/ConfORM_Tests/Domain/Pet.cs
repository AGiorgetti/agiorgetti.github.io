﻿namespace ConfORM_Tests.Domain
{
	public class Pet
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public Person Owner { get; set; }
	}
}