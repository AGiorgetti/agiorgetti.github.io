﻿namespace ConfORM_Tests.Domain
{
	public class Adult : Person
	{
		public string Title { get; set; }
	}
}
