﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Castle.Core.Logging;

namespace Structura.Castle.Windsor.Logging.Tests
{
	public partial class BetterMainPage : UserControl
	{
		public BetterMainPage()
		{
			InitializeComponent();
			
			// not valid here anymore, optional dependencies are injected after the construction
			// _logger.Info("Better MainPage created");

			this.Loaded += (s, e) => { _logger.Info("Better MainPage created"); };
		}

		public ILogger _logger { get; set; }

		private void button1_Click(object sender, RoutedEventArgs e)
		{
			_logger.Info("Second action taken");
		}

		private void button2_Click(object sender, RoutedEventArgs e)
		{
			_logger.Info("First action taken");
		}
	}
}
