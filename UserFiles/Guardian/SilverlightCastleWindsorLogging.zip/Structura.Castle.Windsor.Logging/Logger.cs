using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Castle.Core.Logging;

namespace Structura.Castle.Windsor.Logging
{
	public class Logger : LevelFilteredLogger
	{
		public Logger()
		{
		}

		public Logger(string name)
			: base(name)
		{
		}

		public Logger(LoggerLevel loggerLevel)
			: base(loggerLevel)
		{
		}

		public Logger(string loggerName, LoggerLevel loggerLevel)
			: base(loggerName, loggerLevel)
		{
		}

		public Logger(LoggerLevel loggerLevel, IList<IAppender> appenders)
			: base(loggerLevel)
		{
			_appenders = appenders;
		}

		public Logger(string loggerName, LoggerLevel loggerLevel, IList<IAppender> appenders)
			: base(loggerName, loggerLevel)
		{
			_appenders = appenders;
		}

		public override ILogger CreateChildLogger(string loggerName)
		{
			if (loggerName == null)
				throw new ArgumentNullException("loggerName", "To create a child logger you must supply a non null name");

			return new Logger(String.Format(CultureInfo.CurrentCulture, "{0}.{1}", Name, loggerName), Level, Appenders);
		}

		private readonly IList<IAppender> _appenders = new List<IAppender> { new BrowserConsoleAppender() };
		public IList<IAppender> Appenders
		{
			get { return _appenders; }
		}

		protected override void Log(LoggerLevel loggerLevel, string loggerName, string message, Exception exception)
		{
			foreach (var appender in Appenders)
				appender.Log(loggerLevel, loggerName, message, exception);
		}
	}
}