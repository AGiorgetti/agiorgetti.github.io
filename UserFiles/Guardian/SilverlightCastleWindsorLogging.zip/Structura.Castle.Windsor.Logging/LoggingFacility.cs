using System;
using System.Collections.Generic;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Castle.Core.Logging;
using Castle.MicroKernel.Facilities;
using Castle.MicroKernel.Registration;

namespace Structura.Castle.Windsor.Logging
{
	public class LoggingFacility : AbstractFacility
	{
		public LoggingFacility()
		{ }

		public LoggingFacility(LoggerConfig config)
		{
			_configuredLoggers = new[] { config };
		}

		public LoggingFacility(LoggerConfig[] configs)
		{
			_configuredLoggers = configs;
		}

		private const LoggerLevel DefaultLoggerLevel = LoggerLevel.Warn;
		private readonly LoggerConfig[] _configuredLoggers;

		protected override void Init()
		{
			// if we do not have any explicit configuration, we register a default logger
			if ((_configuredLoggers == null) || (_configuredLoggers.Length == 0))
				Kernel.Register(
					Component.For<ILogger>().ImplementedBy<Logger>()
						.DynamicParameters((k, d) =>
						                   	{
						                   		d["loggerLevel"] = DefaultLoggerLevel;
						                   		IAppender[] appenders = k.ResolveAll<IAppender>();
						                   		// if we do not have registered any appender we provide a default console one
						                   		if (appenders.Length == 0)
						                   			appenders = new IAppender[] { new BrowserConsoleAppender() };
						                   		d["appenders"] = appenders;
						                   	})
					);
			else
			{
				// we need to register more than one logger
				foreach (var loggerConfig in _configuredLoggers)
				{
					LoggerConfig config = loggerConfig;
					Kernel.Register(Component.For<ILogger>()
					                	.ImplementedBy<Logger>()
					                	.DynamicParameters((k, d) =>
					                	                   	{
					                	                   		if (!string.IsNullOrEmpty(config.Name))
					                	                   			d["loggerName"] = config.Name;
					                	                   		d["loggerLevel"] = config.Level;
					                	                   		IAppender[] appenders = null;
					                	                   		/* if we have appenders defined..resolve them*/
					                	                   		if ((config.AppendersNames != null) && (config.AppendersNames.Length > 0))
					                	                   		{
					                	                   			List<IAppender> aps = new List<IAppender>();
					                	                   			for (int i = 0; i < config.AppendersNames.Length; i++)
					                	                   				aps.Add(k.Resolve<IAppender>(config.AppendersNames[i]));
					                	                   			appenders = aps.ToArray();
					                	                   		}
					                	                   		/* if not..resolve all the available*/
					                	                   		if ((appenders == null) || (appenders.Length == 0))
					                	                   			appenders = k.ResolveAll<IAppender>();
					                	                   		/* if we do not have registered any appender we provide a default console one*/
					                	                   		if (appenders.Length == 0)
					                	                   			appenders = new IAppender[] { new BrowserConsoleAppender() };
					                	                   		d["appenders"] = appenders;
					                	                   	}));
				}
			}
		}
	}
}