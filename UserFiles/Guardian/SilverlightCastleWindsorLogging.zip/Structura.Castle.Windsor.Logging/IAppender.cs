﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Castle.Core.Logging;

namespace Structura.Castle.Windsor.Logging
{
	/// <summary>
	/// interface for our custom appenders
	/// </summary>
	public interface IAppender
	{
		void Log(LoggerLevel loggerLevel, string loggerName, string message, Exception exception);
	}
}