﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Castle.Core.Logging;

namespace Structura.Castle.Windsor.Logging
{
	/// <summary>
	/// represents a logger explicit configuration
	/// </summary>
	public class LoggerConfig
	{
		public LoggerConfig()
		{
			Level = LoggerLevel.Warn;
		}

		public string Name { get; set; }
		public LoggerLevel Level { get; set; }
		public string[] AppendersNames { get; set; }
	}
}