﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Castle.Core.Logging;

namespace Structura.Castle.Windsor.Logging
{
   public static class LoggingExtensions
   {
      #region Debug

      public static void SafeDebug(this ILogger logger, string message)
      {
         if (logger != null)
            logger.Debug(message);
      }

      public static void SafeDebug(this ILogger logger, string message, Exception exception)
      {
         if (logger != null)
            logger.Debug(message, exception);
      }

      public static void SafeDebug(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.Debug(format, args);
      }

      public static void SafeDebugFormat(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.DebugFormat(format, args);
      }

      public static void SafeDebugFormat(this ILogger logger, Exception exception, string format, params object[] args)
      {
         if (logger != null)
            logger.DebugFormat(exception, format, args);
      }

      public static void SafeDebugFormat(this ILogger logger, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.DebugFormat(formatProvider, format, args);
      }

      public static void SafeDebugFormat(this ILogger logger, Exception exception, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.DebugFormat(exception, formatProvider, format, args);
      }

      #endregion

      #region Error

      public static void SafeError(this ILogger logger, string message)
      {
         if (logger != null)
            logger.Error(message);
      }

      public static void SafeError(this ILogger logger, string message, Exception exception)
      {
         if (logger != null)
            logger.Error(message, exception);
      }

      public static void SafeError(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.Error(format, args);
      }

      public static void SafeErrorFormat(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.ErrorFormat(format, args);
      }

      public static void SafeErrorFormat(this ILogger logger, Exception exception, string format, params object[] args)
      {
         if (logger != null)
            logger.ErrorFormat(exception, format, args);
      }

      public static void SafeErrorFormat(this ILogger logger, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.ErrorFormat(formatProvider, format, args);
      }

      public static void SafeErrorFormat(this ILogger logger, Exception exception, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.ErrorFormat(exception, formatProvider, format, args);
      }

      #endregion

      #region Fatal

      public static void SafeFatal(this ILogger logger, string message)
      {
         if (logger != null)
            logger.Fatal(message);
      }

      public static void SafeFatal(this ILogger logger, string message, Exception exception)
      {
         if (logger != null)
            logger.Fatal(message, exception);
      }

      public static void SafeFatal(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.Fatal(format, args);
      }

      public static void SafeFatalFormat(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.FatalFormat(format, args);
      }

      public static void SafeFatalFormat(this ILogger logger, Exception exception, string format, params object[] args)
      {
         if (logger != null)
            logger.FatalFormat(exception, format, args);
      }

      public static void SafeFatalFormat(this ILogger logger, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.FatalFormat(formatProvider, format, args);
      }

      public static void SafeFatalFormat(this ILogger logger, Exception exception, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.FatalFormat(exception, formatProvider, format, args);
      }

      #endregion

      #region Info

      public static void SafeInfo(this ILogger logger, string message)
      {
         if (logger != null)
            logger.Info(message);
      }

      public static void SafeInfo(this ILogger logger, string message, Exception exception)
      {
         if (logger != null)
            logger.Info(message, exception);
      }

      public static void SafeInfo(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.Info(format, args);
      }

      public static void SafeInfoFormat(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.InfoFormat(format, args);
      }

      public static void SafeInfoFormat(this ILogger logger, Exception exception, string format, params object[] args)
      {
         if (logger != null)
            logger.InfoFormat(exception, format, args);
      }

      public static void SafeInfoFormat(this ILogger logger, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.InfoFormat(formatProvider, format, args);
      }

      public static void SafeInfoFormat(this ILogger logger, Exception exception, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.InfoFormat(exception, formatProvider, format, args);
      }

      #endregion

      #region Warn

      public static void SafeWarn(this ILogger logger, string message)
      {
         if (logger != null)
            logger.Warn(message);
      }

      public static void SafeWarn(this ILogger logger, string message, Exception exception)
      {
         if (logger != null)
            logger.Warn(message, exception);
      }

      public static void SafeWarn(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.Warn(format, args);
      }

      public static void SafeWarnFormat(this ILogger logger, string format, params object[] args)
      {
         if (logger != null)
            logger.WarnFormat(format, args);
      }

      public static void SafeWarnFormat(this ILogger logger, Exception exception, string format, params object[] args)
      {
         if (logger != null)
            logger.WarnFormat(exception, format, args);
      }

      public static void SafeWarnFormat(this ILogger logger, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.WarnFormat(formatProvider, format, args);
      }

      public static void SafeWarnFormat(this ILogger logger, Exception exception, IFormatProvider formatProvider, string format, params object[] args)
      {
         if (logger != null)
            logger.WarnFormat(exception, formatProvider, format, args);
      }

      #endregion
   }
}
