﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace Structura.NUnitExtensions
{
   public class Addin : ConfigurationElement
   {
      /// <summary>
      /// Gets or sets the description.
      /// </summary>
      [ConfigurationProperty("path", DefaultValue = "", IsRequired = true)]
      public string Path
      {
         get
         {
            return (string)base["path"];
         }
         set
         {
            base["path"] = value;
         }
      }

   }

   [ConfigurationCollection(typeof(Addin))]
   public class AddinCollection : ConfigurationElementCollection
   {

      /// <summary>
      /// Creates a list of filters.
      /// </summary>

      public AddinCollection()
      {
      }

      protected override ConfigurationElement CreateNewElement()
      {
         return new Addin();
      }

      protected override object GetElementKey(ConfigurationElement element)
      {
         return ((Addin)element).Path;
      }

      public void Add(Addin element)
      {
         this.BaseAdd(element);
      }

      public void Remove(string key)
      {
         this.BaseRemove(key);
      }

      public void Clear()
      {
         this.BaseClear();
      }

      public Addin this[int index]
      {
         get
         {
            return (Addin)this.BaseGet(index);
         }
      }
   }

   public class AddinSectionHandler : ConfigurationSection
   {
      public AddinSectionHandler()
      {
      }

      [ConfigurationProperty("addins")]
      public AddinCollection Addins
      {
         get
         {
            return (AddinCollection)base["addins"];
         }
      }
   }
}