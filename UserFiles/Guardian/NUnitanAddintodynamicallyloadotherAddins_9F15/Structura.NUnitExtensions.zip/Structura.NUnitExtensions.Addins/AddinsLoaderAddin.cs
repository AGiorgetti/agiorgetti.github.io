﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using NUnit.Core;
using NUnit.Core.Builders;
using NUnit.Core.Extensibility;
using NUnit.Util;

namespace Structura.NUnitExtensions.Addins
{
   [NUnitAddin(Name = "AddinsLoaderAddin", Description = "An addin to dinamically load other addins")]
   public class AddinsLoaderAddin : IAddin
   {
      #region IAddin Members

      public bool Install(IExtensionHost host)
      {
         //IExtensionPoint builders = host.GetExtensionPoint("SuiteBuilders");
         //if (builders == null)
         //   return false;
         //builders.Install(this);
         //return true;

         AddinSectionHandler config = (AddinSectionHandler)System.Configuration.ConfigurationManager.GetSection("nUnitAddins");
         if (config != null)
         {
            // parse the addin data to load from the application configuration file
            foreach (Addin addin in config.Addins)
            {
               //// this is used by the gui to show the addins
               //if (NUnit.Util.Services.AddinManager != null)
               //   Services.AddinManager.Register(addin.Path);

               // this is used by the core to load and use them
               Assembly asm = Assembly.LoadFrom(addin.Path);
               CoreExtensions.Host.InstallAdhocExtensions(asm);
            }
         }
         
         return true;
      }

      #endregion
   }
}
