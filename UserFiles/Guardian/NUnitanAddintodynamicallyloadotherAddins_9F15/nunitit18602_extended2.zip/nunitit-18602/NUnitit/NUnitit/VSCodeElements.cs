﻿using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;

namespace NUnitit
{
   /// <summary>
   /// some routines to get the function code element where the cursor is on.
   /// </summary>
   /// <remarks>
   /// thanks to Carlos J. Quintero for the code that extract the CodeElements:
   /// http://www.mztools.com/articles/2006/MZ2006009.aspx
   /// </remarks>
   public class VSCodeElements
   {
      public static string GetFunctionAtTextPoint(Solution solution)
      {
         TextPoint tp = GetCursorTextPoint(solution);
         CodeElement ce = GetCodeElementAtTextPoint(vsCMElement.vsCMElementFunction,
                                                    solution.DTE.ActiveDocument.ProjectItem.FileCodeModel.CodeElements,
                                                    tp);
         if (ce != null)
            return ce.FullName;
         
         return string.Empty;
      }

      public static TextPoint GetCursorTextPoint(Solution solution)
      {

         TextDocument objTextDocument;
         TextPoint objCursorTextPoint = default(TextPoint);

         try
         {
            objTextDocument = (TextDocument)solution.DTE.ActiveDocument.Object("");
            objCursorTextPoint = objTextDocument.Selection.ActivePoint;
         }
         catch (Exception ex)
         {
         }
         
         return objCursorTextPoint;
      }

      public static CodeElement GetCodeElementAtTextPoint(vsCMElement eRequestedCodeElementKind, CodeElements colCodeElements, TextPoint objTextPoint)
      {

         CodeElement objResultCodeElement = default(EnvDTE.CodeElement);
         CodeElements colCodeElementMembers = default(EnvDTE.CodeElements);
         CodeElement objMemberCodeElement = default(EnvDTE.CodeElement);

         if ((colCodeElements != null))
         {

            foreach (CodeElement objCodeElement in colCodeElements)
            {

               if (objCodeElement.StartPoint.GreaterThan(objTextPoint))
               {
                  // The code element starts beyond the point
               }
               else if (objCodeElement.EndPoint.LessThan(objTextPoint))
               {
                  // The code element ends before the point
               }
               else
               {
                  // The code element contains the point

                  if (objCodeElement.Kind == eRequestedCodeElementKind)
                  {
                     // Found
                     objResultCodeElement = objCodeElement;
                  }

                  // We enter in recursion, just in case there is an inner code element that also 
                  // satisfies the conditions, for example, if we are searching a namespace or a class
                  colCodeElementMembers = GetCodeElementMembers(objCodeElement);

                  objMemberCodeElement = GetCodeElementAtTextPoint(eRequestedCodeElementKind, colCodeElementMembers, objTextPoint);

                  if ((objMemberCodeElement != null))
                  {
                     // A nested code element also satisfies the conditions
                     objResultCodeElement = objMemberCodeElement;
                  }
                  break; // TODO: might not be correct. Was : Exit For
               }

            }
         }
         return objResultCodeElement;
      }

      public static CodeElements GetCodeElementMembers(CodeElement objCodeElement)
      {
         CodeElements colCodeElements = default(EnvDTE.CodeElements);

         if (objCodeElement is CodeNamespace)
         {
            colCodeElements = ((CodeNamespace)objCodeElement).Members;
         }
         else if (objCodeElement is CodeType)
         {
            colCodeElements = ((CodeType)objCodeElement).Members;
         }
         else if (objCodeElement is CodeFunction)
         {
            colCodeElements = ((CodeFunction)objCodeElement).Parameters;
         }
         return colCodeElements;
      }

   }
}
