using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing.Design;
using System.Windows.Forms.Design;

namespace NUnitit
{
    public partial class NUnititSettings : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NUnititSettings"/> class.
        /// </summary>
        public NUnititSettings()
        {
            InitializeComponent();

            propertyGrid.SelectedObject = _settings;

            try
            {
                this.Text = this.Text + " v" + Common.GetAssemblyFileAttribute(Assembly.GetExecutingAssembly()).Version;
            }
            catch
            {
                // swallow any exception
            }
        }

        private SettingsProxy _settings = new SettingsProxy();

        private class SettingsProxy
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="SettingsProxy"/> class.
            /// </summary>
            public SettingsProxy()
            {
                _nunitConsolePath = Settings.Default.NUnitConsolePath;
                _nunitGUIPath = Settings.Default.NUnitGUIPath;
            }

            private string _nunitConsolePath;
            /// <summary>
            /// Gets or sets the NUnit console path.
            /// </summary>
            /// <value>The NUnit console path.</value>
            [Category("NUnit")]
            [Description("The location of the NUnitConsole runner. If left empty the addin will try to locate it automatically.")]
            [DefaultValue("")]
            [DisplayName("NUnit-Console executable")]
            [EditorAttribute(typeof(FileNameEditor), typeof(UITypeEditor))]
            public string NUnitConsolePath
            {
                get { return _nunitConsolePath; }
                set { _nunitConsolePath = value; }
            }

            private string _nunitGUIPath;
            /// <summary>
            /// Gets or sets the NUnit GUI path.
            /// </summary>
            /// <value>The NUnit GUI path.</value>
            [Category("NUnit")]
            [Description("The location of the NUnitGUI runner. If left empty the addin will try to locate it automatically.")]
            [DefaultValue("")]
            [DisplayName("NUnit-GUI executable")]
            [EditorAttribute(typeof(FileNameEditor), typeof(UITypeEditor))]
            public string NUnitGUIPath
            {
                get { return _nunitGUIPath; }
                set { _nunitGUIPath = value; }
            }

            /// <summary>
            /// Saves this instance.
            /// </summary>
            public void Save()
            {
                Settings.Default.NUnitConsolePath = NUnitConsolePath;
                Settings.Default.NUnitGUIPath = NUnitGUIPath;
                Settings.Default.Save();
            }
        }

        private void btOk_Click(object sender, EventArgs e)
        {
            _settings.Save();
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}