using System;
using System.Collections.Generic;
using System.Text;
using EnvDTE;
using Qreed.Diagnostics;
using System.IO;
using EnvDTE80;

namespace NUnitit
{
   public enum NUnitProgramType
   {
      Console,
      GUI
   }

   public class NUnitit
   {
      private Connect _connect;

      /// <summary>
      /// Initializes a new instance of the <see cref="NUnitit"/> class.
      /// </summary>
      /// <param name="connect">The connect.</param>
      public NUnitit(Connect connect)
      {
         _connect = connect;
      }

      public enum LaunchMode
      {
         StartupProject,
         ActiveProject
      }

      /// <summary>
      /// Launches the NUnit.
      /// </summary>
      /// <param name="program">The program.</param>
      public void LaunchNUnit(NUnitProgramType programType, LaunchMode mode)
      {
         string projectOutputFile = null;

         try
         {
            Project project;
            switch (mode)
            {
               case LaunchMode.StartupProject:
                  project = Common.GetStartupProject(_connect.ApplicationObject.Solution);
                  projectOutputFile = Common.GetProjectOutputFile(project);
                  _connect.ApplicationObject.Solution.SolutionBuild.Build(true);
                  break;
               case LaunchMode.ActiveProject:
                  project = Common.GetSelectedProject(_connect.ApplicationObject.Solution); // Common.GetStartupProject(_connect.ApplicationObject.Solution);
                  projectOutputFile = Common.GetProjectOutputFile(project);
                  string activeconfiguration = _connect.ApplicationObject.Solution.SolutionBuild.ActiveConfiguration.Name;
                  _connect.ApplicationObject.Solution.SolutionBuild.BuildProject(activeconfiguration, project.UniqueName, true);
                  break;
            }
         }
         catch (Exception ex)
         {
            _connect.DisplayErrorMessage("Startup project", "Failed to locate the output of the startup project.\n" + ex.ToString());
            return;
         }

         string processToLaunch = LocateLaunchProgram(programType);

         if (string.IsNullOrEmpty(processToLaunch))
            return; // Error is handled inside LocateLaunchProgram

         try
         {
            StartAndDebugProcess(processToLaunch, "\"" + projectOutputFile + "\"");
         }
         catch (Exception ex)
         {
            _connect.DisplayErrorMessage("Failed starting process.", ex.ToString());
         }
      }

      /// <summary>
      /// Launches the NUnit.
      /// </summary>
      /// <param name="program">The program.</param>
      public void LaunchNUnitSingleTest()
      {
         const NUnitProgramType programType = NUnitProgramType.Console;
         string projectOutputFile = null;
         string test = null;
         try
         {
            Project project = Common.GetCurrentlyOpenedProject(_connect.ApplicationObject.Solution);
            // _connect.DisplayErrorMessage("TEST", project.Name); // debug test message
            projectOutputFile = Common.GetProjectOutputFile(project);
            string activeconfiguration = _connect.ApplicationObject.Solution.SolutionBuild.ActiveConfiguration.Name;
            test = VSCodeElements.GetFunctionAtTextPoint(_connect.ApplicationObject.Solution);
            // _connect.DisplayErrorMessage("TEST", test); // debug test message
            if (string.IsNullOrEmpty(test))
               return; // no test to run

            _connect.ApplicationObject.Solution.SolutionBuild.BuildProject(activeconfiguration, project.UniqueName, true);
                  
         }
         catch (Exception ex)
         {
            _connect.DisplayErrorMessage("Startup project", "Failed to locate the output of the startup project.\n" + ex.ToString());
            return;
         }

         string processToLaunch = LocateLaunchProgram(programType);

         if (string.IsNullOrEmpty(processToLaunch))
            return; // Error is handled inside LocateLaunchProgram

         try
         {
            // _connect.DisplayErrorMessage("TEST", "/run:" + test + " \"" + projectOutputFile + "\""); // debug test message
            StartAndDebugProcess(processToLaunch, "/run:" + test + " \"" + projectOutputFile + "\"");
         }
         catch (Exception ex)
         {
            _connect.DisplayErrorMessage("Failed starting process.", ex.ToString());
         }
      }

      private void StartAndDebugProcess(string execPath, string arguments)
      {
         Win32Process.ProcessInformation pi = Win32Process.CreateProcess(execPath, arguments, null, Win32Process.CreationFlags.CREATE_SUSPENDED);

         if (pi.ProcessId == 0)
         {
            throw (new Exception("Failed starting the process \"" + execPath + "\"."));
         }

         try
         {
            Debugger2 debugger = (Debugger2)_connect.ApplicationObject.Debugger;
            Transport transport = debugger.Transports.Item("Default");

            Processes procList = debugger.GetProcesses(transport, ".");

            Process2 p2 = null;

            for (int i = 1; i <= procList.Count; i++)
            {
               if (procList.Item(i).ProcessID == pi.ProcessId)
               {
                  p2 = (Process2)procList.Item(i);
                  break;
               }
            }

            if (p2 == null)
               throw (new Exception("Unable to locate process with id " + pi.ProcessId));

            Engine[] engines = new Engine[1];
            engines[0] = transport.Engines.Item("Managed");

            p2.Attach2(engines);
         }
         catch (Exception ex)
         {
            throw (new Exception("Error occured while attaching debugger to the process.", ex));
         }
         finally
         {
            Win32Process.ResumeThread(pi.ThreadHandle);
         }
      }

      private string LocateLaunchProgram(NUnitProgramType programType)
      {
         string processToLaunch = null;
         string executableName = null;

         switch (programType)
         {
            case NUnitProgramType.Console:
               processToLaunch = Settings.Default.NUnitConsolePath;
               executableName = Resources.NUnitConsoleExec;
               break;

            case NUnitProgramType.GUI:
               processToLaunch = Settings.Default.NUnitGUIPath;
               executableName = Resources.NUnitGUIExec;
               break;
         }

         try
         {
            if (string.IsNullOrEmpty(processToLaunch))
            {
               processToLaunch = Common.GetNUnitExecPath(executableName);

               if (string.IsNullOrEmpty(processToLaunch))
               {
                  _connect.DisplayErrorMessage("Failed to locate NUnit", "Make sure NUnit is installed and/or the location is correct in the settings of NUnitit.");
                  _connect.DisplaySettings();
                  return null;
               }
            }
         }
         catch (Exception ex)
         {
            _connect.DisplayErrorMessage("Error locating NUnit", ex.ToString());
            return null;
         }

         if (!string.IsNullOrEmpty(processToLaunch) &&
            !File.Exists(processToLaunch))
         {
            _connect.DisplayErrorMessage("File not found", "Unable to open the executable \"" + processToLaunch + "\"");
            return null;
         }

         return processToLaunch;
      }
   }
}
