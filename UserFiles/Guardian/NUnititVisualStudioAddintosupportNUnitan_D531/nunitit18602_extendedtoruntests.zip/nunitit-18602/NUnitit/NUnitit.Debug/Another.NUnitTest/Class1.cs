using System;
using System.Collections.Generic;
using System.Text;

namespace Another.NUnitTest
{
    public class Class1
    {
    }
}
